# Apollo THC and TTCA replica controllers for Reentry

3D-printable, Arduino-based replicas of the Apollo Command Module Translation Hand
Controller (THC) and the Lunar Module Thrust/Translation Controller Assembly (TTCA),
shaped like the flight hardware and presented to the PC as USB game controllers
for *Reentry - A Space Flight Simulator*.

The build plan (reference data on the real controllers, what each exterior detail
is based on, mechanism description, bill of materials, print settings, assembly
steps, wiring, Reentry setup, tuning notes and sources) is the companion document
delivered with this archive.

## Contents

| Folder | What is in it |
| --- | --- |
| `stl/` | one `.stl` and one `.step` per printed part (`thc_*`, `ttca_*`; `ttca_boot` is the TPU part, `ttca_vent_plate` the white one), plus `thc_assembly.step` and `ttca_assembly.step` with all parts in their built positions |
| `cad/` | CadQuery sources: `common.py` (hardware sizes, clearances, colours, text engraving), `thc.py`, `ttca.py`; `shade.py` makes the preview images, `check_ttca.py` sweeps the TTCA handle through its travel and reports any part that touches another, `check_ttca_crank.py` swings the selector crank to THROTTLE and checks it against the sector and the mode switch, `check_ttca_lever.py` turns the selector lever, its band and its crank arm through JETS and THROTTLE against the parts outside and inside, `msh_extract.py` pulls labelled groups out of an Orbiter `.msh` cockpit mesh |
| `firmware/` | Arduino sketches `apollo_thc` and `apollo_ttca` (Pro Micro / Leonardo, Joystick library) |
| `renders/` | preview images used in the build plan |

## Regenerating the parts

```
pip install cadquery trimesh   # cadquery 2.8 or later; trimesh closes sphere seams in the STLs
cd cad
python3 thc.py                 # writes ../stl/thc_*.stl and .step
python3 ttca.py                # writes ../stl/ttca_*.stl and .step
python3 thc.py thc_grip        # one part only
python3 check_ttca.py          # interference sweep (about 25 min; --pitch -28,0 runs only those pitch angles)
python3 check_ttca_lever.py    # selector lever, band and crank arm through their swing (2 min)
python3 check_ttca_crank.py    # selector crank at THROTTLE against the sector and the parts round it
```

Every dimension is a named parameter at the top of `thc.py`, `ttca.py` and
`common.py` (travel, twist angle, grip size, housing size, spring sizes, switch
footprint, clearances, placard text). Change a value, rerun the script, and
reprint only the affected parts.

## Status

Revision 9: the boot, its clamp ring and the face layout are re-read from the
photographs and then sized as asked. The boot is now a squat cone (leaning 48
degrees), 116 mm across at the face and only 39 mm tall to its shoulder (47 to
the collar on the stem guide), with twelve sharp fins (a 1 mm TPU cone wall
carrying solid wedge fins whose undersides lean 65 degrees, the steepest
overhang TPU prints). The ring is 143 mm across and 12.5 wide with its twelve
screws on a 130.5 mm circle; its left edge is 11.5 mm from the body's left
edge, its top 13 mm below the face's top edge and its bottom 28 mm past the
crease, where it passes behind the friction knob as on the flight unit, so
the handle axis is now 15.5 mm left of the body's centre and 84.5 mm down
the face. The
placards, the friction knob, the band's tip and the face holes keep their
places on the face while the boot and ring moved (the brake tunnel follows
the knob, and the pad between its slider and the cradle's flange is longer
for it). The friction knob is now 73 mm up, as photographed. The brake pad
moved well back along the tunnel, to 66 degrees below and behind the gimbal,
because the cradle's brake flange could not stay under it over the whole
pitch travel where it was; the flange is 69 mm in radius with its rear corner
drawn in to 66 mm, so it clears the back chamfer by 7 mm at full pitch and
still carries the whole pad face at the other end of the travel (the three checks now
sample each part's surfaces as well as its vertices, which is how that was
found, along with two older faults the vertex sampling had missed: the pitch
stop fins are now radial wedges standing 1.5 degrees past the sector's edge
at full travel, and the plate that joined the crank's pivot lugs under the
crank, which its control arm swept through, is gone). The body is the
catalogued 7.75 in (197 mm) wide instead of 184, because in the face-on
photograph it is as wide as it is tall; the left-wall brackets and the pot
keep their room and the right-wall brackets simply reach further. As in the
photographs the ring overhangs the crease, so the housing carries a flat pad
under its lower part in front of the vertical lower face; the friction knob
(now 38 mm across) stands proud of that pad, 39 mm right of the body's centre.
The face layout: the four holes near the top corners and the hole beside the
placard, the 9.5 x 63.5 mm THROTTLE / JETS placard moved out to 20 mm from the
face's right edge with its arrows beside the words, the band's tip 41.5 mm
from the face's right edge at the ring's edge, no screw row on the face (the
photograph shows none) and four slotted screws on the flat top. Moving the
axis moved the mechanism with it; the lever's crank arm and the crank drive
were re-solved (lever swing +/-4.8 degrees, band travel 18 mm) and all three
interference checks pass. The square white vent plate low on the left wall
(left-side photograph) is now a separate part, ttca_vent_plate: a 39 mm
square, 2 mm thick, with a 23 mm fan wheel of 22 swept blades let 0.4 mm
into its face; the slots between the blades are open vents from 6.5 mm out
to the rim (0.96 to 1.7 mm wide, printable with a 0.4 nozzle) and continue
as grooves in to the hub. It sits flush in a 43.5 mm square frame standing
1 mm proud of the wall, over a 23.5 mm hole through the wall, on four M2 x 8
self-tapping screws (pilot holes with bosses inside); 63.5 mm from the back
wall and 31 mm up, as photographed. Print it on its back in white.

Revision 8: the TTCA's body is rebuilt to two direct side photographs of the
flight-type unit (lot 8118), scaled to its catalogued 8 in height: a vertical
back wall for the lower 103 mm, a 24-degree chamfer up to a 38 mm flat top at
203 mm, the front panel inclined 22.8 degrees for 128 mm down to a soft crease
85 mm above the base, a vertical lower face and a gentle 8 mm set-back into
the base (body 203 tall x 124 mm deep). The front is one formed 2 mm panel
standing proud of the box on its gasket; there is no separate top band. The
friction knob sits on the vertical lower face just below the crease with a
horizontal axis, as photographed, and the brake tunnel inside is re-aimed to
match. The selector lever is one straight flat piece from the side: a 21 mm
bar from a 26 mm hub on a 36 mm gasket ring at the back-bottom corner, under
the leaf-shaped guide plate, with the chrome band on its outer face curving
90 degrees in towards the handle on a 10 mm radius once past the face's edge,
its arm level across the face. Nothing hangs below the hub any more: the crank
drive is a small arm on the shaft's inboard end (ttca_lever_arm) whose pin
runs in a radial slot in the pawl crank, with the crank's spring moved behind
its tip arm. The left wall carries the faint 62 mm circle and the square vent
plate the photographs show. The auction listing notes that this unit's
T-handle and blue boot are 3D-printed reproductions, so the knob and boot
keep their NASSP proportions. Revisions 6 and 7 brought the face layout,
placards, holes and colours to the front-right and face-on photographs;
revisions 3 and 4 rebuilt both exteriors to the NASSP (Project Apollo for
Orbiter) cockpit meshes alongside NASA TN D-7884 and the auction
measurements; the THC is unchanged since then.
Designed in CAD, checked in section views and with interference sweeps of the
handle, the selector lever with its band and crank arm, and the crank; not yet
printed. See "Testing, tuning and known limitations" in the build plan.
