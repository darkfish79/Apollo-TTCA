#!/bin/sh
# usage: render_ttca.sh out.png [shade.py args...]   (exterior parts with the recommended colours)
cd "$(dirname "$0")/.." || exit 1
S=stl
G="0.60,0.62,0.64"; B="0.60,0.68,0.80"; A="0.80,0.81,0.83"; K="0.55,0.56,0.58"; L="0.58,0.59,0.61"
C="0.88,0.89,0.91"; P="0.08,0.08,0.09"; ST="0.75,0.76,0.78"; TK="0.66,0.67,0.68"; W="0.93,0.93,0.91"
OUT=$1; shift
python3 cad/shade.py "$OUT" $S/ttca_housing.stl:$G $S/ttca_bottom_plate.stl:$G $S/ttca_nameplate.stl:$A \
  $S/ttca_boot_ring.stl:$G $S/ttca_boot.stl:$B $S/ttca_stem_guide.stl:$G $S/ttca_stem.stl:$ST $S/ttca_knob.stl:$TK \
  $S/ttca_friction_knob.stl:$K $S/ttca_select_lever.stl:$L $S/ttca_lever_band.stl:$C $S/ttca_lever_guide.stl:$L \
  $S/ttca_placard_mode.stl:$P $S/ttca_placard_friction.stl:$P $S/ttca_vent_plate.stl:$W "$@"
