"""Interference check for the TTCA over its travel: moves the pitch / yaw / slide
groups through their stops and tests sample points of each part (its vertices
and 600 points spread over its surfaces, pulled 0.3 mm inside, so touching
parts do not count) against the other parts.  At the
neutral position every pair is tested, fixed parts included; the TPU boot is
only tested there (it flexes with the handle).
usage: python3 check_ttca.py [--pitch -28,0,28]   (run after ttca.py, from the cad directory;
       --pitch limits the sweep to those pitch angles, so it can be run in parts)"""
import math, itertools, sys, numpy as np, trimesh
from trimesh.ray.ray_triangle import RayMeshIntersector
import ttca as t

S = "../stl/"
PITCH = ["ttca_cradle", "ttca_yaw_block", "ttca_yaw_block_lid", "ttca_stem_washer", "ttca_stem", "ttca_stem_guide",
         "ttca_knob", "ttca_stub_axle_right", "ttca_stub_axle_left", "ttca_sector", "ttca_pot_coupler"]
YAW = ["ttca_yaw_block", "ttca_yaw_block_lid", "ttca_stem_washer", "ttca_stem", "ttca_stem_guide", "ttca_knob"]
SLIDE = ["ttca_stem", "ttca_knob"]
FIXED = ["ttca_housing", "ttca_boot_ring", "ttca_bottom_plate", "ttca_brake_slider", "ttca_brake_pad", "ttca_brake_rod",
         "ttca_detent_plunger", "ttca_pawl_crank", "ttca_friction_knob", "ttca_select_lever", "ttca_lever_band", "ttca_lever_arm",
         "ttca_lever_guide", "ttca_nameplate", "ttca_placard_mode", "ttca_placard_friction", "ttca_vent_plate"]
STATIC = ["ttca_boot"]                      # tested at neutral only
IGNORE = {("ttca_sector", "ttca_pawl_crank"), ("ttca_sector", "ttca_detent_plunger"),   # meant to touch
          ("ttca_cradle", "ttca_brake_pad"), ("ttca_stub_axle_right", "ttca_pawl_crank"),
          ("ttca_housing", "ttca_select_lever"),      # the lever's detent bump is preloaded into the wall
          ("ttca_select_lever", "ttca_lever_band"),   # the band is screwed to the lever's end
          ("ttca_select_lever", "ttca_lever_arm"),    # the arm sits on the shaft's flat
          ("ttca_lever_arm", "ttca_pawl_crank")}      # the arm's pin runs in the crank's slot

meshes, inter, pts = {}, {}, {}
rs = np.random.RandomState(0)
for n in sorted(set(PITCH + FIXED + STATIC)):                 # sorted: the same sample every run
    m = trimesh.load(S + n + ".stl", force="mesh")
    meshes[n] = m
    inter[n] = RayMeshIntersector(m)
    p = m.vertices - m.vertex_normals * 0.3
    if len(p) > 400:
        p = p[rs.choice(len(p), 400, replace=False)]
    # plus points spread over the surfaces, so a part passing through a thin flat wall (whose
    # vertices are only at its corners) is caught as well
    q, fi = trimesh.sample.sample_surface_even(m, 600, seed=0)
    q = q - m.face_normals[fi] * 0.3
    pts[n] = np.vstack([p, q])

ax = np.array([t.HANDLE_X, t.AY, t.AZ])
zdir = np.array([0.0, t.ST, t.CT]); ydir = np.array([0.0, t.CT, -t.ST])

def rot(axis, deg, point):
    return trimesh.transformations.rotation_matrix(math.radians(deg), axis, point)

def transform_of(n, pitch, yaw, slide):
    T = np.eye(4)
    if n in SLIDE:
        T = trimesh.transformations.translation_matrix(zdir * slide) @ T
    if n in YAW:
        T = rot(ydir, yaw, ax) @ T
    if n in PITCH:
        T = rot(np.array([1.0, 0, 0]), pitch, ax) @ T
    return T

def apply(T, p):
    return (T[:3, :3] @ p.T).T + T[:3, 3]

def inside(n, T_n, p_world):
    """Are the world points inside part n placed by T_n?"""
    p_local = apply(np.linalg.inv(T_n), p_world)
    out = []
    for k in range(0, len(p_local), 40):
        out.append(inter[n].contains_points(p_local[k:k + 40]))
    return np.concatenate(out) if out else np.zeros(0, bool)

problems = 0
P, Yw, Sl = t.PITCH_STOP, t.YAW_STOP, t.SLIDE
pitches = (-P, -P / 2, 0, P / 2, P)
if len(sys.argv) > 2 and sys.argv[1] == "--pitch":
    pitches = tuple(float(a) for a in sys.argv[2].split(","))
for pitch, yaw, slide in itertools.product(pitches, (-Yw, 0, Yw), (-Sl, 0, Sl)):
    if yaw and slide:
        continue
    neutral = (pitch, yaw, slide) == (0, 0, 0)
    Ts = {n: transform_of(n, pitch, yaw, slide) for n in meshes}
    for a, b in itertools.combinations(sorted(meshes), 2):
        if (a, b) in IGNORE or (b, a) in IGNORE:
            continue
        still = [n for n in (a, b) if n in FIXED or n in STATIC]
        if len(still) == 2 and not neutral:
            continue                        # fixed pair, checked once
        if (a in STATIC or b in STATIC) and not neutral:
            continue
        if a in PITCH and b in PITCH and not (set((a, b)) & set(YAW + SLIDE)) and not neutral:
            continue                        # rigid pair, checked once
        pa, pb = apply(Ts[a], pts[a]), apply(Ts[b], pts[b])
        hits = int(inside(b, Ts[b], pa).sum()) + int(inside(a, Ts[a], pb).sum())
        if hits:
            problems += 1
            print(f"pitch {pitch:+5.1f} yaw {yaw:+5.1f} slide {slide:+4.1f}: {a} <-> {b}: {hits} sample points inside", flush=True)
print("problems:", problems)
