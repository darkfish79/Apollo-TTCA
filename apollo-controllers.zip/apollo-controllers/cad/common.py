"""Shared helpers and hardware dimensions for the Apollo THC / TTCA replicas.

All dimensions are millimetres. Everything in this file is a parameter you may
change; the part scripts import these names.
"""
import os
import cadquery as cq

OUT_DIR = os.environ.get("APOLLO_OUT", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "stl"))

# ---------------------------------------------------------------- hardware --
# Sub-miniature snap-action lever microswitch, KW11-3Z / 10T85 style.
SW_L = 19.8          # body length
SW_H = 10.2          # body height (plunger on this edge)
SW_T = 6.4           # body thickness
SW_PLUNGER = 1.5     # plunger protrusion above the body at rest
SW_HOLE_D = 2.6      # mounting holes (M2.5 clearance), 9.5 mm apart, 2.6 mm up from
SW_HOLE_PITCH = 9.5  # the terminal edge, centred on the length

# Potentiometer, 10 kOhm linear, 16 mm body (Alpha RV16 / B10K), 6 mm D-shaft.
POT_BUSH_D = 7.2
POT_SHAFT_D = 6.2
POT_BODY_D = 17.0

# Fasteners
M3_CLEAR = 3.4
M3_INSERT = 4.0      # hole for a 4 mm OD heat-set insert (M3), 5-6 mm long
M3_HEAD_D = 6.0
M2_CLEAR = 2.3
M25_CLEAR = 2.8
M4_CLEAR = 4.4

# Springs (from a common 200 pc spring assortment)
COMP_SPRING_OD = 8.0

# Printing
CLEAR_SLIDE = 0.4    # radial clearance for a sliding fit
CLEAR_PRESS = 0.1    # radial clearance for a press fit
CLEAR_FREE = 0.6     # clearance where parts must never touch

# Finish / colours used in the renders and recommended for the prints
COL_HOUSING_GRAY = (0.62, 0.64, 0.66)   # CM THC: light gray enamel
COL_HOUSING_DARK = (0.30, 0.31, 0.33)   # LM TTCA: dark gray
COL_GRIP = (0.52, 0.53, 0.55)           # gray grip (auction grips are "gray-tone")
COL_BOOT = (0.12, 0.12, 0.13)           # black boot / bellows
COL_SKIRT_BLUE = (0.16, 0.35, 0.70)     # TTCA blue anodized skirt
COL_ALU = (0.80, 0.81, 0.83)            # bare aluminium lever
COL_PLACARD = (0.92, 0.92, 0.90)


def cyl(d, h, at=(0, 0, 0), axis="Z"):
    wp = {"Z": "XY", "X": "YZ", "Y": "XZ"}[axis]
    return cq.Workplane(wp).circle(d / 2).extrude(h).translate(at)


def box(x, y, z, at=(0, 0, 0), centered=(True, True, False)):
    return cq.Workplane("XY").box(x, y, z, centered=centered).translate(at)


def engrave(text, size, depth, face, at, kind="bold"):
    """Text cutter for a flat face.  face: 'front' (+Z), 'back' (-Z), 'top' (+Y),
    'bottom' (-Y), 'right' (+X), 'left' (-X), each read the natural way with
    +Y up (top/bottom: read from the +Z side).  `at` is the text centre on the
    face plane; the solid cuts `depth` into the material and stands 0.1 proud."""
    t = cq.Workplane("XY").text(text, size, depth + 0.1, kind=kind, halign="center", valign="center")
    t = t.translate((0, 0, -depth))          # z from -depth to +0.1, normal +Z
    rot = {"front": [], "back": [((0, 1, 0), 180)], "top": [((1, 0, 0), -90)], "bottom": [((1, 0, 0), 90)],
           "right": [((0, 1, 0), 90)], "left": [((0, 1, 0), -90)]}[face]
    for axis, ang in rot:
        t = t.rotate((0, 0, 0), axis, ang)
    return t.translate(at)


def _split_t_junctions(m, passes=6):
    """Split faces whose edge runs through a boundary vertex of a neighbouring
    face (T-junctions the tessellator leaves along fillet seams)."""
    import numpy as np, trimesh
    for _ in range(passes):
        uniq, counts = np.unique(m.edges_sorted, axis=0, return_counts=True)
        bverts = np.unique(uniq[counts == 1].ravel())
        if len(bverts) == 0:
            return m
        V = m.vertices; F = m.faces
        new_faces = []
        split = np.zeros(len(F), bool)
        for w in bverts:
            P = V[w]
            for k in range(3):
                u = F[:, k]; v = F[:, (k + 1) % 3]; o = F[:, (k + 2) % 3]
                A = V[u]; B = V[v]
                AB = B - A; AP = P - A
                L2 = (AB * AB).sum(1)
                tpar = (AP * AB).sum(1) / np.maximum(L2, 1e-12)
                dist = np.linalg.norm(P - (A + AB * tpar[:, None]), axis=1)
                ok = (dist < 1e-4) & (tpar > 1e-6) & (tpar < 1 - 1e-6) & (u != w) & (v != w) & (o != w) & ~split
                for i in np.nonzero(ok)[0]:
                    split[i] = True
                    new_faces.append([F[i, k], w, F[i, (k + 2) % 3]])
                    new_faces.append([w, F[i, (k + 1) % 3], F[i, (k + 2) % 3]])
        if not new_faces:
            return m
        m = trimesh.Trimesh(vertices=V, faces=np.vstack([F[~split], np.array(new_faces)]), process=False)
    return m


def _drop_fins(m, passes=4):
    """Remove dangling faces (two or more of their edges on no other face) and
    the slivers folded onto an edge that more than two faces share."""
    import numpy as np
    for _ in range(passes):
        uniq, inv, counts = np.unique(m.edges_sorted, axis=0, return_inverse=True, return_counts=True)
        ec = counts[inv.ravel()].reshape(-1, 3)
        fin = (ec == 1).sum(1) >= 2
        over = (ec > 2).any(1) & (m.area_faces < 0.5)                  # tiny faces on an over-shared edge
        drop = fin | over
        if not drop.any():
            return m
        m.update_faces(~drop)
    return m


def _weld_boundary(m, tol=0.15):
    """Merge boundary vertices that lie within tol of each other (the scraps a
    tangency leaves), then drop the faces that collapse."""
    import numpy as np, trimesh
    uniq, counts = np.unique(m.edges_sorted, axis=0, return_counts=True)
    bverts = np.unique(uniq[counts == 1].ravel())
    if len(bverts) < 2:
        return m
    V = m.vertices.copy(); F = m.faces.copy()
    remap = np.arange(len(V))
    for i, a in enumerate(bverts):
        for b in bverts[i + 1:]:
            if remap[b] == b and np.linalg.norm(V[a] - V[b]) < tol:
                remap[b] = remap[a]
    F = remap[F]
    m = trimesh.Trimesh(vertices=V, faces=F, process=False)
    m.update_faces(m.nondegenerate_faces()); m.update_faces(m.unique_faces())
    return m


def _clean(m):
    m.merge_vertices(digits_vertex=3)
    m.update_faces(m.nondegenerate_faces()); m.update_faces(m.unique_faces())
    return m


def export(shape, name, step=True):
    os.makedirs(OUT_DIR, exist_ok=True)
    path = os.path.join(OUT_DIR, name + ".stl")
    cq.exporters.export(shape, path, tolerance=0.02, angularTolerance=0.1)
    try:   # close the seams OCC leaves at sphere poles and along fillet corners, so slicers get a watertight mesh
        import trimesh
        m = trimesh.load(path, force="mesh")
        if not m.is_watertight:
            m = _clean(m)
            m = _split_t_junctions(m)
            m = _clean(m)
            m = _drop_fins(m)
            if not m.is_watertight:
                m = _weld_boundary(m)
                m = _drop_fins(m)
            if not m.is_watertight:
                trimesh.repair.fill_holes(m)
            if not m.is_watertight:
                print(f"{name}: STL is not watertight")
            m.export(path)
    except ImportError:
        pass
    if step:
        cq.exporters.export(shape, os.path.join(OUT_DIR, name + ".step"))
    bb = shape.val().BoundingBox()
    print(f"{name:28s} {bb.xlen:6.1f} x {bb.ylen:6.1f} x {bb.zlen:6.1f} mm")
    return path
