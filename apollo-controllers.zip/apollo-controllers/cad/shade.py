"""Shaded PNG renders of STL files with a small numpy z-buffer rasteriser.
usage: python3 shade.py out.png a.stl[:r,g,b] b.stl ... [--view ex,ey,ez] [--up x|y|z]
                        [--cut x|x+|y|y+|x-12.5|x+12.5] [--px N]
"""
import sys
import numpy as np
import trimesh
from PIL import Image

args = sys.argv[1:]
out = args.pop(0)
view = np.array([1.0, -1.2, 0.8]); cut = None; px = 900; upname = "z"
files = []
i = 0
while i < len(args):
    a = args[i]
    if a == "--view":
        view = np.array([float(v) for v in args[i + 1].split(",")]); i += 2; continue
    if a == "--cut":
        cut = args[i + 1]; i += 2; continue
    if a == "--px":
        px = int(args[i + 1]); i += 2; continue
    if a == "--up":
        upname = args[i + 1]; i += 2; continue
    files.append(a); i += 1

palette = [(0.78, 0.78, 0.80), (0.90, 0.58, 0.35), (0.45, 0.65, 0.90), (0.55, 0.80, 0.50),
           (0.92, 0.82, 0.40), (0.80, 0.50, 0.75), (0.50, 0.80, 0.80), (0.90, 0.60, 0.60),
           (0.60, 0.60, 0.90), (0.75, 0.85, 0.60)]
tris, cols = [], []
for k, f in enumerate(files):
    col = palette[k % len(palette)]
    if ":" in f:
        f, c = f.split(":"); col = tuple(float(v) for v in c.split(","))
    m = trimesh.load(f, force="mesh")
    if cut:
        ax = "xyz".index(cut[0]); sgn = 1.0 if (len(cut) > 1 and cut[1] == "+") else -1.0
        val = float(cut[2:]) if len(cut) > 2 else 0.0
        origin = [0, 0, 0]; origin[ax] = val
        normal = [0, 0, 0]; normal[ax] = sgn
        m = m.slice_plane(origin, normal, cap=True)
    if len(m.faces) == 0:
        continue
    tris.append(m.vertices[m.faces]); cols.append(np.tile(np.array(col), (len(m.faces), 1)))
T = np.vstack(tris); C = np.vstack(cols)

d = view / np.linalg.norm(view)
up = {"x": np.array([1.0, 0, 0]), "y": np.array([0, 1.0, 0]), "z": np.array([0, 0, 1.0])}[upname]
if abs(np.dot(up, d)) > 0.95:
    up = np.array([0, 1.0, 0]) if upname == "z" else np.array([0, 0, 1.0])
right = np.cross(up, d); right /= np.linalg.norm(right)
up2 = np.cross(d, right)
P = np.stack([right, up2, d], axis=1)
V = T @ P
n = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0])
nn = np.linalg.norm(n, axis=1); keep = nn > 1e-9
V, C, n = V[keep], C[keep], n[keep] / nn[keep, None]
# two lights: key from the upper left of the camera, fill from the camera
key = np.array([-0.4, 0.7, 0.6]); key /= np.linalg.norm(key)
nc = n @ P
shade = 0.22 + 0.55 * np.clip(np.abs(nc @ key), 0, 1) + 0.28 * np.clip(np.abs(nc[:, 2]), 0, 1)
C = np.clip(C * shade[:, None], 0, 1)

lo = V[:, :, :2].reshape(-1, 2).min(0); hi = V[:, :, :2].reshape(-1, 2).max(0)
span = (hi - lo).max() * 1.06
scale = px / span
off = (lo + hi) / 2 - span / 2
img = np.ones((px, px, 3)) * 1.0
zb = np.full((px, px), -np.inf)
for t in range(len(V)):
    v = V[t]
    xy = (v[:, :2] - off) * scale
    x0, y0 = np.floor(xy.min(0)).astype(int); x1, y1 = np.ceil(xy.max(0)).astype(int)
    x0, y0 = max(x0, 0), max(y0, 0); x1, y1 = min(x1, px - 1), min(y1, px - 1)
    if x1 < x0 or y1 < y0:
        continue
    xs, ys = np.meshgrid(np.arange(x0, x1 + 1) + 0.5, np.arange(y0, y1 + 1) + 0.5)
    (ax, ay), (bx, by), (cx, cy) = xy
    det = (bx - ax) * (cy - ay) - (cx - ax) * (by - ay)
    if abs(det) < 1e-12:
        continue
    l1 = ((bx - xs) * (cy - ys) - (cx - xs) * (by - ys)) / det
    l2 = ((cx - xs) * (ay - ys) - (ax - xs) * (cy - ys)) / det
    l3 = 1 - l1 - l2
    inside = (l1 >= -1e-6) & (l2 >= -1e-6) & (l3 >= -1e-6)
    if not inside.any():
        continue
    z = l1 * v[0, 2] + l2 * v[1, 2] + l3 * v[2, 2]
    sub = zb[y0:y1 + 1, x0:x1 + 1]
    m = inside & (z > sub)
    sub[m] = z[m]
    img[y0:y1 + 1, x0:x1 + 1][m] = C[t]
Image.fromarray((np.flipud(img) * 255).astype(np.uint8)).save(out)
print("wrote", out)
