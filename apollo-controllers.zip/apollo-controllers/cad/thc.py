"""Apollo Block II Translation Hand Controller (THC) replica, revision 3 -
exterior matched to the Honeywell CG160 flight unit as modelled in the NASSP
(Project Apollo for Orbiter) cockpit mesh, with the NASA TN D-7884 envelope.

CAD frame:  Z = handle axis, +Z towards the user (out of the front plate),
            X = width (left/right), Y = height (up/down).
            Z = 0 is the outer face of the front plate; the mechanism is at -Z.
            The housing is centred on (0, 0); the handle axis is at (0, HY).

Exterior (what the user sees)
  housing   97 wide x 160 long x 109 deep box (NASA envelope 3.83 x 6.31 in),
            light gray, 1.5 mm chamfered edges, screwed front plate, nameplate
            recesses on the right side, dovetail socket underneath, round
            connector boss on the back.
  boot      black stepped cone (five rings, 70 -> 36 mm) that moves with the
            handle over a hidden escutcheon disc, as the flight boot does.
  handle    gray T-grip: 17 mm stem, spindle-shaped crossbar 83 long x 27 mm
            (the auctioned flight grips measure 3.25 x 1 in), pointed ends.
  lock      sliding block (15 x 24 x 9) on the front face beyond the handle (+Y
            end), offset to the right as on the flight unit: pushed towards the
            handle = LOCK, away = ARM.

Mechanism (unchanged in principle from revision 1)
  carriage  50 x 70 block sliding behind the front plate, +/-TRAVEL in X and Y,
            centred by eight wall springs, pressing four lever switches in the
            pocket walls.
  shaft     slides +/-TRAVEL along Z in the carriage, centred by two spring
            pairs; its tail disc presses a pull switch (on a fin from the floor)
            and a push switch (on a fin on the back floor).
  sleeve    keyed to the square tail, twists +/-ROT_STOP, paddle centred by two
            springs and pressing two switches on the carriage deck.

python3 thc.py  ->  ../stl/thc_*.stl and .step
"""
import math
import cadquery as cq
from common import *

# -------------------------------------------------------------- parameters --
TRAVEL = 8.0
ROT_STOP = 17.0
ROT_SWITCH = 12.0

HOUSING_W = 97.0
HOUSING_H = 160.0
EDGE_CH = 1.5             # chamfer on the long edges
HY = 10.0                 # handle axis above the housing centre (grip 53 % down the box, as NASSP)
FRONT_T = 5.0
BACK_T = 4.0
BOTTOM_T = 12.0           # rear body bottom wall (carries the dovetail socket)
SIDE_T = 4.0

GRIP_BAR_LEN = 83.0
GRIP_BAR_D = 27.0         # spindle diameter at the middle
GRIP_STEM_D = 17.0
GRIP_STEM_H = 23.0        # boot top to the underside of the bar
GRIP_H = GRIP_STEM_H + GRIP_BAR_D   # boot top to the top of the bar (50)
BOOT_STEPS = [(70.0, 6.0), (60.0, 5.0), (52.0, 5.0), (44.0, 5.0), (36.0, 3.0)]   # (diameter, height), base first
BOOT_H = sum(h for _, h in BOOT_STEPS)      # 24
BOOT_BASE_D = 48.0        # skirt through the plate hole
BOOT_ID = 38.0
DISC_D = 84.0
DISC_T = 3.0
HUB_GAP = TRAVEL          # disc back face to the front plate at neutral

SHAFT_DIA = 14.0
TAIL_SQ = 10.0

CARRIAGE_W, CARRIAGE_H, CARRIAGE_T = 50.0, 70.0, 32.0
BOSS_DIA, BOSS_H = 36.0, 14.0
POCKET_W, POCKET_H = CARRIAGE_W + 2 * TRAVEL, CARRIAGE_H + 2 * TRAVEL   # 66 x 86
WALL = (HOUSING_W - POCKET_W) / 2                                        # 15.5
FRONT_HOLE = BOOT_BASE_D - 2 + 2 * TRAVEL + 2       # 64
TAB_T, TAB_W, TAB_REACH = 4.0, 8.0, 14.0
REAR_CAV_W = HOUSING_W - 2 * SIDE_T                 # 89
REAR_CAV_Y0, REAR_CAV_Y1 = -HOUSING_H / 2 + BOTTOM_T, HOUSING_H / 2 - SIDE_T   # -68 .. 76

SW_RECESS = 1.5
YZ_SPRING_D = 6.0
YZ_SPRING_FREE = 20.0
YZ_SPRING_PRELOAD = 2.0
YZ_SPRING_OFF = (22.0, 16.0)   # spring offsets from the slot centre: X walls (in Y), Y walls (in X)

NECK_H, DECK_T = 5.0, 4.0
DECK_W, DECK_H = 56.0, 60.0
NOTCH_W = 26.0
SLEEVE_BOSS_D, SLEEVE_BOSS_H = 30.0, 25.0
SLEEVE_OD = 22.0
PADDLE_W, PADDLE_R, PADDLE_L, PADDLE_Z0 = 6.0, 26.0, 16.0, 1.0
ROT_SPRING_INSTALLED = 16.0
ROT_SW_FACE = 8.2

TAIL_DISC_D, TAIL_DISC_T = 76.0, 6.0
XSPRING_POST_D = 5.6
XSPRING_FRONT_R = 12.0
XSPRING_REAR = [(20.0, -10.0), (-20.0, -10.0)]   # relative to the handle axis
PULL_STANDOFF, PUSH_STANDOFF = 4.0, 6.0
LEVER_PROUD, CONTACT_AT = 4.0, 5.0

LOCK_SLOT_Y = HY + 56.0   # centre of the slot in the front plate (block 56 mm beyond the grip at the +Y end, as NASSP)
LOCK_TRAVEL = 8.0
LOCK_BLOCK = (15.0, 24.0, 9.0)   # thumb block over the slot, offset LOCK_BLOCK_X to the right
LOCK_BLOCK_X = 4.0

# ---------------------------------------------------------------- derived --
Z_FRONT_IN = -FRONT_T                          # -5
Z_CARR_BACK = Z_FRONT_IN - CARRIAGE_T          # -37
Z_TAB_F = Z_CARR_BACK - 0.5
Z_TAB_B = Z_TAB_F - TAB_T                      # -41.5
Z_DECK_B = Z_CARR_BACK - NECK_H - DECK_T       # -46
Z_SLEEVE_END = Z_CARR_BACK - SLEEVE_BOSS_H - 3 # -65
Z_DISC_F = Z_SLEEVE_END - TRAVEL - 0.5         # -73.5
Z_DISC_B = Z_DISC_F - TAIL_DISC_T              # -79.5
Z_PULL_TIP = Z_DISC_F + CONTACT_AT
Z_PULL_FACE = Z_PULL_TIP + LEVER_PROUD         # plunger face
Z_PULL_BODY_B = Z_PULL_FACE + SW_H             # terminal edge, nearer the carriage
Z_PUSH_TIP = Z_DISC_B - CONTACT_AT
Z_PUSH_FACE = Z_PUSH_TIP - LEVER_PROUD
Z_BACK_IN = Z_PUSH_FACE - SW_H - PUSH_STANDOFF
Z_BACK_OUT = Z_BACK_IN - BACK_T
DEPTH = -Z_BACK_OUT
REAR_PED = (Z_DECK_B - Z_DISC_F) - 24.0        # rear X-spring pedestal height (24 installed)
YZ_POCKET_DEPTH = YZ_SPRING_FREE - YZ_SPRING_PRELOAD - TRAVEL
TAIL_LEN = (Z_CARR_BACK - 2) - (Z_DISC_B + 1.5)
Z_BOOT_TOP = HUB_GAP + DISC_T + BOOT_H          # 35
Z_GRIP_TOP = Z_BOOT_TOP + GRIP_H                # 85
FRONT_SPRING_INST = (Z_BOOT_TOP - 6) - (Z_FRONT_IN + BOSS_H)


def report():
    print(f"depth {DEPTH:.1f}  grip top {Z_GRIP_TOP:.0f}  front springs {FRONT_SPRING_INST:.0f} mm installed, "
          f"rear pedestal {REAR_PED:.1f}, wall spring pocket {YZ_POCKET_DEPTH:.0f}, wall {WALL:.1f}")


def screw_pts():
    x = HOUSING_W / 2 - 6.5
    return [(x, 74), (-x, 74), (x, -74), (-x, -74), (x, 56), (-x, 56), (x, -27), (-x, -27), (26, 74), (-26, 74), (26, -74), (-26, -74)]


def block_outline(z0, length):
    return cq.Workplane("XY").rect(HOUSING_W, HOUSING_H).extrude(length).translate((0, 0, z0)).edges("|Z").chamfer(EDGE_CH)


# -------------------------------------------------------------- housing ----
def front_plate():
    p = block_outline(-FRONT_T, FRONT_T).faces(">Z").edges().chamfer(0.8)
    p = p.cut(cyl(FRONT_HOLE, -FRONT_T - 1, (0, HY, 0.5)))
    for (x, y) in screw_pts():
        p = p.cut(cyl(M3_CLEAR, -FRONT_T - 1, (x, y, 0.5)))
        p = p.cut(cyl(M3_HEAD_D, -2.2, (x, y, 0.5)))
    # lock slider groove on the inside, slot through the plate for the thumb block
    p = p.cut(box(10.6, 50, 2.6, (0, LOCK_SLOT_Y - 9, Z_FRONT_IN - 0.1), (True, True, False)))
    p = p.cut(box(10.6, 16.6, FRONT_T + 2, (0, LOCK_SLOT_Y, Z_FRONT_IN - 1), (True, True, False)))
    p = p.cut(engrave("LOCK", 4, 0.6, "front", (-14, LOCK_SLOT_Y - 8, 0)))
    p = p.cut(engrave("ARM", 4, 0.6, "front", (-14, LOCK_SLOT_Y + 8, 0)))
    return p


def front_body():
    h = block_outline(Z_TAB_B, Z_FRONT_IN - Z_TAB_B)
    h = h.cut(box(POCKET_W, POCKET_H, Z_FRONT_IN - Z_TAB_F + 1, (0, HY, Z_TAB_F), (True, True, False)))
    opening = box(POCKET_W, POCKET_H, TAB_T + 1, (0, HY, Z_TAB_B - 0.5))
    for a, (px, py) in zip((0, 90, 180, 270), ((POCKET_W / 2, 0), (0, POCKET_H / 2), (-POCKET_W / 2, 0), (0, -POCKET_H / 2))):
        r = math.hypot(px, py)
        tab = box(TAB_REACH + 1, TAB_W, TAB_T + 1, (r - TAB_REACH + 0.5, 0, Z_TAB_B - 0.5), (False, True, False))
        opening = opening.cut(tab.rotate((0, 0, 0), (0, 0, 1), a).translate((0, HY, 0)))
    h = h.cut(opening)
    zc = Z_FRONT_IN - CARRIAGE_T / 2
    for a, half, off in ((0, POCKET_W / 2, YZ_SPRING_OFF[0]), (180, POCKET_W / 2, YZ_SPRING_OFF[0]),
                         (90, POCKET_H / 2, YZ_SPRING_OFF[1]), (270, POCKET_H / 2, YZ_SPRING_OFF[1])):
        slot = box(SW_RECESS + SW_H + 0.4 + 2.0, SW_L + 0.6, SW_T + 0.6,
                   (half - SW_RECESS, 0, zc - (SW_T + 0.6) / 2), (False, True, False))
        groove = box(3.0, 4.0, 40, (half - 1.5, 0, Z_TAB_B - 1), (False, True, False))
        cut = slot.union(groove)
        for s in (-1, 1):
            cut = cut.union(cyl(YZ_SPRING_D + 0.7, YZ_POCKET_DEPTH + 0.5).rotate((0, 0, 0), (0, 1, 0), 90)
                            .translate((half - 0.5, s * off, zc)))
        h = h.cut(cut.rotate((0, 0, 0), (0, 0, 1), a).translate((0, HY, 0)))
    for (x, y) in screw_pts():
        h = h.cut(cyl(M3_CLEAR, -(Z_FRONT_IN - Z_TAB_B) - 2, (x, y, Z_FRONT_IN + 1)))
    return h


def rear_body():
    h = block_outline(Z_BACK_OUT, Z_TAB_B - Z_BACK_OUT)
    cav = box(REAR_CAV_W, REAR_CAV_Y1 - REAR_CAV_Y0, Z_TAB_B - Z_BACK_IN + 1,
              (0, (REAR_CAV_Y0 + REAR_CAV_Y1) / 2, Z_BACK_IN), (True, True, False)).edges("|Z").fillet(3)
    h = h.cut(cav)
    for (x, y) in screw_pts():
        h = h.cut(cyl(M3_INSERT, -10, (x, y, Z_TAB_B + 0.1)))
    # pull-switch fin: plate standing on the back floor and the bottom wall, with a window
    fin = box(4, (HY - 20 + 11) - REAR_CAV_Y0 + 0.5, Z_PULL_BODY_B + PULL_STANDOFF - Z_BACK_IN,
              (5.2, ((HY - 20 + 11) + REAR_CAV_Y0 - 0.5) / 2, Z_BACK_IN), (True, True, False))
    fin = fin.cut(box(6, 40, 28, (5.2, REAR_CAV_Y0 + 28, Z_BACK_IN + 8), (True, True, False)))
    h = h.union(fin)
    for dy in (-SW_HOLE_PITCH / 2, SW_HOLE_PITCH / 2):
        h = h.cut(cyl(2.3, 8, (1, HY - 20 + dy, Z_PULL_BODY_B - 2.6), "X"))
    # push-switch fin on the back floor
    fin2 = box(4, 24, PUSH_STANDOFF + SW_H + 2, (5.2, HY - 20, Z_BACK_IN), (True, True, False))
    h = h.union(fin2)
    for dy in (-SW_HOLE_PITCH / 2, SW_HOLE_PITCH / 2):
        h = h.cut(cyl(2.3, 8, (1, HY - 20 + dy, Z_BACK_IN + PUSH_STANDOFF + 2.6), "X"))
    # Pro Micro standing in two rails on the back floor, USB plug out through the back
    for s in (-1, 1):
        rail = box(4, 10, 30, (s * (8.9 + 2.0), -50, Z_BACK_IN), (True, True, False))
        rail = rail.cut(box(2.0, 2.0, 31, (s * (8.9 + 0.8), -50, Z_BACK_IN - 0.5), (True, True, False)))
        h = h.union(rail)
    h = h.cut(box(13, 8.5, BACK_T + 2, (0, -50, Z_BACK_OUT - 1), (True, True, False)))
    # dovetail socket in the bottom face, open to the back
    dt = (cq.Workplane("XY").polyline([(-10, -0.5), (10, -0.5), (14, 7), (-14, 7)]).close()
          .extrude(-70).translate((0, -HOUSING_H / 2, Z_BACK_OUT + 66)))
    h = h.cut(dt)
    # nameplate recesses on the right side, first one engraved
    xw = HOUSING_W / 2
    for (y, hgt) in ((26, 20), (6, 12), (-10, 12)):
        h = h.cut(box(0.6, hgt, 56, (xw - 0.3, y, Z_BACK_OUT + 20), (True, True, False)))
    h = h.cut(engrave("CONTROL-TRANSLATION", 3.6, 0.5, "right", (xw - 0.6, 29, Z_BACK_OUT + 48)))
    h = h.cut(engrave("MFR PART NO CG160G2", 3.0, 0.5, "right", (xw - 0.6, 23, Z_BACK_OUT + 48)))
    return h


def connector_boss():
    """Decorative circular-connector flange glued over the USB exit on the back face."""
    b = cyl(26, -7, (0, -50, Z_BACK_OUT))
    b = b.union(cyl(20, -5, (0, -50, Z_BACK_OUT - 7)))
    b = b.cut(box(13, 8.5, 14, (0, -50, Z_BACK_OUT - 13), (True, True, False)))
    for a in (45, 135, 225, 315):
        b = b.cut(cyl(2.2, -3, (10 * math.cos(math.radians(a)), -50 + 10 * math.sin(math.radians(a)), Z_BACK_OUT - 7)))
    return b


# ------------------------------------------------------------- carriage ----
def carriage():
    c = (cq.Workplane("XY").rect(CARRIAGE_W, CARRIAGE_H).extrude(-CARRIAGE_T)
         .translate((0, 0, Z_FRONT_IN)).edges("|Z").chamfer(1.0))
    neck = box(DECK_W, DECK_H, NECK_H, (0, 0, Z_CARR_BACK - NECK_H))
    for a, half in ((0, DECK_W / 2), (180, DECK_W / 2), (90, DECK_H / 2), (270, DECK_H / 2)):
        n = box(half - 16 + 1, NOTCH_W, NECK_H + 1, (16, 0, Z_CARR_BACK - NECK_H - 0.5), (False, True, False))
        neck = neck.cut(n.rotate((0, 0, 0), (0, 0, 1), a))
    deck = box(DECK_W, DECK_H, DECK_T, (0, 0, Z_DECK_B)).edges("|Z").chamfer(1.0)
    c = c.union(neck).union(deck)
    c = c.cut(cyl(SHAFT_DIA + 2 * CLEAR_SLIDE, -CARRIAGE_T - 20, (0, 0, Z_FRONT_IN + 1)))
    for a in (90, 210, 330):
        c = c.cut(cyl(M3_INSERT, -8, (13 * math.cos(math.radians(a)), 13 * math.sin(math.radians(a)), Z_FRONT_IN + 0.1)))
    c = c.union(cyl(SLEEVE_BOSS_D, -SLEEVE_BOSS_H, (0, 0, Z_CARR_BACK)))
    c = c.cut(cyl(SLEEVE_OD + 2 * CLEAR_SLIDE, -SLEEVE_BOSS_H - 1, (0, 0, Z_CARR_BACK + 0.5)))
    half = SLEEVE_BOSS_D / 2 * math.sin(math.radians(ROT_STOP)) + PADDLE_W / 2
    slot_h = (Z_DECK_B - 0.5) - (Z_CARR_BACK - SLEEVE_BOSS_H - 1)
    c = c.cut(box(2 * half, SLEEVE_BOSS_D, slot_h, (0, 0, Z_CARR_BACK - SLEEVE_BOSS_H - 1), (True, False, False)))
    for a in (210, 330):
        c = c.cut(cyl(2.1, 8, (12.5 * math.cos(math.radians(a)), 12.5 * math.sin(math.radians(a)), Z_CARR_BACK - SLEEVE_BOSS_H - 0.1)))
    for (x, y) in XSPRING_REAR:
        c = c.union(cyl(XSPRING_POST_D + 5, -REAR_PED, (x, y, Z_DECK_B)))
        c = c.union(cyl(XSPRING_POST_D, -(REAR_PED + 14), (x, y, Z_DECK_B)))
    zs = Z_DECK_B - PADDLE_Z0 - PADDLE_L + 5
    for sx in (-1, 1):
        bx = sx * (PADDLE_W / 2 + ROT_SPRING_INSTALLED + 4)
        c = c.union(box(8, 8, Z_DECK_B - (zs - 6), (bx, 15, zs - 6)))
        c = c.union(cyl(4.8, 4).rotate((0, 0, 0), (0, 1, 0), -90 * sx).translate((bx - sx * 4, 15, zs)))
    for sx in (-1, 1):
        for dy in (-SW_HOLE_PITCH / 2, SW_HOLE_PITCH / 2):
            x0 = sx * (ROT_SW_FACE + SW_H - 2.6)
            c = c.cut(box(3.0 + 2.3, 2.3, 6, (x0, 11 + SW_L / 2 + dy, Z_DECK_B - 5.9)).edges("|Z").fillet(1.1))
    return c.translate((0, HY, 0))


def boss_cap():
    b = cyl(BOSS_DIA, BOSS_H, (0, 0, Z_FRONT_IN))
    b = b.cut(cyl(SHAFT_DIA + 2 * CLEAR_SLIDE, BOSS_H + 2, (0, 0, Z_FRONT_IN - 1)))
    for a in (90, 210, 330):
        x, y = 13 * math.cos(math.radians(a)), 13 * math.sin(math.radians(a))
        b = b.cut(cyl(M3_CLEAR, BOSS_H + 2, (x, y, Z_FRONT_IN - 1)))
        b = b.cut(cyl(M3_HEAD_D, 4, (x, y, Z_FRONT_IN + BOSS_H - 3.9)))
    for sx in (-1, 1):      # short posts: the boot's spring pockets come down to 10 mm above them at full push
        b = b.union(cyl(XSPRING_POST_D, 8, (sx * XSPRING_FRONT_R, 0, Z_FRONT_IN + BOSS_H)))
    # lock notch at +Y (towards the lock block), in the plate's groove plane
    b = b.cut(box(10.8, 8, 3.2, (0, BOSS_DIA / 2 - 4, Z_FRONT_IN - 0.1), (True, True, False)))
    return b.translate((0, HY, 0))


def sleeve_retainer():
    z = Z_CARR_BACK - SLEEVE_BOSS_H
    r = cyl(SLEEVE_BOSS_D, -3, (0, 0, z))
    r = r.cut(cyl(TAIL_SQ * 1.42 + 3, -5, (0, 0, z + 1)))
    for a in (210, 330):
        r = r.cut(cyl(M25_CLEAR, -5, (12.5 * math.cos(math.radians(a)), 12.5 * math.sin(math.radians(a)), z + 1)))
    return r.translate((0, HY, 0))


def sleeve():
    s = cyl(SLEEVE_OD, -(SLEEVE_BOSS_H - 0.6), (0, 0, Z_CARR_BACK - 0.3))
    s = s.union(box(PADDLE_W, PADDLE_R, PADDLE_L, (0, 0, Z_DECK_B - PADDLE_Z0 - PADDLE_L), (True, False, False)))
    s = s.cut(cq.Workplane("XY").rect(TAIL_SQ + 2 * CLEAR_SLIDE, TAIL_SQ + 2 * CLEAR_SLIDE).extrude(-40).translate((0, 0, Z_CARR_BACK + 2)))
    return s.translate((0, HY, 0))


# --------------------------------------------------------------- handle ----
def boot():
    """Black escutcheon disc + skirt + stepped boot (five rings), one part.
    Print disc-down."""
    z = HUB_GAP + DISC_T
    b = None
    for (d, hgt) in BOOT_STEPS:
        ring = cyl(d, hgt, (0, 0, z)).faces(">Z").edges().chamfer(0.8)
        b = ring if b is None else b.union(ring)
        z += hgt
    disc = cyl(DISC_D, DISC_T, (0, 0, HUB_GAP)).faces(">Z").edges().chamfer(1.0)
    skirt = cyl(BOOT_BASE_D - 2, -(HUB_GAP - 2), (0, 0, HUB_GAP))
    b = b.union(disc).union(skirt)
    top = Z_BOOT_TOP
    b = b.cut(cyl(BOOT_ID, (top - 6) - 1, (0, 0, 1)))                   # cavity to 6 mm below the top
    b = b.cut(cyl(SHAFT_DIA + 0.2, 8, (0, 0, top - 7)))                   # shaft bore through the top wall
    for sx in (-1, 1):
        b = b.cut(cyl(COMP_SPRING_OD + 1.2, 2.5, (sx * XSPRING_FRONT_R, 0, top - 6 - 2.4)))
    b = b.cut(cyl(2.9, 60, (-30, 0, top - 3), "X"))                      # cross pin
    return b.translate((0, HY, 0))


def shaft():
    """Round shaft with the square tail; grip socket in the top.  Print standing."""
    top = Z_BOOT_TOP
    s = cyl(SHAFT_DIA, top - (Z_CARR_BACK - 2), (0, 0, Z_CARR_BACK - 2))
    s = s.union(cq.Workplane("XY").rect(TAIL_SQ, TAIL_SQ).extrude(-TAIL_LEN).translate((0, 0, Z_CARR_BACK - 2)))
    s = s.cut(cyl(M3_INSERT, 8, (0, 0, Z_CARR_BACK - 2 - TAIL_LEN - 0.1)))
    s = s.cut(cq.Workplane("XY").rect(TAIL_SQ + 0.3, TAIL_SQ + 0.3).extrude(-14).translate((0, 0, top + 0.1)))
    s = s.cut(cyl(2.9, 60, (-30, 0, top - 3), "X"))
    return s.translate((0, HY, 0))


def spindle(length, dia):
    """Body of revolution along X: the flight grip's crossbar, a spindle that is
    full diameter over the middle third and tapers to blunt points."""
    L, R = length / 2, dia / 2
    pts = [(-L, 0), (-L + 1.5, 0.22 * R), (-L * 0.72, 0.62 * R), (-L * 0.45, 0.92 * R), (0, R),
           (L * 0.45, 0.92 * R), (L * 0.72, 0.62 * R), (L - 1.5, 0.22 * R), (L, 0)]
    return cq.Workplane("XY").spline(pts, includeCurrent=False).close().revolve(360, (0, 0, 0), (1, 0, 0))


def grip():
    """Gray T-grip: spindle crossbar on a round stem, square peg below.  The bar
    lies along the box (Y), as on the flight unit; the peg has cross-pin holes
    both ways, so the grip can also be fitted with the bar across the box for
    use on the tilt stand.  Print lying on its back (bar and stem on the bed)."""
    z0 = Z_BOOT_TOP
    zc = z0 + GRIP_STEM_H + GRIP_BAR_D / 2
    bar = spindle(GRIP_BAR_LEN, GRIP_BAR_D).rotate((0, 0, 0), (0, 0, 1), 90).translate((0, 0, zc))
    stem = (cq.Workplane("XY").circle(GRIP_STEM_D / 2).workplane(offset=zc - z0).circle(GRIP_STEM_D / 2 + 1).loft()
            .translate((0, 0, z0)))
    g = bar.union(stem)
    g = g.union(cq.Workplane("XY").rect(TAIL_SQ, TAIL_SQ).extrude(14).translate((0, 0, z0 - 14)))
    g = g.cut(cyl(2.9, 60, (-30, 0, z0 - 3), "X"))
    g = g.cut(cyl(2.9, 60, (0, -30, z0 - 3), "Y"))     # same pin, grip turned 90 degrees
    return g.translate((0, HY, 0))


def tail_disc():
    d = cyl(TAIL_DISC_D, -TAIL_DISC_T, (0, 0, Z_DISC_F)).edges().chamfer(0.8)
    d = d.cut(cq.Workplane("XY").rect(TAIL_SQ + 0.3, TAIL_SQ + 0.3).extrude(-TAIL_DISC_T + 1.5).translate((0, 0, Z_DISC_F + 0.1)))
    d = d.cut(cyl(M3_CLEAR, -TAIL_DISC_T - 1, (0, 0, Z_DISC_F + 0.5)))
    d = d.cut(cyl(M3_HEAD_D, 2.5, (0, 0, Z_DISC_B - 0.1)))
    for (x, y) in XSPRING_REAR:
        d = d.cut(cyl(COMP_SPRING_OD + 1.2, -2.5, (x, y, Z_DISC_F + 0.1)))
    return d.translate((0, HY, 0))


def lock_slider():
    """Bar in the groove inside the front plate; the thumb block passes through
    the plate slot and sits over it, offset to the right like the flight unit's
    lock.  Block at the far end of the slot = ARM (tongue clear of the boss cap),
    pushed towards the handle = LOCK (tongue in the cap's notch)."""
    y_tip = HY + BOSS_DIA / 2 + 6          # tongue tip, unlocked
    y_top = LOCK_SLOT_Y + 8.3 + 10
    s = box(10, y_top - y_tip, 2.4, (0, (y_tip + y_top) / 2, Z_FRONT_IN + 0.1), (True, True, False))
    neck = box(10, 8, FRONT_T + 0.5, (0, LOCK_SLOT_Y + 8.3 - 4, Z_FRONT_IN + 0.1), (True, True, False))
    bw, bl, bh = LOCK_BLOCK
    blk = box(bw, bl, bh, (LOCK_BLOCK_X, LOCK_SLOT_Y + 8.3 - 4, 0.3), (True, True, False)).edges(">Z").chamfer(1.0)
    return s.union(neck).union(blk)


def tilt_stand():
    """25-degree hollow wedge with a dovetail rail that slides into the socket
    under the housing, so the handle points up at the user on a desk."""
    ang, L, W = 25, 115.0, HOUSING_W
    H = L * math.tan(math.radians(ang))
    outer = cq.Workplane("YZ").polyline([(0, 0), (L, 0), (L, H)]).close().extrude(W / 2, both=True)
    inner = (cq.Workplane("YZ").polyline([(10, 4), (L - 10, 4), (L - 10, (L - 10) * math.tan(math.radians(ang)) - 10)])
             .close().extrude(W / 2 - 8, both=True))
    stand = outer.cut(inner)
    rail = (cq.Workplane("XZ").polyline([(-9.7, -0.5), (9.7, -0.5), (13.5, 6.6), (-13.5, 6.6)]).close()
            .extrude(-64))                                               # along +Y, standing on z = 0
    rail = (rail.rotate((0, 0, 0), (1, 0, 0), ang)                       # up the slope
            .translate((0, 25 * math.cos(math.radians(ang)), 25 * math.sin(math.radians(ang)))))
    return stand.union(rail)


PARTS = {
    "thc_front_plate": front_plate,
    "thc_front_body": front_body,
    "thc_rear_body": rear_body,
    "thc_connector_boss": connector_boss,
    "thc_carriage": carriage,
    "thc_boss_cap": boss_cap,
    "thc_sleeve": sleeve,
    "thc_sleeve_retainer": sleeve_retainer,
    "thc_boot": boot,
    "thc_shaft": shaft,
    "thc_grip": grip,
    "thc_tail_disc": tail_disc,
    "thc_lock_slider": lock_slider,
    "thc_tilt_stand": tilt_stand,
}

if __name__ == "__main__":
    import sys
    report()
    only = sys.argv[1:]
    built = {}
    for name, fn in PARTS.items():
        if only and name not in only:
            continue
        built[name] = fn()
        export(built[name], name)
    if not only:
        asm = cq.Assembly()
        for name, shape in built.items():
            if name != "thc_tilt_stand":
                asm.add(shape, name=name)
        asm.export(os.path.join(OUT_DIR, "thc_assembly.step"))
    print("done")
