"""Extract labelled groups from an Orbiter MSHX1 mesh into OBJ files.
usage: python3 msh_extract.py mesh.msh outdir [label-substring ...]
"""
import sys, os, re

path, outdir = sys.argv[1], sys.argv[2]
wanted = [w.lower() for w in sys.argv[3:]]
os.makedirs(outdir, exist_ok=True)

with open(path, "r", errors="replace") as f:
    lines = f.read().split("\n")

i = 0
assert lines[0].strip().startswith("MSHX1")
ngroups = int(lines[1].split()[1])
i = 2
groups = []
for g in range(ngroups):
    label = f"group{g}"
    material = texture = None
    while True:
        tok = lines[i].split()
        if not tok:
            i += 1; continue
        if tok[0] == "LABEL":
            label = " ".join(tok[1:])
        elif tok[0] == "MATERIAL":
            material = int(tok[1])
        elif tok[0] == "TEXTURE":
            texture = int(tok[1])
        elif tok[0] == "GEOM":
            nv, nt = int(tok[1]), int(tok[2])
            i += 1
            break
        i += 1
    verts = []
    for k in range(nv):
        t = lines[i + k].split()
        verts.append((float(t[0]), float(t[1]), float(t[2])))
    i += nv
    tris = []
    for k in range(nt):
        t = lines[i + k].split()
        tris.append((int(t[0]), int(t[1]), int(t[2])))
    i += nt
    groups.append((label, material, texture, verts, tris))

for label, material, texture, verts, tris in groups:
    if wanted and not any(w in label.lower() for w in wanted):
        continue
    xs = [v[0] for v in verts]; ys = [v[1] for v in verts]; zs = [v[2] for v in verts]
    print(f"{label:34s} v={len(verts):6d} t={len(tris):6d} mat={material} tex={texture} "
          f"x[{min(xs):7.3f},{max(xs):7.3f}] y[{min(ys):7.3f},{max(ys):7.3f}] z[{min(zs):7.3f},{max(zs):7.3f}]")
    safe = re.sub(r"[^A-Za-z0-9_]+", "_", label)
    with open(os.path.join(outdir, safe + ".obj"), "w") as o:
        for v in verts:
            o.write(f"v {v[0]} {v[1]} {v[2]}\n")
        for t in tris:
            o.write(f"f {t[0]+1} {t[1]+1} {t[2]+1}\n")

# materials / textures tables, for colours
rest = "\n".join(lines[i:])
m = re.search(r"MATERIALS\s+(\d+)", rest)
if m:
    n = int(m.group(1))
    start = rest.index(m.group(0)) + len(m.group(0))
    names = rest[start:].split("\n")[1:n + 1]
    print("materials:", names[:60])
t = re.search(r"TEXTURES\s+(\d+)", rest)
if t:
    n = int(t.group(1))
    start = rest.index(t.group(0)) + len(t.group(0))
    print("textures:", rest[start:].split("\n")[1:n + 1][:60])
