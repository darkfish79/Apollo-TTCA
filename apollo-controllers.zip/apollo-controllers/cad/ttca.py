"""Apollo LM Thrust/Translation Controller Assembly (TTCA) replica, revision 9 -
exterior proportioned to four auction photographs of a Grumman LDW300-21800
flight-type unit (two direct side views for the body's profile, a face-on and
a front-right view for the face), with the NASSP (Project Apollo for Orbiter)
LM cockpit mesh behind the mechanism's layout; without the electrical
connector on top (USB socket flush in the back wall instead) and with a
flexible TPU bellows.

Two CAD frames are used:

  WORLD  X = right (seen from the user's seat), Y = up, Z = towards the user.
         Y = 0 is the desk; the back wall is at Z = 0.  The housing, lever,
         friction knob, nameplate, vent plate and bottom plate are modelled here.

  LOCAL  the handle frame: the pitch axle is the origin, X = world X minus
         HANDLE_X (the handle sits 15.5 mm left of the body centre: the ring's
         left edge 11.5 mm from the body's edge), z' = handle axis (towards the
         knob, i.e. up-and-towards-the-user at TILT degrees above horizontal),
         y' = perpendicular (up-and-back).  The whole mechanism, the boot, the
         band and the placards are modelled here and placed with M().

Exterior
  body      wedge 197 wide (the catalogued 7.75 in; the face-on photograph is
            as wide as it is tall) x 203 tall x 124 deep at the base (side
            photographs, scaled to the catalogued 8 in): vertical back wall to
            103, a 24 deg chamfer up to a 38 mm flat top with the nameplate and
            four slotted screws; 1.5 mm edge radii; grooves for the orange
            gasket seams round the side panels; on the left wall a faint 62 mm
            circle and, low near the back, a square white vent plate in a
            frame: a separate part whose 23 mm fan wheel of 22 swept blades
            has open slots between the blades (ttca_vent_plate).
  panel     the front is one formed 2 mm sheet standing proud of the box on its
            gasket: the face inclined TILT (22.8 deg) from the vertical for
            128 mm, bending on an 8 mm radius into a vertical lower face 85 mm
            up, which sets back 8 mm into the base on two gentle arcs.  Five
            open holes in the face and six along the lower face, as
            photographed.  Light gray.
  bellows   pale-blue TPU boot: a squat cone (photographs) 116 mm across at the
            face, only 39 mm tall to the shoulder and 47 to its collar on the
            stem guide, with twelve sharp fins on its outside, clamped by a
            12.5 mm wide, 143 mm ring with twelve screws.  The ring's top is
            13 mm below the face's top edge, its left edge 11.5 mm from the
            body's left edge (as asked), and its bottom 28 mm past the crease,
            where it sits on a flat pad and passes behind the friction knob as
            on the flight unit.  Printed flange-down.
  handle    11 mm stem, light-gray prolate-spheroid knob 62 x 24 mm with its
            long axis in the face plane, retaining screw in a round recess
            (the auctioned unit's handle and boot are reproductions, so these
            keep the NASSP proportions).
  friction  six-lobe star knob on the vertical lower face just below the
            crease, axis horizontal, on a short skirt; curved black FRICTION
            placard beside it; its M4 screw works a wedge brake on the cradle.
  selector  one straight flat strip seen from the side: a gray 21 mm bar on the
            right wall from a 26 mm hub (on a 36 mm gasket ring) near the
            back-bottom corner, climbing at 39.5 deg under a leaf-shaped guide
            plate (LDW300-11877-1); past the plate a chrome band of the same
            width lies on the bar's outer face, screwed to it, and once clear
            of the face edge curves 90 deg in towards the T-handle on a 10 mm
            radius, its arm level across the face to a rounded tip beside the
            black THROTTLE / JETS placard: band up = THROTTLE, down = JETS.
            Nothing hangs below the hub: the crank drive is an arm on the
            shaft's inboard end.

Mechanism (local frame)
  pitch (LM X)  cradle on two stub axles through the origin, +/-PITCH_STOP;
                left stub -> coupler -> potentiometer on an internal bracket;
                right stub -> sector near the right wall: V-notch for the JETS
                pawl, bump for the soft-stop plunger; brake flange on the
                cradle's right plate for the friction pad.
  yaw   (LM Y)  yaw block on two pins through the origin (a true gimbal),
                +/-YAW_STOP, spring centred, two lever switches on the cradle.
  slide (LM Z)  D-stem in the block through a double-acting spring, +/-SLIDE,
                flag screw pressing two lever switches on the block.
  JETS/THROTTLE rotary pawl (bell crank) behind the sector, spring-loaded into
                the notch, driven by the pin on the lever's crank arm running
                in a radial slot in the crank's control arm.

python3 ttca.py -> ../stl/ttca_*.stl and .step
"""
import math
import cadquery as cq
from common import *

# ======================================================= world-frame body ==
BODY_W = 197.0                                  # the catalogued 7.75 in: face-on, the body is as wide as it is tall
WALL_T = 4.0
# Side profile read from the two direct side photographs of the flight-type unit (revision 8), scaled to
# its catalogued 8 in height.  The front is one formed sheet (the panel) standing PLATE_T proud of the box
# on its gasket: the inclined face from the top edge down to a soft crease, a vertical lower face, and a
# gentle S-shaped set-back into the base.  Points are (Z, Y) on the PANEL's outer surface.
BODY_H = 203.0                                  # top face
BACK_TOP_Y = 103.0                              # the back wall is vertical up to here, then the chamfer to the top
TOP_Z0, TOP_Z1 = 44.0, 81.5                     # the flat top: chamfer's top end .. the panel's top edge
CREASE = (131.0, 85.0)                          # where the inclined face and the vertical lower face would meet
LOWER_Z = 131.0                                 # the vertical lower face
JOGGLE_Y1, JOGGLE_Y0 = 45.0, 10.0               # between these heights the lower face steps back ...
JOGGLE_IN = 8.5                                 # ... by this much, on two tangent arcs (JOGGLE_R)
JOGGLE_R = 38.0
PLATE_T = 2.0                                   # panel thickness (it stands this proud of the box)
PLATE_CREASE_R = 8.0                            # outer radius of the crease bend
PLATE_EDGE_IN = 1.0                             # the panel's side edges, inside the body's sides
FACE_TOP = (TOP_Z1, BODY_H)                     # the panel's top edge
FACE_BOT = CREASE
TILT = math.degrees(math.atan2(FACE_BOT[0] - FACE_TOP[0], FACE_TOP[1] - FACE_BOT[1]))   # 22.8 deg from vertical
CT, ST = math.cos(math.radians(TILT)), math.sin(math.radians(TILT))
FACE_LEN = math.hypot(FACE_BOT[0] - FACE_TOP[0], FACE_TOP[1] - FACE_BOT[1])             # 128 along the slope
AXIS_FROM_TOP = 84.5                            # handle axis down the slope from the top edge: the ring's top 13 mm below it, its bottom 28 mm past the crease, passing behind the friction knob as on the flight unit (as asked)
FACE_C = (FACE_TOP[0] + AXIS_FROM_TOP * ST, FACE_TOP[1] - AXIS_FROM_TOP * CT)          # (Z, Y) where the handle axis leaves the panel
FACE_HALF = FACE_LEN / 2
# the box behind the panel: its front is the panel's inner surface (sharp corners; the panel's bends are filled)
_TOP_IN = (FACE_TOP[0] - PLATE_T * CT, FACE_TOP[1] - PLATE_T * ST)
BOX_TOP_Z = _TOP_IN[0] + (_TOP_IN[1] - BODY_H) * ST / CT                                 # box's top-front corner (Z) at Y = BODY_H
BOX_CREASE_Y = _TOP_IN[1] - (LOWER_Z - PLATE_T - _TOP_IN[0]) * CT / ST                   # box's crease corner (Y) at Z = LOWER_Z - PLATE_T
BASE_D = LOWER_Z - JOGGLE_IN - PLATE_T                                                   # the box's base depth (120.5)
PROFILE = [(0, 0), (BASE_D, 0), (BASE_D, JOGGLE_Y0), (LOWER_Z - PLATE_T, JOGGLE_Y1), (LOWER_Z - PLATE_T, BOX_CREASE_Y),
           (BOX_TOP_Z, BODY_H), (TOP_Z0, BODY_H), (0, BACK_TOP_Y)]
HANDLE_X = -15.5                                # handle axis left of the body centre: the ring's left edge 11.5 mm from the body's edge (as asked; NASSP has -9.2)
AXLE_DEPTH = 25.0 + PLATE_T                     # gimbal behind the panel's surface (25 behind the box's front)
AZ, AY = FACE_C[0] - AXLE_DEPTH * CT, FACE_C[1] - AXLE_DEPTH * ST
FACE_Z = AXLE_DEPTH                             # local z' of the panel's outer surface
X_IN = BODY_W / 2 - WALL_T                      # inner face of the side walls (94.5)
XW_R = X_IN - HANDLE_X + 1.0                    # local x just inside the right wall (brackets overlap it 1 mm)
XW_L = -X_IN - HANDLE_X - 1.0                   # local x just inside the left wall
EDGE_R = 1.5                                    # body edge radius

SCREW_XS = ()                                   # the face-on photograph shows no screw row on the face below its top edge
TOP_SCREW_YL = AXIS_FROM_TOP - 5.0              # (local y' of that row, if one is wanted)
TOP_FACE_SCREWS = ((-54.0, 60.0), (-8.0, 60.0), (8.0, 60.0), (54.0, 60.0))   # (X, Z) slotted screws on the flat top (two show in the face-on photograph; mirrored)
LOWER_HOLE_Y = 20.0                              # row of open mounting holes on the lower face (photographs)
LOWER_HOLE_XS = (-71, -41, -12, 18, 49, 73)
LOWER_HOLE_D = 4.5
FACE_HOLES = ((-65.5, 67.5), (-35.0, 67.5), (57.5, 67.5), (77.0, 67.5), (98.5, 25.5))   # open holes in the face, local (x, y'): the four near the top corners where the face-on photograph has them (17 mm below the top edge), one beside the placard's top (all fixed on the face while the handle axis moved)
RING_PAD_R = 73.0                               # flat pad the ring's lower part sits on where it overhangs the crease (photographs); the friction knob's skirt stands just outside it
FACE_HOLE_SMALL_D = 4.0
USB_X = -45.0                                   # Pro Micro cradle / USB slot centre, world X, on the back wall
USB_SLOT = (18.6, 8.0, 6.0)                     # slot width, bottom Y, height through the back wall
NAMEPLATE = (60.0, 22.0, 1.2)                   # width (X), depth (Z), thickness, centred on the top face
NAMEPLATE_Z = (TOP_Z0 + BOX_TOP_Z) / 2
FEET = ((-60, 20), (60, 20), (-60, 100), (60, 100))   # stick-on rubber feet recesses (X, Z)
# left wall (photographs): a faint flush circle high up, and low down a square white vent plate - a separate
# part (ttca_vent_plate) in a square frame on the wall, with a round fan-wheel pattern of 22 swept blades
# whose slots are open vents into the housing
LEFT_CIRCLE = (57.0, 123.0, 62.0)               # (Z, Y, diameter) of the circular outline, a 0.4 mm groove
LEFT_VENT = (63.5, 31.0)                        # (Z, Y) centre of the vent plate: 63.5 mm from the back wall, 31 mm up (left-side photograph)
VENT_PLATE_W, VENT_PLATE_T = 39.0, 2.0          # the white plate, square, and its thickness
VENT_PLATE_R = 1.5                              # its corner radius
VENT_FRAME_W, VENT_FRAME_PROUD = 43.5, 1.0      # the square frame on the wall round it (part of the housing): outer size, how far it stands proud
VENT_POCKET_D = 2.0                             # the plate's pocket, from the frame's top down (1 mm into the wall): the plate sits flush with the frame
VENT_FAN_D = 23.0                               # the fan wheel: its outer diameter ...
VENT_HUB_D = 5.5                                # ... its hub ...
VENT_BLADES = 22                                # ... blades (the photograph shows 22), swept clockwise seen from outside ...
VENT_SWEEP_DEG_MM = 1.3                         # ... by this many degrees per mm of radius
VENT_SLOT_R = (6.5, 11.5)                       # the slots between the blades are open from this radius out to the wheel's rim; in from it
VENT_GROOVE_DEPTH = 0.8                         # they go on as grooves this deep to the hub (the slots would be too narrow to print)
VENT_BLADE_T = (0.5, 0.9, 1.4)                  # blade thickness at the hub, where the open slots begin, and at the rim
VENT_FAN_RECESS = 0.4                           # the wheel sits this far below the plate's face
VENT_SCREWS = 16.0                              # four M2 screws at (+/-16, +/-16) from the centre, into pilot holes in the wall
VENT_HOLE_D = VENT_FAN_D + 0.5                  # the hole through the wall behind the wheel

# friction knob: on the vertical lower face just below the crease, axis horizontal (side photographs);
# world frame.  Its x keeps the brake rod inside the brake tunnel.
KNOB_WX, KNOB_WY = HANDLE_X + 54.5, 73.0        # world X, Y of the knob axis on the lower face (Z = LOWER_Z): 39 mm right of the body's centre, 73 up (photographs); the skirt clears the ring's pad
STAR_D, STAR_VALLEY_D, STAR_H = 38.0, 28.0, 10.0   # about 38 across in the face-on photograph
STAR_LOBE_D = 13.0
STAR_SKIRT = (9.0, 7.0)                         # skirt diameter, height; its base 4 mm off the face
KNOB_STANDOFF = 4.0

LEVER_PIVOT = (23.0, 80.0)                      # (Z, Y) of the pivot on the right wall, near the back-bottom corner (side photograph)
LEVER_T, LEVER_W = 3.0, 21.0                    # flat bar: thickness (X), width (the band is the same width)
LEVER_RISE_DEG = 39.5                           # bar climbs towards the front at this angle at neutral (46.5 at THROTTLE, as photographed)
LEVER_HUB_D = 26.0                              # round pivot hub on the bar, central screw, four cosmetic holes
PIVOT_RING_D, PIVOT_RING_T = 36.0, 1.5          # gasket-ring boss on the wall under the hub
LEVER_X0 = BODY_W / 2 + PIVOT_RING_T + 0.5      # inner face of the bar
# the lever drives the selector crank from INSIDE the wall: a crank arm on the shaft's inboard end carries a
# pin that works the pawl crank's slotted control arm (nothing but the hub and bar show outside)
LEVER_ARM_T, LEVER_ARM_W = 3.0, 10.0
LEVER_ARM_ELBOW = (-44.0, -64.0)                # (y', z') the arm doglegs here to pass below the crank's pivot lug and under the detent guide
CRANK_SWING = 17.0                              # degrees the pawl crank turns between engaged (JETS) and THROTTLE
LOST_MOTION = 2.0                               # mm of free pin travel at the JETS end, so the lever reaches its detent
# chrome band: a strip of the bar's width lying on the bar's outer face (from the side, bar and band read as
# one straight flat piece), screwed to the bar's end past the guide plate; once clear of the face edge it
# curves 90 degrees in towards the handle on a gentle radius, and the flat arm runs level across the face to a
# rounded tip above the THROTTLE/JETS placard.
BAND_W, BAND_T = 21.0, 2.0
BAND_ROOT_ZL = (24.0, 30.5)                     # the straight root on the bar, just past the guide plate's front edge: rear edge .. start of the bend (local z' on the bar's centreline)
BAND_BEND_R = 10.0                              # centreline radius of the bend
BAND_SKEW_DEG = 0.0                             # the bend line's angle across the strip: 0 = a square bend, level arm
BAND_FACETS = 24                                # flat facets the bend is built from (the STL would be faceted anyway)
BAND_TIP_X = 72.5                               # local x of the arm's rounded tip (its inner corner): 41.5 mm from the face's right edge, at the ring's edge, beside the THROTTLE/JETS placard
BAND_TIP_R = 4.0
BAND_SCREWS = ((27.2, 5.5), (27.2, -5.5))       # M2 screws through root and bar, side by side: (local z' on the bar's centreline, offset across the bar)
BAND_RIVETS = ((4.0, 5.5), (8.0, -6.0))         # cosmetic rivet heads on the tip: (back from the tip along the strip, offset across it)
DETENT_Z = 82.0                                 # detent bump on the bar's inner face, under the guide plate
DETENT_BLOCK_Z = 50.0                           # cosmetic block on the bar (the flight unit's detent housing)
GUIDE_CENTRE = (98.3, 109.9)                    # (Z, Y) centre of the leaf-shaped guide plate on the wall (side photograph, set 4 mm further from the face edge so the band root clears its top end at THROTTLE)
GUIDE_L, GUIDE_W0, GUIDE_BULGE = 124.0, 14.0, 3.0  # length along the face edge, width at the ends, extra width mid-way
GUIDE_T, GUIDE_GAP = 2.0, 0.4                   # plate thickness, clearance over the bar
GUIDE_SCREW_IN = 6.0                            # screw centres from the plate ends
PLACARD_T = 0.8                                 # black placards let into the face, white lettering
MODE_PLACARD = (84.0, 93.5, -37.5, 26.0)        # local x0, x1, y0, y1 of the THROTTLE / JETS placard (9.5 x 63.5 mm, face-on photograph): 20 mm from the face's right edge, clear of the ring, fixed on the face
FRICTION_PLACARD = (29.0, 40.0, 13.0, -13.0)    # r0, r1 about the knob axis, start / end angle (degrees), on the lower face (kept below the crease bend)

# ========================================================== local frame ==
PITCH_STOP = 28.0
SOFT_STOP = 20.0
YAW_STOP = 8.0
SLIDE = 6.0

AXLE_D = 8.0
CRADLE_X, CRADLE_T = 33.0, 6.0
CRADLE_Z0, CRADLE_Z1 = -32.0, 18.0
CRADLE_Y1 = 34.0
FLANGE_R, FLANGE_A0, FLANGE_A1 = 69.0, -88.0, -22.0   # brake flange sector on the right cradle plate (degrees from -y' towards +z'): the pad's footprint over the pitch travel, no more
FLANGE_TAIL = (-105.0, 66.0)                    # (angle, radius) of the sector's rear tip, drawn in so the flange clears the back chamfer at full pitch (7 mm) while the pad's face stays on it (3.5 mm in hand) at the other end of the travel

BLOCK_W, BLOCK_H = 36.0, 40.0
BLOCK_Z0, BLOCK_Z1 = -24.0, 24.0
YAW_PIN_D = 6.0
LID_T = 4.0
STEM_D, STEM_FLAT = 12.0, 1.5
STEM_ROUND_D = 11.0
CAVITY_D, CAVITY_L, WASHER_T = 20.0, 20.0, 3.0
FLAG_Z = BLOCK_Z0 + 32.0
LEVER_PROUD = 4.0
CAP_SCREWS = ((13.0, -12.0), (-13.0, -12.0))     # (x, y') of the stem-guide screws through the block
CRADLE_SPHERE_R = 44.0                          # the cradle's front is kept inside this sphere about the gimbal (clear of the Ø80 face hole's wall at any pitch)

# stem guide (moves with the handle) and the TPU boot
TUBE_OD, TUBE_ID = 18.0, 13.0
BOOT_T = 1.0                                    # wall of the boot's cone
# the boot (photographs, and the sizing asked for): a squat cone of thin sharp fins, 116 mm across at the
# face and only 39 mm tall to its shoulder, to a small collar; the fins are a 1 mm cone wall (leaning 48
# degrees, which prints) carrying solid wedge fins whose undersides lean BOOT_LEDGE_DEG from the axis (the
# steepest overhang TPU prints).
BOOT_R0, BOOT_Z0 = 55.0, FACE_Z                 # cone wall's outer radius at the face; the fins stand BOOT_FIN_D further out
BOOT_FIN_D = 3.0
BOOT_PLEATS = 12                                # fins (the photographs show about twelve)
BOOT_CONE_H = 39.0                              # height of the cone to its shoulder ...
BOOT_CONE_R1 = 11.0                             # ... where its outer radius is this (the cone leans atan((R0 - R1) / H) = 48 deg from the axis)
BOOT_Z1 = FACE_Z + BOOT_CONE_H
BOOT_LEDGE_DEG = 65.0                           # fin undersides, from the axis (print overhang)
BOOT_COLLAR_R, BOOT_COLLAR_Z0, BOOT_COLLAR_Z1 = TUBE_OD / 2 + 0.9, FACE_Z + 41.0, FACE_Z + 47.0
TUBE_Z1 = BOOT_COLLAR_Z1 + 1.8                  # top of the guide tube; the flare under its top retains the boot collar
TUBE_FLARE_D = 21.5
BOOT_CREST_R, BOOT_VALLEY_R = 0.6, 0.4          # fillets on the fin crests and the valleys
BOOT_FLANGE_R0, BOOT_FLANGE_R1, BOOT_FLANGE_T = 40.0, 71.0, 1.5
RING_R0, RING_R1, RING_T = 59.0, 71.5, 2.0      # clamp ring on the face: 143 across, 12.5 wide, twelve screws; its top 13 mm from the face's top edge, its left edge 11.5 mm from the body's edge, its bottom 28 mm past the crease on the pad, behind the friction knob
RING_SCREW_R = 65.25
RING_SCREWS = tuple(27.0 + 30 * k for k in range(12))
FACE_HOLE_D = 80.0
FACE_RECESS_R = 72.0

KNOB_Z = 124.0                                  # knob centre on the stem
KNOB_AX = (12.0, 31.0)                          # spheroid semi-axes (across, long)
STEM_Z0 = BLOCK_Z0 - 10.0

SECTOR_R, SECTOR_T, SECTOR_SPAN, SECTOR_X0 = 45.0, 8.0, 72.0, 78.0
BEARING_R_X = (72.0, 76.0)                      # right bearing plate
BEARING_L_X = (-46.0, -42.0)                    # left bearing plate (coupler runs in it)
POT_PLATE_X = (-62.0, -58.0)
COUPLER_X = (-55.0, -41.0)
STUB_R = (24.0, 87.0)
STUB_L = (-24.0, -47.0)
DETENT_D, DETENT_X, DETENT_DY = 5.0, 86.5, -9.0
PAWL_X = (77.7, 81.3)                           # crank thickness (lugs at 77.5 / 81.5)
CRANK_PIVOT = (-28.0, -50.0)                    # (y', z'): tip arm straight up to the notch
CRANK_CTRL = (25.0, 45.0)                       # control arm: length, degrees below the z' axis (down-and-forward from the pivot)
CRANK_ARM_W = 6.0
PIN_D = 3.0
SPRING_SEAT = (-20.0, -72.0)                    # (y', z') crank spring: boss on the frame behind the tip arm, spring pushes the tip arm forward
SW_ZL = -67.8                                   # mode switch mounting holes (local z'); the crank's foot stops 0.9 mm short of the plunger face at THROTTLE

# friction brake, world frame: the knob's M4 screw on the vertical lower face pushes a rod horizontally (-Z)
# down a tunnel to a wedge slider that forces the pad (-X) onto the cradle's brake flange
BRAKE_X = (KNOB_WX - 6.0, KNOB_WX + 11.0)       # tunnel block, world X, round the knob's rod; the pad reaches back from it to the cradle flange at HANDLE_X + 39
BRAKE_Y = (KNOB_WY - 9.5, KNOB_WY + 9.5)
BRAKE_Z = (30.0, LOWER_Z - 4.0)                 # tunnel block, world Z (back .. the lower face's inside): the pad sits well back, where the cradle's flange stays under it over the whole pitch travel
BRAKE_WALL_Z0 = 46.0                            # the tunnel's +X wall starts here (the mode-switch bracket is behind and beside it)
SLIDER_X = (KNOB_WX - 1.0, KNOB_WX + 6.4)
SLIDER_Y = (KNOB_WY - 5.2, KNOB_WY + 5.2)
SLIDER_Z = (36.0, 66.0)                         # slider at rest (pushed back by the rod from the front)
PAD_WZ = (46.0, 54.0)                           # the pad, world Z (its centre is on the cradle flange, 66 degrees below-behind the gimbal)
ROD_D = 6.0


# -------------------------------------------------------------- helpers --
def M(s):
    """Local (handle) frame -> world frame."""
    return s.rotate((0, 0, 0), (1, 0, 0), -TILT).translate((HANDLE_X, AY, AZ))


def W2L(s):
    """World frame -> local (handle) frame: the inverse of M()."""
    return s.translate((-HANDLE_X, -AY, -AZ)).rotate((0, 0, 0), (1, 0, 0), TILT)


def to_local(Y, Z):
    dy, dz = Y - AY, Z - AZ
    return dy * CT - dz * ST, dy * ST + dz * CT          # (y', z')


def to_world(yl, zl):
    return AY + yl * CT + zl * ST, AZ - yl * ST + zl * CT   # (Y, Z)


def yz_prism(pts, x0, x1):
    """Prism from a (y, z) polygon between x0 and x1."""
    return cq.Workplane("YZ").polyline(pts).close().extrude(x1 - x0).translate((x0, 0, 0))


def lbox(x0, x1, y0, y1, z0, z1):
    return box(x1 - x0, y1 - y0, z1 - z0, ((x0 + x1) / 2, (y0 + y1) / 2, z0))


def d_hole(length, x0, d=AXLE_D + 0.3):
    hole = cyl(d, length, (x0, 0, 0), "X")
    flat = box(length + 2, 4, d + 2, (x0 + length / 2, d / 2 - 1 + 2 + 0.15, -d / 2 - 1))
    return hole.cut(flat)


def arc_text(text, r, a0, a1, size, depth, kind="bold", tops_out=False):
    """Letters placed along an arc (degrees, counter-clockwise from +X) from a0
    to a1; letter tops towards the centre (lower arc of a dial) or outwards
    (upper arc, give a0 > a1 so it reads left to right)."""
    n = len(text)
    out = None
    for i, ch in enumerate(text):
        a = a0 + (a1 - a0) * (i + 0.5) / n
        t = cq.Workplane("XY").text(ch, size, depth + 0.1, kind=kind, halign="center", valign="center").translate((0, 0, -depth))
        t = t.rotate((0, 0, 0), (0, 0, 1), a - 90 if tops_out else a + 90)
        t = t.translate((r * math.cos(math.radians(a)), r * math.sin(math.radians(a)), 0))
        out = t if out is None else out.union(t)
    return out


# ---- selector kinematics (local frame) ----
# The lever's shaft carries a crank arm inside the wall from the hub H to the pin P; the pin works a radial
# slot in the pawl crank's control arm (pivot C).  THROTTLE = bar up = the hub turns by -LEVER_SWING = the
# pin moves up and forward = the control arm is pushed round so the tip withdraws from the sector notch.
HUB_LOCAL = to_local(LEVER_PIVOT[1], LEVER_PIVOT[0])                     # (y', z') of the lever's pivot
_ca = math.radians(CRANK_CTRL[1])
CRANK_END = (CRANK_PIVOT[0] - CRANK_CTRL[0] * math.sin(_ca), CRANK_PIVOT[1] + CRANK_CTRL[0] * math.cos(_ca))   # pin at the lever's neutral
LEVER_ARM_R = math.hypot(CRANK_END[0] - HUB_LOCAL[0], CRANK_END[1] - HUB_LOCAL[1])


def pin_at(lever_deg):
    """(y', z') of the lever's pin with the lever turned lever_deg from neutral (+ = JETS, bar down)."""
    hy, hz = HUB_LOCAL
    dy, dz = CRANK_END[0] - hy, CRANK_END[1] - hz
    a = math.radians(lever_deg)
    return hy + dy * math.cos(a) - dz * math.sin(a), hz + dy * math.sin(a) + dz * math.cos(a)


def _rot2(v, deg):
    a = math.radians(deg)
    return (v[0] * math.cos(a) - v[1] * math.sin(a), v[0] * math.sin(a) + v[1] * math.cos(a))


def crank_angle(lever_deg, swing):
    """Pawl crank angle (degrees, negative = tip withdrawing) for a lever angle, with the slot's push wall
    through the pin's contact position for the given lever swing: the pin's centre rides 0.15 mm off the wall."""
    contact = swing - math.degrees(math.asin(LOST_MOTION / LEVER_ARM_R))
    cy, cz = pin_at(contact)
    py, pz = CRANK_PIVOT
    d = math.hypot(cy - py, cz - pz)
    n0 = (-(cz - pz) / d, (cy - py) / d)                                    # lateral unit at contact (crank at 0)
    P = pin_at(lever_deg)
    def lat(th):
        n = _rot2(n0, th)
        return (P[0] - py) * n[0] + (P[1] - pz) * n[1] + 0.15
    if lat(0.0) >= 0:
        return 0.0
    lo, hi = -80.0, 0.0
    for _ in range(60):
        mid = (lo + hi) / 2
        if lat(mid) < 0:
            hi = mid
        else:
            lo = mid
    return (lo + hi) / 2


def _solve_swing():
    lo, hi = 2.0, 20.0
    for _ in range(50):
        mid = (lo + hi) / 2
        if crank_angle(-mid, mid) > -CRANK_SWING:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


LEVER_SWING = _solve_swing()                                              # +/- degrees, JETS / THROTTLE
PIN_CONTACT_DEG = LEVER_SWING - math.degrees(math.asin(LOST_MOTION / LEVER_ARM_R))   # the pin meets the slot wall here (from JETS)
PIN_TRAVEL = LEVER_ARM_R * math.sin(math.radians(LEVER_SWING))           # either side of neutral
LEVER_PIN = tuple(reversed(to_world(*CRANK_END)))                         # (Z, Y) in the world frame


def report():
    print(f"tilt {TILT:.2f} deg, axle at X {HANDLE_X} Y {AY:.1f} Z {AZ:.1f}, face {FACE_LEN:.1f} along the slope, hole {FACE_HOLE_D:.1f}")
    print(f"friction knob axis at world X {KNOB_WX:.1f} Y {KNOB_WY:.1f} Z {LOWER_Z:.1f}")
    ky, kz = to_world(*CRANK_PIVOT); print(f"crank pivot world Y {ky:.1f} Z {kz:.1f}; hub local y' {HUB_LOCAL[0]:.1f} z' {HUB_LOCAL[1]:.1f}")
    print(f"lever arm {LEVER_ARM_R:.1f} mm to the pin at local y' {CRANK_END[0]:.1f} z' {CRANK_END[1]:.1f}; pin travel +/-{PIN_TRAVEL:.1f}, lever swing +/-{LEVER_SWING:.1f} deg, crank {crank_angle(-LEVER_SWING, LEVER_SWING):.1f} deg at THROTTLE")
    py, pz = CRANK_PIVOT
    print(f"crank: tip arm {math.hypot(py, -SECTOR_R + 3.5 - pz):.1f}, control arm {CRANK_CTRL[0]:.1f}; tip withdraws about {math.hypot(py, -SECTOR_R + 3.5 - pz) * math.sin(math.radians(CRANK_SWING)):.1f} mm at THROTTLE (needs > 4.5)")


# ================================================================ body ===
def bar_point(z):
    """(Y, Z) of the selector bar's centreline at world Z."""
    pz, py = LEVER_PIVOT
    return py + (z - pz) * math.tan(math.radians(LEVER_RISE_DEG)), z


def guide_axis():
    """Unit direction (dZ, dY) of the guide plate's long axis: up-and-back along the face edge."""
    return (-ST, CT)


def guide_centre():
    """(Z, Y) of the guide plate's centre on the wall."""
    return GUIDE_CENTRE


def guide_screw_pts():
    cz, cy = guide_centre()
    dz, dy = guide_axis()
    u = GUIDE_L / 2 - GUIDE_SCREW_IN
    return [(cz - u * dz, cy - u * dy), (cz + u * dz, cy + u * dy)]


def body_outline(inset=0.0, x_half=BODY_W / 2):
    w = cq.Workplane("YZ").polyline([(y, z) for (z, y) in PROFILE]).close()
    if inset:
        w = w.offset2D(-inset, "intersection")
    return w.extrude(x_half, both=True)


def ring_screw_pts():
    return [(RING_SCREW_R * math.cos(math.radians(a)), RING_SCREW_R * math.sin(math.radians(a))) for a in RING_SCREWS]


def ring_bosses():
    """Insert bosses inside the face for the eight boot-ring screws."""
    b = None
    for (x, y) in ring_screw_pts():
        c = cyl(8, 13, (x, y, FACE_Z - 13)).cut(cyl(M3_INSERT, 8.5, (x, y, FACE_Z - 7.9)))
        b = c if b is None else b.union(c)
    return b


def right_frame():
    """Everything that hangs off the right wall, local frame: bearing plate,
    stop fins, detent block + spring bridge, crank lugs, the crank spring's
    seat and the mode-switch bracket (the brake tunnel is brake_tunnel(), in
    the world frame); housing() clips it all to the body's outline."""
    xw = XW_R
    f = None
    def add(s):
        nonlocal f
        f = s if f is None else f.union(s)
    # bearing plate with two ribs back to the wall
    bx0, bx1 = BEARING_R_X
    add(lbox(bx0, bx1, -38, 38, -60, 20))                  # bearing plate, tied to the stop fins
    add(lbox(bx0, xw, -22, 22, 13, 17))                    # front rib: clear of the sector hub, meets the face wall
    # pitch hard-stop fins (also the rear ribs of the bearing plate): radial wedges from r 28 to 46, 6 mm
    # wide at the sector's rim, whose near (radial) face stands 1.5 degrees past the sector's edge at full
    # pitch; each has a gusset to the wall on its far side
    delta = math.degrees(math.atan2(3.0, SECTOR_R))        # half-width in degrees at the rim
    fin_c = SECTOR_SPAN / 2 + PITCH_STOP + 1.5 + delta     # the fin's centreline angle from -z' towards +y'
    for s in (-1, 1):
        a0, a1 = math.radians(s * (fin_c - delta)), math.radians(s * (fin_c + delta))
        wedge = [(28 * math.sin(a0), -28 * math.cos(a0)), (46 * math.sin(a0), -46 * math.cos(a0)),
                 (46 * math.sin(a1), -46 * math.cos(a1)), (28 * math.sin(a1), -28 * math.cos(a1))]
        gusset = (cq.Workplane("XY").polyline([(xw, 3 * s), (bx0, 3 * s), (xw, 17 * s)]).close().extrude(18)
                  .translate((0, 0, -46)).rotate((0, 0, 0), (1, 0, 0), s * fin_c))
        add(yz_prism(wedge, bx0, xw).union(gusset))
    # soft-stop detent plunger guide and spring bridge (the bridge reaches into the back wall; the guide
    # stops short of the lever's crank arm, which passes below it against the wall)
    add(lbox(82.5, xw, DETENT_DY - 7, DETENT_DY + 7, -63, -49))
    add(lbox(82.5, xw, DETENT_DY - 7, DETENT_DY + 7, -98, -87))
    add(cyl(3.6, 5, (DETENT_X, DETENT_DY, -87)))
    # crank pivot lugs: the inner one on the bearing plate, the outer one on the wall (nothing joins them
    # below the crank, whose control arm sweeps past the pivot there)
    py, pz = CRANK_PIVOT
    add(lbox(73.5, 77.5, py - 8, py + 5, pz - 6, pz + 6))
    add(lbox(81.5, xw, py - 8, py + 5, pz - 6, pz + 6))
    # crank spring seat behind the tip arm: a block off the back wall's brackets with a boss pointing
    # forward; the spring pushes the tip arm (and so the tip) forward into the notch
    sy, sz = SPRING_SEAT
    add(lbox(74, 82, sy - 6, sy + 6, sz - 6, sz))
    add(cyl(3.8, 3, ((PAWL_X[0] + PAWL_X[1]) / 2, sy, sz)))
    # mode-switch bracket off the bearing plate: the switch lies against the +X face of
    # the inner plate, plunger towards +z', pressed by the foot on the crank's tip arm
    add(lbox(62, bx0, -32, -28, -76, -58))                 # (from x 62: the brake slider runs just outboard of it)
    add(lbox(62, 66, -30, 2, -76, -58))
    return f


def right_frame_cuts():
    """Holes through the right-frame solids (local)."""
    c = cyl(AXLE_D + 0.4, 10, (BEARING_R_X[0] - 1, 0, 0), "X")
    c = c.union(cyl(DETENT_D + 0.4, 60, (DETENT_X, DETENT_DY, -70)))
    py, pz = CRANK_PIVOT
    c = c.union(cyl(PIN_D + 0.2, XW_R - 2 - 70, (70, py, pz), "X"))
    ey, ez = CRANK_END
    for dy in (-SW_HOLE_PITCH / 2, SW_HOLE_PITCH / 2):
        c = c.union(cyl(2.3, 8, (60, -10 + dy, SW_ZL), "X"))
    c = c.union(lbox(BEARING_R_X[0] - 1, BEARING_R_X[1] + 1, -16, -4, -62, -40))    # window for the crank's foot
    return c


def left_frame():
    """Left wall bracket, local frame: bearing plate for the coupler, pot plate."""
    xw = XW_L
    bx0, bx1 = BEARING_L_X
    f = cyl(48, bx1 - bx0, (bx0, 0, 0), "X")
    px0, px1 = POT_PLATE_X
    f = f.union(lbox(px0, px1, -16, 16, -31, 16))
    f = f.union(lbox(xw, bx1, -22, 22, -31, -27))            # plate to the wall, behind the cradle's sweep
    f = f.union(lbox(bx0 - 1, bx1, -12, 12, -31, -22))       # tab joining the bearing disc to that plate
    return f


def left_frame_cuts():
    c = cyl(16.6, 10, (BEARING_L_X[0] - 1, 0, 0), "X")
    c = c.union(cyl(18.0, BEARING_L_X[1] - XW_L + 2, (XW_L - 2, 0, 0), "X").cut(lbox(POT_PLATE_X[0] - 0.5, POT_PLATE_X[1] + 0.5, -20, 20, -20, 20)))
    c = c.union(cyl(POT_BUSH_D, 10, (POT_PLATE_X[0] - 1, 0, 0), "X"))
    c = c.union(cyl(2.8, 10, (POT_PLATE_X[0] - 1, -9.5, 0), "X"))     # pot anti-rotation lug
    return c


def screw_head(at, axis="Z", slot=False):
    """Screw head look: 5.5 mm dome with a hex socket, or a slotted pan head."""
    s = cyl(5.5, 1.8, (0, 0, 0)).faces(">Z").edges().chamfer(0.7)
    if slot:
        s = s.cut(box(6, 0.8, 1.0, (0, 0, 0.9)))
    else:
        s = s.cut(cq.Workplane("XY").polygon(6, 2.8 / math.cos(math.radians(30))).extrude(1.0).translate((0, 0, 0.9)))
    rot = {"Z": None, "Y": ((1, 0, 0), -90), "X": ((0, 1, 0), 90)}[axis]
    if rot:
        s = s.rotate((0, 0, 0), rot[0], rot[1])
    return s.translate(at)


def _arc_mid(c, r, a0, a1):
    """Mid-point of an arc about c (Z, Y) from angle a0 to a1 (degrees)."""
    am = math.radians((a0 + a1) / 2)
    return cq.Vector(c[0] + r * math.cos(am), c[1] + r * math.sin(am), 0)


def plate_outer_path():
    """The panel's outer surface, top to bottom, as a list of segments for a
    (Z, Y) wire: ("line", P) or ("arc", M, P) with cq.Vectors (x = Z, y = Y).
    Inclined face, PLATE_CREASE_R bend, vertical lower face, the S-shaped
    set-back of two JOGGLE_R arcs, then straight down to the base."""
    top = cq.Vector(FACE_TOP[0], FACE_TOP[1], 0)
    crease = cq.Vector(CREASE[0], CREASE[1], 0)
    u1 = (crease - top).normalized()
    u2 = cq.Vector(0, -1, 0)
    turn = math.acos(max(-1.0, min(1.0, u1.dot(u2))))
    R = PLATE_CREASE_R
    t = R * math.tan(turn / 2)
    A, B = crease - u1 * t, crease + u2 * t
    n1 = cq.Vector(-u1.y, u1.x, 0)                                           # outward normal of the inclined face
    C = A - n1 * R
    Mc = C + (crease - C).normalized() * R
    # joggle: arc 1 about (LOWER_Z - JOGGLE_R, JOGGLE_Y1) from 0 deg down to -th, arc 2 about
    # (LOWER_Z - JOGGLE_IN + JOGGLE_R, JOGGLE_Y0) from 180 - th to 180 deg
    th = math.degrees(math.atan2(JOGGLE_IN / 2, (JOGGLE_Y1 - JOGGLE_Y0) / 2) * 2)
    c1 = (LOWER_Z - JOGGLE_R, JOGGLE_Y1)
    c2 = (LOWER_Z - JOGGLE_IN + JOGGLE_R, JOGGLE_Y0)
    mid = cq.Vector(c1[0] + JOGGLE_R * math.cos(math.radians(-th)), c1[1] + JOGGLE_R * math.sin(math.radians(-th)), 0)
    return [("start", top), ("line", A), ("arc", Mc, B),
            ("line", cq.Vector(LOWER_Z, JOGGLE_Y1, 0)),
            ("arc", _arc_mid(c1, JOGGLE_R, 0, -th), mid),
            ("arc", _arc_mid(c2, JOGGLE_R, 180 - th, 180), cq.Vector(LOWER_Z - JOGGLE_IN, JOGGLE_Y0, 0)),
            ("line", cq.Vector(LOWER_Z - JOGGLE_IN, 0, 0))]


def face_plate():
    """The front panel (world frame): one PLATE_T formed sheet standing proud
    of the box on its gasket, its outer surface from plate_outer_path() and
    its inner surface the box's front (the bends are filled behind); side
    edges PLATE_EDGE_IN inside the body's sides, from the top face to the
    base."""
    segs = plate_outer_path()
    w = cq.Workplane("YZ").moveTo(segs[0][1].y, segs[0][1].x)
    for s in segs[1:]:
        if s[0] == "line":
            w = w.lineTo(s[1].y, s[1].x)
        else:
            w = w.threePointArc((s[1].y, s[1].x), (s[2].y, s[2].x))
    # back along the box's front (PROFILE, base to top)
    front = [(BASE_D, 0), (BASE_D, JOGGLE_Y0), (LOWER_Z - PLATE_T, JOGGLE_Y1), (LOWER_Z - PLATE_T, BOX_CREASE_Y), (BOX_TOP_Z, BODY_H)]
    for (z, y) in front:
        w = w.lineTo(y, z)
    w = w.close()
    xh = BODY_W / 2 - PLATE_EDGE_IN
    pl = w.extrude(2 * xh).translate((-xh, 0, 0))
    top = segs[0][1]
    try:
        pl = pl.edges(cq.selectors.BoxSelector((-xh - 1, top.y - 0.5, top.x - 0.5), (xh + 1, top.y + 0.5, top.x + 0.5))).fillet(1.0)
    except Exception:
        print("face plate: top edge fillet skipped")
    for sel in (">X", "<X"):
        try:
            outer = [e for e in pl.faces(sel).edges().vals() if _outside_box_front(e.Center())]
            pl = pl.newObject(outer).fillet(0.6)
        except Exception:
            print("face plate: side edge fillet skipped")
    return pl


def box_front_z(y):
    """Z of the box's front (the panel's inner surface) at height y."""
    pts = [(BASE_D, 0), (BASE_D, JOGGLE_Y0), (LOWER_Z - PLATE_T, JOGGLE_Y1), (LOWER_Z - PLATE_T, BOX_CREASE_Y), (BOX_TOP_Z, BODY_H)]
    for (z0, y0), (z1, y1) in zip(pts, pts[1:]):
        if y0 <= y <= y1:
            return z0 + (z1 - z0) * (y - y0) / (y1 - y0) if y1 > y0 else z0
    return pts[-1][0]


def _outside_box_front(c):
    """True for an edge centre (world) that lies on the panel's outer surface or top, not on the box's front."""
    return c.z > box_front_z(c.y) + 0.3 or c.y > BODY_H - 0.01


def brake_tunnel():
    """Brake tunnel (world frame) off the lower front wall: top and bottom
    plates and a +X wall round the slider's path, the rod guide to the lower
    face and the M4 nut boss on its inside; the pad's key slots, the rod bore,
    the nut pocket and the screw's clearance hole are cut here too."""
    (x0, x1), (y0, y1), (z0, z1) = BRAKE_X, BRAKE_Y, BRAKE_Z
    f = lbox(x0, x1, y1 - 4, y1, z0, z1)
    f = f.union(lbox(x0, x1, y0, y0 + 4, z0, z1))
    f = f.union(lbox(x1 - 3, x1, y0, y1, BRAKE_WALL_Z0, z1))                 # the +X wall stops short of the mode-switch bracket behind
    f = f.union(lbox(KNOB_WX - 6.5, KNOB_WX + 6.5, KNOB_WY - 7, KNOB_WY + 7, SLIDER_Z[1] + 1.0, LOWER_Z - PLATE_T - 1))   # rod guide; its face is the slider's forward stop
    f = f.union(cyl(12, 12, (KNOB_WX, KNOB_WY, LOWER_Z - PLATE_T - 15)))
    zc = (PAD_WZ[0] + PAD_WZ[1]) / 2
    cuts = lbox(x0 - 1, SLIDER_X[0] - 0.4, y0 - 1, y0 + 5, zc - 2.2, zc + 2.2)
    cuts = cuts.union(lbox(x0 - 1, SLIDER_X[0] - 0.4, y1 - 5, y1 + 1, zc - 2.2, zc + 2.2))
    cuts = cuts.union(cyl(ROD_D + 0.6, LOWER_Z - 15 - (SLIDER_Z[1] - 3), (KNOB_WX, KNOB_WY, SLIDER_Z[1] - 3)))
    nut = cq.Workplane("XY").polygon(6, 7.4 / math.cos(math.radians(30))).extrude(3.6).translate((KNOB_WX, KNOB_WY, LOWER_Z - PLATE_T - 15))
    cuts = cuts.union(nut).union(cyl(M4_CLEAR, 30, (KNOB_WX, KNOB_WY, LOWER_Z - PLATE_T - 15)))
    return f, cuts


def ring_pad():
    """Flat pad the ring's lower part sits on (world frame): the face plane
    carried on past the crease within RING_PAD_R of the handle axis, as the
    photographs show the ring overhanging the crease on a shelf in front of
    the lower face (the friction knob stands proud of it)."""
    disc = M(cyl(2 * RING_PAD_R, 16.0, (0, 0, FACE_Z - 16.0)))
    below = box(BODY_W, CREASE[1], 60.0, (0, CREASE[1] / 2, LOWER_Z - 30.0))
    return disc.intersect(below)


def housing():
    """World frame.  Open at the bottom; print upside down (top face on the bed)
    with supports for the internal brackets."""
    h = body_outline()
    try:
        h = h.edges().fillet(EDGE_R)
    except Exception:
        print("housing: edge fillet skipped")
    h = h.union(face_plate()).union(ring_pad())
    h = h.cut(body_outline(WALL_T, X_IN))
    h = h.cut(box(BODY_W - 2 * WALL_T, 6, BASE_D - 2 * WALL_T, (0, 2, WALL_T)))      # open bottom
    # boot: opening in the face, recess for the boot flange, insert bosses for the clamp ring
    h = h.union(M(ring_bosses()))
    h = h.cut(M(cyl(FACE_HOLE_D, 40, (0, 0, FACE_Z - 20))))
    h = h.cut(M(cyl(2 * FACE_RECESS_R, 10, (0, 0, FACE_Z - BOOT_FLANGE_T))))
    # internal brackets, and the brake tunnel off the lower front wall
    frames = M(right_frame()).union(M(left_frame())).intersect(body_outline())   # nothing may poke through a wall
    h = h.union(frames)
    h = h.cut(M(right_frame_cuts())).cut(M(left_frame_cuts()))
    tunnel, tunnel_cuts = brake_tunnel()
    h = h.union(tunnel).cut(tunnel_cuts)
    # selector lever: pivot hole and gasket-ring boss on the right wall (the crank drive is inside: no slot);
    # detent dimples where the bar's bump sits in JETS and THROTTLE; insert bosses for the guide plate
    pz, py = LEVER_PIVOT
    h = h.cut(cyl(AXLE_D + 0.4, 10, (X_IN - 1, py, pz), "X"))
    h = h.union(cyl(PIVOT_RING_D, PIVOT_RING_T, (BODY_W / 2, py, pz), "X").cut(cyl(AXLE_D + 0.4, 3, (BODY_W / 2 - 0.5, py, pz), "X")))
    by, bz = bar_point(DETENT_Z)
    for s_ in (-1, 1):
        a = math.radians(LEVER_SWING * s_)
        dz_, dy_ = (bz - pz) * math.cos(a) - (by - py) * math.sin(a), (bz - pz) * math.sin(a) + (by - py) * math.cos(a)
        h = h.cut(cq.Workplane("XY").sphere(1.8).translate((BODY_W / 2, py + dy_, pz + dz_)))
    for (gz, gy) in guide_screw_pts():
        h = h.union(cyl(8, 9, (X_IN - 8, gy, gz), "X"))
        h = h.cut(cyl(M3_INSERT, 6.5, (BODY_W / 2 - 6, gy, gz), "X"))
    # recesses for the two black placards (separate parts): vertical THROTTLE / JETS beside the band's
    # travel on the face, curved FRICTION beside the knob on the lower face; open holes in the face
    x0, x1, y0, y1 = MODE_PLACARD
    h = h.cut(M(lbox(x0 - 0.2, x1 + 0.2, y0 - 0.2, y1 + 0.2, FACE_Z - PLACARD_T, FACE_Z + 1)))
    h = h.cut(friction_placard_outline(0.2).extrude(PLACARD_T + 1).translate((0, 0, LOWER_Z - PLACARD_T)))
    for (xl, yl) in FACE_HOLES:                                              # through panel and wall, short of the brackets behind
        h = h.cut(M(cyl(FACE_HOLE_SMALL_D, 8, (xl, yl, FACE_Z - 6.5))))
    # gasket seams (paint them orange): a groove round each side panel 3 mm in from the edges; the front
    # panel's own gasket is the step round its edge
    for s_ in (-1, 1):
        outer = cq.Workplane("YZ").polyline([(y, z) for (z, y) in PROFILE]).close().offset2D(-3.0, "intersection").extrude(0.6)
        inner = cq.Workplane("YZ").polyline([(y, z) for (z, y) in PROFILE]).close().offset2D(-3.8, "intersection").extrude(0.6)
        ring = outer.cut(inner).translate((s_ * BODY_W / 2 - (0.5 if s_ > 0 else 0.1), 0, 0))
        h = h.cut(ring)
    # left wall (photographs): the faint circular outline, and the frame, pocket, vent hole and screw
    # bosses for the separate vent plate
    cz, cy, cd = LEFT_CIRCLE
    h = h.cut(cyl(cd + 1.0, 0.4, (-BODY_W / 2 - 0.1, cy, cz), "X").cut(cyl(cd - 1.0, 0.4, (-BODY_W / 2 - 0.1, cy, cz), "X")))
    frame, frame_cuts = vent_frame()
    h = h.union(frame).cut(frame_cuts)
    nw, nd, nt = NAMEPLATE
    h = h.cut(box(nw + 0.4, nt + 0.2, nd + 0.4, (0, BODY_H - nt - 0.1 + (nt + 0.2) / 2, NAMEPLATE_Z - nd / 2 - 0.2)))
    # slotted screw heads along the top of the face and on the top face; open mounting holes along the lower face
    for x in SCREW_XS:
        h = h.union(M(screw_head((x - HANDLE_X, TOP_SCREW_YL, FACE_Z), slot=True)))
    for (x, z) in TOP_FACE_SCREWS:
        h = h.union(screw_head((x, BODY_H, z), "Y", slot=True))
    for x in LOWER_HOLE_XS:
        h = h.cut(cyl(LOWER_HOLE_D, 40, (x, LOWER_HOLE_Y, LOWER_Z - 30)))
    # USB socket slot through the back wall (the Pro Micro lies in the bottom plate's cradle)
    uw, uy, uh = USB_SLOT
    h = h.cut(box(uw, uh, WALL_T + 2, (USB_X, uy + uh / 2, -1)))
    # bottom plate bosses inside the walls, above the plate (the plate is screwed up into them)
    for (x, z) in bottom_pts():
        h = h.union(box(12, 11, 12, (x, 9.5, z - 6)).edges("|Y").chamfer(1))
        h = h.cut(cyl(M3_INSERT, 8, (x, 3.9, z), "Y"))
    return h


def vent_frame():
    """The vent plate's seat on the left wall (world frame): a square frame
    standing VENT_FRAME_PROUD off the wall, and the cuts - the plate's pocket
    through the frame and 1 mm into the wall, the round hole behind the fan
    wheel so its slots vent into the housing, and the four M2 pilot holes,
    which run on into small bosses on the inside of the wall."""
    vz, vy = LEFT_VENT
    x1 = -BODY_W / 2
    hw = VENT_FRAME_W / 2
    f = lbox(x1 - VENT_FRAME_PROUD, x1 + 0.5, vy - hw, vy + hw, vz - hw, vz + hw)
    try:
        f = f.edges("|X").fillet(VENT_PLATE_R + (VENT_FRAME_W - VENT_PLATE_W) / 2)
        f = f.faces("<X").edges().chamfer(0.5)
    except Exception:
        print("vent frame: fillet/chamfer skipped")
    for sy, sz in ((-1, -1), (1, -1), (-1, 1), (1, 1)):                        # screw bosses inside the wall
        f = f.union(cyl(5.0, WALL_T + 4.0, (x1 + 0.5, vy + sy * VENT_SCREWS, vz + sz * VENT_SCREWS), "X"))
    pw = VENT_PLATE_W / 2 + 0.15
    cuts = lbox(x1 - VENT_FRAME_PROUD - 1, x1 - VENT_FRAME_PROUD + VENT_POCKET_D, vy - pw, vy + pw, vz - pw, vz + pw)
    try:
        cuts = cuts.edges("|X").fillet(VENT_PLATE_R + 0.15)
    except Exception:
        pass
    cuts = cuts.union(cyl(VENT_HOLE_D, WALL_T + 4, (x1 - 2, vy, vz), "X"))
    for sy, sz in ((-1, -1), (1, -1), (-1, 1), (1, 1)):
        cuts = cuts.union(cyl(1.7, 9.0, (x1 - 1, vy + sy * VENT_SCREWS, vz + sz * VENT_SCREWS), "X"))
    return f, cuts


def vent_blade_outline(phi0):
    """One fan blade of the vent plate as a closed (x, y) outline in the plate's
    own frame (face up, +Z out): a swept rib from inside the hub to just past
    the wheel's rim, thickening from the hub outwards."""
    r_hub, r_open, r_rim = VENT_HUB_D / 2, VENT_SLOT_R[0], VENT_FAN_D / 2
    t_hub, t_open, t_rim = VENT_BLADE_T
    rs = [r_hub - 0.4 + (r_rim + 0.6 - (r_hub - 0.4)) * i / 18 for i in range(19)]
    centres, thick = [], []
    for r in rs:
        phi = math.radians(phi0 - VENT_SWEEP_DEG_MM * (r - r_hub))               # swept clockwise (seen from outside) going out
        centres.append((r * math.cos(phi), r * math.sin(phi)))
        if r <= r_open:
            thick.append(t_hub + (t_open - t_hub) * max(0.0, r - r_hub) / (r_open - r_hub))
        else:
            thick.append(t_open + (t_rim - t_open) * min(1.0, (r - r_open) / (r_rim - r_open)))
    left, right = [], []
    for i, (c, t) in enumerate(zip(centres, thick)):
        a, b = centres[max(i - 1, 0)], centres[min(i + 1, len(centres) - 1)]
        tx, ty = b[0] - a[0], b[1] - a[1]
        n = math.hypot(tx, ty)
        nx, ny = -ty / n, tx / n
        left.append((c[0] + nx * t / 2, c[1] + ny * t / 2))
        right.append((c[0] - nx * t / 2, c[1] - ny * t / 2))
    return left + right[::-1]


def vent_plate():
    """The square white vent plate on the left wall (photographs), one printed
    part: a 39 mm plate with a 23 mm fan wheel of 22 swept blades let 0.4 mm
    into its face; the slots between the blades are open from 6.5 mm out to the
    rim and go on as grooves in to the hub.  Built face up (+Z out), then
    turned to the left wall.  Print it as built, on its back."""
    w, t = VENT_PLATE_W, VENT_PLATE_T
    r_hub, (r_open, r_rim) = VENT_HUB_D / 2, VENT_SLOT_R
    p = box(w, w, t)
    try:
        p = p.edges("|Z").fillet(VENT_PLATE_R)
        p = p.faces(">Z").edges().chamfer(0.4)
    except Exception:
        print("vent plate: fillet/chamfer skipped")
    z_wheel = t - VENT_FAN_RECESS                                              # the wheel's face
    p = p.cut(cyl(VENT_FAN_D, VENT_FAN_RECESS + 1, (0, 0, z_wheel)))            # the wheel's recess
    grooves = cyl(2 * r_open + 0.2, 5, (0, 0, z_wheel - VENT_GROOVE_DEPTH))    # the grooves' depth round the hub ...
    p = p.cut(grooves.cut(cyl(2 * r_hub - 0.2, 6, (0, 0, z_wheel - VENT_GROOVE_DEPTH - 0.5))))
    p = p.cut(cyl(2 * r_rim, t + 2, (0, 0, -1)).cut(cyl(2 * r_open, t + 2, (0, 0, -1))))   # ... and the open ring
    for k in range(VENT_BLADES):                                               # the blades, from the hub into the rim
        p = p.union(cq.Workplane("XY").polyline(vent_blade_outline(k * 360.0 / VENT_BLADES)).close().extrude(z_wheel))
    hub = cyl(VENT_HUB_D, z_wheel + 0.2).cut(cyl(2.2, 1, (0, 0, z_wheel + 0.2 - 0.3)))                 # the hub, with a centre dimple
    p = p.union(hub)
    for sx, sy in ((-1, -1), (1, -1), (-1, 1), (1, 1)):
        p = p.cut(cyl(M2_CLEAR, t + 2, (sx * VENT_SCREWS, sy * VENT_SCREWS, -1)))
    # to the left wall: +Z (out of the face) -> -X, +X -> +Z (towards the user), +Y up; its back on the pocket's floor
    vz, vy = LEFT_VENT
    x_back = -BODY_W / 2 - VENT_FRAME_PROUD + VENT_POCKET_D
    return p.rotate((0, 0, 0), (0, 1, 0), -90).translate((x_back, vy, vz))


def nameplate():
    """Light-gray plate let into the top face, Grumman data engraved (fill black)."""
    nw, nd, nt = NAMEPLATE
    p = box(nw, nt, nd, (0, BODY_H - 0.1 - nt / 2, NAMEPLATE_Z - nd / 2))
    for (txt, dz, sz_) in (("GRUMMAN AIRCRAFT ENG. CORP.", -7.5, 2.6), ("BETHPAGE, NEW YORK, U.S.A.", -3.0, 2.2),
                           ("PART NO LDW300-21800   SER NO", 2.5, 2.2), ("MODEL TTCA   DATE", 7.5, 2.2)):
        p = p.cut(engrave(txt, sz_, 0.4, "top", (0, BODY_H - 0.1, NAMEPLATE_Z + dz)))
    return p


def bottom_pts():
    x = X_IN - 6
    return [(x, 12), (-x, 12), (x, 62), (-x, 62), (x, 116), (-x, 116)]


def bottom_plate():
    """Inset plate closing the open bottom; Pro Micro cradle against the back
    wall (board flat, USB socket in the wall slot), rubber-feet recesses."""
    p = box(BODY_W - 2 * WALL_T - 0.4, 4, BASE_D - 2 * WALL_T - 0.4, (0, 2, WALL_T + 0.2))
    for (x, z) in bottom_pts():
        p = p.cut(cyl(M3_CLEAR, 6, (x, -1, z), "Y"))
        p = p.cut(cyl(M3_HEAD_D, 2.2, (x, -0.1, z), "Y"))
    for (x, z) in FEET:
        p = p.cut(cyl(10.5, 1.0, (x, -0.1, z), "Y"))
    uw, uy, uh = USB_SLOT
    for s in (-1, 1):                                   # rails with a groove for the board's long edges
        x = USB_X + s * (18.3 / 2 + 1.5)
        rail = box(3, 6, 30, (x, 7, 5))
        rail = rail.cut(box(1.8, 1.9, 32, (x - s * 0.9, uy + 2.15, 4)))
        p = p.union(rail)
    return p


def friction_knob():
    """Six-lobe star knob on a short skirt, KNOB_STANDOFF off the vertical
    lower face, axis horizontal (world frame), on the M4 brake screw (head
    glued in the pocket on the star's face)."""
    z0 = LOWER_Z + KNOB_STANDOFF
    sd, sh = STAR_SKIRT
    k = cyl(sd, sh, (KNOB_WX, KNOB_WY, z0))
    star = cyl(STAR_VALLEY_D, STAR_H, (KNOB_WX, KNOB_WY, z0 + sh))
    for i in range(6):
        a = math.radians(i * 60 + 90)
        r = (STAR_D - STAR_LOBE_D) / 2
        star = star.union(cyl(STAR_LOBE_D, STAR_H, (KNOB_WX + r * math.cos(a), KNOB_WY + r * math.sin(a), z0 + sh)))
    try:
        star = star.faces(">Z").edges().chamfer(1.5)
    except Exception:
        pass
    k = k.union(star)
    k = k.cut(cyl(7.5, 6, (KNOB_WX, KNOB_WY, z0 + sh + STAR_H - 5.9)))      # M4 socket head pocket
    k = k.cut(cyl(M4_CLEAR, 40, (KNOB_WX, KNOB_WY, z0 - 1)))
    return k


def _thick_line(a, b, w, x0, x1, ext0=0.0, ext1=0.0):
    """Prism (x0..x1) of a straight strip of width w from (y, z) point a to b,
    extended ext0 / ext1 beyond the ends."""
    ay, az = a; by, bz = b
    L = math.hypot(by - ay, bz - az)
    ey, ez = (by - ay) / L, (bz - az) / L
    py_, pz_ = -ez, ey
    a2 = (ay - ey * ext0, az - ez * ext0); b2 = (by + ey * ext1, bz + ez * ext1)
    pts = [(a2[0] + py_ * w / 2, a2[1] + pz_ * w / 2), (b2[0] + py_ * w / 2, b2[1] + pz_ * w / 2),
           (b2[0] - py_ * w / 2, b2[1] - pz_ * w / 2), (a2[0] - py_ * w / 2, a2[1] - pz_ * w / 2)]
    return yz_prism(pts, x0, x1)


def bar_frame_world(sv, w):
    """World (Y, Z) of a point sv along the bar from the hub and w across it (+w up-and-back)."""
    pz, py = LEVER_PIVOT
    r = math.radians(LEVER_RISE_DEG)
    return py + sv * math.sin(r) + w * math.cos(r), pz + sv * math.cos(r) - w * math.sin(r)


def bar_alpha():
    """The bar's angle above the handle frame's z' axis (degrees)."""
    return LEVER_RISE_DEG - TILT


def bar_s(zl):
    """Distance along the bar from the hub to the point at local z'."""
    hy, hz = to_local(LEVER_PIVOT[1], LEVER_PIVOT[0])
    return (zl - hz) / math.cos(math.radians(bar_alpha()))


def shaft_flat_box(x0, x1, py, pz):
    """The D-flat on the lever shaft's inboard end (world), cut 1.5 mm deep on the +Y side."""
    return lbox(x0, x1, py + AXLE_D / 2 - 1.5, py + AXLE_D / 2 + 1, pz - AXLE_D / 2 - 1, pz + AXLE_D / 2 + 1)


def select_lever():
    """THROTTLE / JETS selector bar as on the flight unit: one straight flat
    piece on the right wall, from a round pivot hub near the back-bottom
    corner, climbing towards the front and passing under the guide plate, and
    ending beside the face where the chrome band (the same width, lying on
    the bar's outer face) starts to curve inward - so from the side, bar and
    band read as one straight strip.  Nothing hangs below the hub: the crank
    drive is the arm on the shaft's inboard end (lever_arm).  Modelled at
    neutral; the lever turns +/-LEVER_SWING about the hub: band up = THROTTLE,
    down = JETS."""
    pz, py = LEVER_PIVOT
    x0 = LEVER_X0
    x1 = x0 + LEVER_T
    half = LEVER_W / 2
    # the bar ends 0.2 mm behind the line where the band starts to curve away from it (skewed BAND_SKEW_DEG)
    s1 = bar_s(BAND_ROOT_ZL[1])
    tp = math.tan(math.radians(BAND_SKEW_DEG))
    outline = [(0.0, -half), (s1 - half * tp - 0.2, -half), (s1 + half * tp - 0.2, half), (0.0, half)]
    pts = [bar_frame_world(sv, w) for (sv, w) in outline]
    bar = yz_prism(pts, x0, x1)
    hub = cyl(LEVER_HUB_D, LEVER_T, (x0, py, pz), "X")
    for a in (45, 135, 225, 315):
        hub = hub.cut(cyl(2.5, LEVER_T + 2, (x0 - 1, py + 8.5 * math.sin(math.radians(a)), pz + 8.5 * math.cos(math.radians(a))), "X"))
    lever = bar.union(hub).union(screw_head((x1, py, pz), "X"))
    # shaft through the ring boss and the wall, the crank arm on its inboard end on a D-flat, and the
    # insert for the retaining screw that also clamps the arm
    x_in = x0 - WALL_T - PIVOT_RING_T - 0.5 - LEVER_ARM_T - 1.0
    shaft = cyl(AXLE_D, -(x0 - x_in), (x0, py, pz), "X")
    shaft = shaft.cut(shaft_flat_box(x_in - 1, x_in + LEVER_ARM_T + 1.5, py, pz))
    shaft = shaft.cut(cyl(M3_INSERT, 6, (x_in - 0.1, py, pz), "X"))
    lever = lever.union(shaft)
    # cosmetic detent housing block on the bar's outer face, two rivet holes
    rise = math.radians(LEVER_RISE_DEG)
    e = (math.sin(rise), math.cos(rise))                      # bar direction (y, z)
    by, bz = bar_point(DETENT_BLOCK_Z)
    blk = _thick_line((by - e[0] * 6, bz - e[1] * 6), (by + e[0] * 6, bz + e[1] * 6), 9.0, x1, x1 + 3.0)
    for d in (-3, 3):
        blk = blk.cut(cyl(1.6, 5, (x1 + 0.5, by + e[0] * d, bz + e[1] * d), "X"))
    lever = lever.union(blk)
    # detent bump on the inner face (0.4 mm proud of the wall; the guide plate lets the bar flex that much)
    by, bz = bar_point(DETENT_Z)
    lever = lever.union(cq.Workplane("XY").sphere(1.5).translate((BODY_W / 2 + 1.1, by, bz)))
    # M2 holes through the bar's end for the band's root
    for (zl, w) in BAND_SCREWS:
        hy, hz = bar_frame_world(bar_s(zl), w)
        lever = lever.cut(cyl(1.8, LEVER_T + 2, (x0 - 1, hy, hz), "X"))
    return lever


def lever_arm():
    """Crank arm on the lever shaft's inboard end (local frame): a flat
    LEVER_ARM_W x LEVER_ARM_T plate from a round boss on the shaft's D-flat at
    the hub, doglegged past the pawl crank's pivot lug to the pin at CRANK_END
    (the pin is pressed in, pointing inboard into the crank's slot).  The
    retaining screw through the shaft's insert clamps it."""
    hy, hz = HUB_LOCAL
    ey, ez = LEVER_ARM_ELBOW
    py, pz = CRANK_END
    x1 = XW_R - 1.0 - 0.5                                   # against the wall's inner face, 0.5 mm off it
    x0 = x1 - LEVER_ARM_T
    a = _thick_line((hy, hz), (ey, ez), LEVER_ARM_W, x0, x1)
    a = a.union(_thick_line((ey, ez), (py, pz), LEVER_ARM_W, x0, x1))
    a = a.union(cyl(LEVER_ARM_W, LEVER_ARM_T, (x0, ey, ez), "X"))               # rounded elbow
    a = a.union(cyl(14.0, LEVER_ARM_T, (x0, hy, hz), "X"))                      # boss on the shaft
    a = a.union(cyl(LEVER_ARM_W, LEVER_ARM_T, (x0, py, pz), "X"))
    # D-hole matching the shaft's flat (which is cut on the shaft's +Y side in the world frame): the hole
    # is made in the world frame at the hub and brought into the handle frame
    wz, wy = LEVER_PIVOT
    wx0 = x0 + HANDLE_X
    hole = cyl(AXLE_D + 0.3, LEVER_ARM_T + 2, (wx0 - 1, wy, wz), "X")
    hole = hole.cut(lbox(wx0 - 2, wx0 + LEVER_ARM_T + 2, wy + AXLE_D / 2 - 1.5 + 0.15, wy + AXLE_D / 2 + 2, wz - 6, wz + 6))
    a = a.cut(W2L(hole))
    a = a.cut(cyl(PIN_D - 0.1, LEVER_ARM_T + 2, (x0 - 1, py, pz), "X"))
    return a


def band_frame():
    """Geometry of the band's skewed bend in the band frame (X = local x, Y = w across the bar,
    Z = s along it): the bend axis direction a and the in-plane perpendicular p, the start line
    through (w 0, s1), the arc length and the flat position of the tip."""
    phi = math.radians(BAND_SKEW_DEG)
    a = (0.0, math.cos(phi), math.sin(phi))
    p = (0.0, -math.sin(phi), math.cos(phi))
    s1 = bar_s(BAND_ROOT_ZL[1])
    xc = LEVER_X0 + LEVER_T - HANDLE_X + BAND_T / 2
    arc = BAND_BEND_R * math.pi / 2
    d_tip = (xc - BAND_BEND_R) - BAND_TIP_X + arc              # the tip's inner corner, measured along p from the start line
    s_tip = s1 + (d_tip - (BAND_W / 2) * math.sin(phi)) / math.cos(phi)
    return phi, a, p, s1, xc, arc, s_tip


def lever_band():
    """Chrome band (handle frame): a BAND_W x BAND_T strip of the bar's width
    lying on the bar's outer face - a straight root screwed to the bar's end
    just ahead of the guide plate, then a 90-degree bend on a gentle
    BAND_BEND_R radius turning in towards the T-handle, and the flat arm
    ending in a rounded tip above the THROTTLE / JETS placard.  The bend line
    is skewed BAND_SKEW_DEG across the strip, so the arm climbs towards its
    tip and stands a little further off the face there, as both photographs
    show.  Modelled as the flat strip, split along the bend lines and wrapped
    round the bend axis in BAND_FACETS steps.  Print on the arm with the bend
    and root standing up; polish or paint chrome."""
    hy, hz = to_local(LEVER_PIVOT[1], LEVER_PIVOT[0])
    alpha = bar_alpha()
    x_in = LEVER_X0 + LEVER_T - HANDLE_X                       # the bar's outer face, local x
    x_out = x_in + BAND_T
    w0, w1 = -BAND_W / 2, BAND_W / 2
    s0 = bar_s(BAND_ROOT_ZL[0])
    phi, a, p, s1, xc, arc, s_tip = band_frame()
    R = BAND_BEND_R
    # the flat strip in the band frame: rear edge at s0, rounded tip at s_tip
    tr = BAND_TIP_R
    flat = [(w0, s0), (w1, s0), (w1, s_tip - tr)]
    for i in range(1, 9):
        ang = math.radians(90 * i / 8)
        flat.append((w1 - tr + tr * math.cos(ang), s_tip - tr + tr * math.sin(ang)))
    for i in range(1, 9):
        ang = math.radians(90 + 90 * i / 8)
        flat.append((w0 + tr + tr * math.cos(ang), s_tip - tr + tr * math.sin(ang)))
    strip = yz_prism(flat, x_in, x_out)
    for (zl, w) in BAND_SCREWS:                               # screw holes and heads on the root
        sv = bar_s(zl)
        strip = strip.cut(cyl(M2_CLEAR, BAND_T + 2, (x_in - 1, w, sv), "X"))
        strip = strip.union(cyl(3.8, 0.6, (x_out, w, sv), "X"))
    for (back, dw) in BAND_RIVETS:                            # rivet heads on the tip
        strip = strip.union(cyl(2.4, 0.6, (x_out, dw, s_tip - back), "X"))

    def region(d_lo, d_hi):
        """The part of the flat strip between d_lo and d_hi along p from the start line."""
        box_ = lbox(x_in - 5, x_out + 5, -60, 60, s1 + d_lo, s1 + d_hi).rotate((0, 0, s1), (1, 0, s1), BAND_SKEW_DEG)
        return strip.intersect(box_)

    def wrap(solid, d_mid, deg):
        """Move a region whose mid-line is d_mid along p onto the start line and turn it deg about the bend axis."""
        solid = solid.translate((0, d_mid * math.sin(phi), -d_mid * math.cos(phi)))
        return solid.rotate((xc - R, 0, s1), (xc - R, a[1], s1 + a[2]), deg)

    b = region(-100, 0)                                        # root, flat on the bar
    n = BAND_FACETS
    for k in range(n):
        d_lo, d_hi = arc * k / n, arc * (k + 1) / n
        d_mid = (d_lo + d_hi) / 2
        b = b.union(wrap(region(d_lo - 0.01, d_hi + 0.01), d_mid, -math.degrees(d_mid / R)))
    b = b.union(wrap(region(arc, arc + 200), arc, -90.0))     # arm, in towards the handle
    return b.rotate((0, 0, 0), (1, 0, 0), -alpha).translate((0, hy, hz))


def friction_placard_outline(grow=0.0):
    r0, r1, a0, a1 = FRICTION_PLACARD
    r0, r1 = r0 - grow, r1 + grow
    da = math.degrees(grow / r0) if grow else 0.0
    a0, a1 = a0 + da, a1 - da
    outer = [(KNOB_WX + r1 * math.cos(math.radians(a0 + (a1 - a0) * i / 16)), KNOB_WY + r1 * math.sin(math.radians(a0 + (a1 - a0) * i / 16))) for i in range(17)]
    inner = [(KNOB_WX + r0 * math.cos(math.radians(a1 + (a0 - a1) * i / 16)), KNOB_WY + r0 * math.sin(math.radians(a1 + (a0 - a1) * i / 16))) for i in range(17)]
    return cq.Workplane("XY").polyline(outer + inner).close()


def placard_mode():
    """Black THROTTLE (arrow up) / JETS (arrow down) placard, handle frame,
    let into the face beside the band's travel; rivet heads at both ends.
    Fill the engraved letters white."""
    x0, x1, y0, y1 = MODE_PLACARD
    p = lbox(x0, x1, y0, y1, FACE_Z - PLACARD_T, FACE_Z)
    xc = (x0 + x1) / 2
    xt, xa = xc - 2.2, xc + 2.6                               # the words read downwards in a column; each arrow runs beside its word (photograph)
    for (txt, yc) in (("THROTTLE", 4.5), ("JETS", -25.0)):
        t = cq.Workplane("XY").text(txt, 4.2, 0.5, kind="bold", halign="center", valign="center").rotate((0, 0, 0), (0, 0, 1), -90)
        p = p.cut(t.translate((xt, yc, FACE_Z - 0.4)))
    for (ya, yb, s_) in ((-6.0, 13.0, 1), (-19.0, -28.0, -1)):   # arrow shafts (from .. to) and heads: up beside THROTTLE, down beside JETS
        p = p.cut(box(0.6, abs(yb - ya), 0.5, (xa, (ya + yb) / 2, FACE_Z - 0.4)))
        tri = cq.Workplane("XY").polyline([(xa - 1.2, yb), (xa + 1.2, yb), (xa, yb + 3.0 * s_)]).close().extrude(0.5)
        p = p.cut(tri.translate((0, 0, FACE_Z - 0.4)))
    for yc in (y1 - 2.5, y0 + 2.5):
        p = p.union(cyl(2.4, 0.6, (xc, yc, FACE_Z)))
    return p


def placard_friction():
    """Black curved FRICTION placard beside the friction knob on the vertical
    lower face (world frame)."""
    r0, r1, a0, a1 = FRICTION_PLACARD
    p = friction_placard_outline().extrude(PLACARD_T).translate((0, 0, LOWER_Z - PLACARD_T))
    txt = arc_text("FRICTION", (r0 + r1) / 2, a0 - 4, a1 + 4, 2.6, 0.4, tops_out=True)
    p = p.cut(txt.translate((KNOB_WX, KNOB_WY, LOWER_Z)))
    rm = (r0 + r1) / 2
    for a in (a0 - 1.5, a1 + 1.5):
        p = p.union(cyl(2.4, 0.6, (KNOB_WX + rm * math.cos(math.radians(a)), KNOB_WY + rm * math.sin(math.radians(a)), LOWER_Z)))
    return p


def guide_plane():
    """Sketch plane of the guide plate: x along its axis (up-and-back), normal +X (outwards)."""
    cz, cy = guide_centre()
    dz, dy = guide_axis()
    x_in = LEVER_X0 + LEVER_T + GUIDE_GAP
    return cq.Plane(origin=(x_in, cy, cz), xDir=(0, dy, dz), normal=(1, 0, 0))


def lever_guide():
    """Leaf-shaped guide plate on the right wall along the face edge, standing
    off the wall on two spacer bosses so the selector bar passes between plate
    and wall; straight rear edge, curved front edge, M3 screws at both ends
    into inserts in the wall (stamped LDW300-11877-1 like the flight part)."""
    pl = guide_plane()
    x_in = pl.origin.x
    xw = BODY_W / 2
    n = 24
    pts = []
    for i in range(n + 1):                      # front (curved) edge, in plate (u, v); v > 0 faces the front
        u = -GUIDE_L / 2 + GUIDE_L * i / n
        pts.append((u, GUIDE_W0 / 2 + GUIDE_BULGE * (1 - (2 * u / GUIDE_L) ** 2)))
    pts += [(GUIDE_L / 2, -GUIDE_W0 / 2), (-GUIDE_L / 2, -GUIDE_W0 / 2)]
    plate = cq.Workplane(pl).polyline(pts).close().extrude(GUIDE_T)
    try:
        plate = plate.edges("|X").fillet(3.0)
    except Exception:
        pass
    plate = plate.cut(cq.Workplane(pl).workplane(offset=GUIDE_T).center(6.0, 1.5)
                      .text("LDW300-11877-1", 2.0, -0.35, kind="bold", halign="center", valign="center"))
    for (gz, gy) in guide_screw_pts():
        plate = plate.union(cyl(8.0, x_in - xw, (xw, gy, gz), "X"))
        plate = plate.cut(cyl(M3_CLEAR, 20, (xw - 1, gy, gz), "X"))
        plate = plate.cut(cyl(M3_HEAD_D + 0.2, 2.5, (x_in + GUIDE_T - 1.4, gy, gz), "X"))
    return plate


# ============================================================== cradle ===
def cradle():
    c = None
    for s in (-1, 1):
        plate = lbox(s * CRADLE_X - (CRADLE_T if s < 0 else 0), s * CRADLE_X + (CRADLE_T if s > 0 else 0),
                     -CRADLE_Y1, CRADLE_Y1, CRADLE_Z0, CRADLE_Z1)
        c = plate if c is None else c.union(plate)
    # brake flange on the right plate: sector R FLANGE_R from FLANGE_A0 to FLANGE_A1 (degrees from -y' towards +z'),
    # with its rear corner drawn in to FLANGE_TAIL so it clears the back chamfer at full pitch
    ta, tr = FLANGE_TAIL
    pts = [(0, 0), (-tr * math.cos(math.radians(ta)), tr * math.sin(math.radians(ta)))]
    pts += [(-FLANGE_R * math.cos(math.radians(a)), FLANGE_R * math.sin(math.radians(a)))
            for a in [FLANGE_A0 + (FLANGE_A1 - FLANGE_A0) * i / 24 for i in range(25)]]
    c = c.union(yz_prism(pts, CRADLE_X, CRADLE_X + CRADLE_T))
    W = 2 * CRADLE_X + 2 * CRADLE_T
    for (y0, y1) in ((-CRADLE_Y1, -CRADLE_Y1 + 8), (CRADLE_Y1 - 8, CRADLE_Y1)):
        c = c.union(box(W, y1 - y0, 20, (0, (y0 + y1) / 2, CRADLE_Z0)))
    for (y0, y1) in ((-CRADLE_Y1, -BLOCK_H / 2 - 1), (BLOCK_H / 2 + LID_T + 1, CRADLE_Y1)):
        c = c.union(box(W, y1 - y0, 16, (0, (y0 + y1) / 2, -8)))
    c = c.cut(cyl(YAW_PIN_D + 0.1, 80, (0, -40, 0), "Y"))
    for s in (-1, 1):
        c = c.cut(d_hole(CRADLE_T + 2, s * (CRADLE_X + CRADLE_T / 2) - (CRADLE_T + 2) / 2))
        c = c.cut(cyl(2.9, 30, (s * (CRADLE_X + CRADLE_T / 2), -20, 0), "Y"))
    # yaw switch ledges and spring nubs
    for s in (-1, 1):
        c = c.union(box(10, 4, 24, (s * (CRADLE_X - 5), -20, BLOCK_Z1 - 26)))
        for dz in (-SW_HOLE_PITCH / 2, SW_HOLE_PITCH / 2):
            c = c.cut(cyl(2.3, 6, (s * (CRADLE_X - 2.6), -21, BLOCK_Z1 - 14 + dz), "Y"))
    for s in (-1, 1):
        c = c.union(cyl(4.8, 4, (s * CRADLE_X - (4 if s > 0 else 0), 8, BLOCK_Z0 + 8), "X"))
    # keep the front of the cradle inside a sphere about the gimbal, clear of the boot at any pitch
    front = box(200, 200, 100, (0, 0, -6.0))
    c = c.cut(front.cut(cq.Workplane("XY").sphere(CRADLE_SPHERE_R)))
    return c


# ----------------------------------------------------------- yaw block ---
def stem_channel(length, z0, clearance):
    ch = cyl(STEM_D + 2 * clearance, length, (0, 0, z0))
    flat = box(STEM_D + 2, 4, length + 2, (0, STEM_D / 2 - STEM_FLAT + clearance + 2, z0 - 1))
    return ch.cut(flat)


def yaw_block():
    L = BLOCK_Z1 - BLOCK_Z0
    b = box(BLOCK_W, BLOCK_H, L, (0, 0, BLOCK_Z0))
    top = BLOCK_H / 2
    b = b.cut(stem_channel(L + 2, BLOCK_Z0 - 1, CLEAR_SLIDE))
    b = b.cut(box(STEM_D + 2 * CLEAR_SLIDE, top + 1, L + 2, (0, (top + 1) / 2, BLOCK_Z0 - 1)))
    zc0 = BLOCK_Z0 + 4
    cb = SLIDE + 4
    zcav = zc0 + cb
    zc1 = zcav + CAVITY_L
    for (z, l) in ((zc0, cb), (zcav, CAVITY_L), (zc1, cb)):
        b = b.cut(cyl(CAVITY_D, l, (0, 0, z)))
        b = b.cut(box(CAVITY_D, top + 1, l, (0, (top + 1) / 2, z)))
    b = b.cut(cyl(YAW_PIN_D + 0.3, 9, (0, top - 8, 0), "Y"))
    b = b.cut(cyl(YAW_PIN_D + 0.3, 9, (0, -top - 1, 0), "Y"))
    for z in (BLOCK_Z0 + 6, BLOCK_Z1 - 6):
        for s in (-1, 1):
            b = b.cut(cyl(M3_INSERT, 8, (s * (BLOCK_W / 2 - 5), top - 7.9, z), "Y"))
    for s in (-1, 1):
        b = b.cut(cyl(COMP_SPRING_OD - 1.2, 2.5, (s * BLOCK_W / 2 - (2.5 if s > 0 else 0), 8, BLOCK_Z0 + 8), "X"))
    b = b.cut(box(BLOCK_W, 4.5, 2 * SLIDE + 3.6, (BLOCK_W / 2, 0, FLAG_Z - SLIDE - 1.8)))
    for (x, y) in CAP_SCREWS:
        b = b.cut(cyl(M3_CLEAR, L + 2, (x, y, BLOCK_Z0 - 1)))
        b = b.cut(cyl(M3_HEAD_D, 4, (x, y, BLOCK_Z0 - 0.1)))
    for sgn in (-1, 1):
        z_face = FLAG_Z + sgn * (2 + 3 + LEVER_PROUD)
        z_bottom = z_face + sgn * SW_H
        for dy in (-SW_HOLE_PITCH / 2, SW_HOLE_PITCH / 2):
            b = b.cut(box(8, 2.3, 3 + 2.3, (BLOCK_W / 2 - 4, -2 + dy, z_bottom - sgn * 2.6 - 2.65)).edges("|X").fillet(1.1))
    return b


def yaw_block_lid():
    top = BLOCK_H / 2
    lid = box(BLOCK_W, LID_T, BLOCK_Z1 - BLOCK_Z0, (0, top + LID_T / 2, BLOCK_Z0))
    lid = lid.cut(cyl(YAW_PIN_D + 0.3, LID_T + 2, (0, top - 1, 0), "Y"))
    for z in (BLOCK_Z0 + 6, BLOCK_Z1 - 6):
        for s in (-1, 1):
            lid = lid.cut(cyl(M3_CLEAR, LID_T + 2, (s * (BLOCK_W / 2 - 5), top - 1, z), "Y"))
            lid = lid.cut(cyl(M3_HEAD_D, 2.2, (s * (BLOCK_W / 2 - 5), top + LID_T - 2.1, z), "Y"))
    return lid


def stem_washer():
    w = cyl(CAVITY_D - 0.5, WASHER_T, (0, 0, 0))
    return w.cut(stem_channel(WASHER_T + 2, -1, 0.35))


def stem():
    """D-stem (flat up) inside the block and the cap tube, round 11 mm where it
    shows, knob socket at the end with an M3 insert for the knob's face screw.
    Print flat side down."""
    s = cyl(STEM_D, 70 - STEM_Z0, (0, 0, STEM_Z0))
    s = s.cut(box(STEM_D + 2, 4, 70 - STEM_Z0 + 2, (0, STEM_D / 2 - STEM_FLAT + 2, STEM_Z0 - 1)))
    s = s.union(cyl(STEM_ROUND_D, KNOB_Z - 70, (0, 0, 70)))
    zcav = BLOCK_Z0 + 4 + SLIDE + 4
    for z in (zcav - 1.5, zcav + CAVITY_L + 1.5):
        s = s.cut(cyl(3.0, STEM_D + 2, (-STEM_D / 2 - 1, 0, z), "X"))
    s = s.cut(cyl(2.5, 8, (STEM_D / 2 - 7.9, 0, FLAG_Z), "X"))
    s = s.cut(cyl(M3_INSERT, 6, (0, 0, KNOB_Z - 5.9)))
    return s


def revolve_ring(pts):
    """Solid of revolution about Z from a closed (r, z) polygon away from the axis."""
    return cq.Workplane("XZ").polyline(pts).close().revolve(360, (0, 0, 0), (0, 1, 0))


def rounded_path(pts, radii, n_arc=6):
    """Replace each interior corner of an (r, z) polyline by a sampled arc of
    the given radius (list, one per interior corner)."""
    out = [pts[0]]
    for i in range(1, len(pts) - 1):
        p0, p1, p2 = (cq.Vector(*pts[i - 1], 0), cq.Vector(*pts[i], 0), cq.Vector(*pts[i + 1], 0))
        d1, d2 = (p1 - p0).normalized(), (p2 - p1).normalized()
        R = radii[i - 1]
        cosang = max(-1.0, min(1.0, d1.dot(d2)))
        turn = math.acos(cosang)                       # turning angle at the corner
        if R <= 0 or turn < 1e-6:
            out.append(pts[i])
            continue
        tlen = R * math.tan(turn / 2)                  # tangent length
        a = p1 - d1 * tlen
        b = p1 + d2 * tlen
        # centre of the arc: from a, perpendicular to d1 towards the inside of the turn
        cross = d1.x * d2.y - d1.y * d2.x              # +: left turn
        n1 = cq.Vector(-d1.y, d1.x, 0) * (1 if cross > 0 else -1)
        centre = a + n1 * R
        ang0 = math.atan2(a.y - centre.y, a.x - centre.x)
        sweep = turn * (1 if cross > 0 else -1)
        for k in range(n_arc + 1):
            t = ang0 + sweep * k / n_arc
            out.append((centre.x + R * math.cos(t), centre.y + R * math.sin(t)))
    out.append(pts[-1])
    return out


def offset_path(pts, d):
    """Offset an open (r, z) polyline by d to its left (looking along it)."""
    out = []
    n = len(pts)
    for i in range(n):
        p = cq.Vector(*pts[i], 0)
        d1 = (p - cq.Vector(*pts[i - 1], 0)).normalized() if i > 0 else None
        d2 = (cq.Vector(*pts[i + 1], 0) - p).normalized() if i < n - 1 else None
        if d1 is None:
            d1 = d2
        if d2 is None:
            d2 = d1
        n1, n2 = cq.Vector(-d1.y, d1.x, 0), cq.Vector(-d2.y, d2.x, 0)
        bis = n1 + n2
        denom = 1 + n1.dot(n2)
        q = p + bis * (d / denom)
        out.append((q.x, q.y))
    return out


def boot_outer_profile():
    """Outer (r, z') polyline of the TPU boot: the fins on the cone (valley on
    the cone wall, crest BOOT_FIN_D further out with the fin's underside
    leaning BOOT_LEDGE_DEG from the axis, then the fin's top surface back to
    the wall at the next valley), the shoulder and the collar, before corner
    rounding."""
    rise = 1 / math.tan(math.radians(BOOT_LEDGE_DEG))   # the fin underside climbs this much per mm outward
    n = BOOT_PLEATS
    dr, dz = (BOOT_R0 - BOOT_CONE_R1) / n, BOOT_CONE_H / n          # the cone wall per fin: inward, up
    pts = [(BOOT_R0, BOOT_Z0)]
    for k in range(n):
        rv, zv = BOOT_R0 - k * dr, BOOT_Z0 + k * dz                  # valley k on the cone wall
        pts.append((rv + BOOT_FIN_D, zv + BOOT_FIN_D * rise))        # crest k
        pts.append((rv - dr, zv + dz))                               # valley k + 1
    pts.append((BOOT_COLLAR_R, BOOT_COLLAR_Z0))
    pts.append((BOOT_COLLAR_R, BOOT_COLLAR_Z1))
    return pts


def boot():
    """Flexible boot, print in TPU flange-down: a 1 mm cone wall carrying
    solid wedge fins, flange clamped under the ring on the face, collar
    stretched over the stem guide's tube below its flare.  Modelled in the
    neutral position."""
    pts = boot_outer_profile()
    radii = []
    for i in range(1, len(pts) - 1):
        radii.append(BOOT_CREST_R if i % 2 == 1 else BOOT_VALLEY_R)
    radii[2 * BOOT_PLEATS - 1] = BOOT_VALLEY_R         # cone top -> shoulder
    radii[-1] = BOOT_CREST_R                           # shoulder -> collar
    outer = rounded_path(pts, radii)
    # inner surface: the collar's bore, then the cone wall's inside (BOOT_T behind the cone, measured
    # square to it), down to the face
    lean = math.atan2(BOOT_R0 - BOOT_CONE_R1, BOOT_CONE_H)            # the cone wall's angle from the axis
    r_in0 = BOOT_R0 - BOOT_T / math.cos(lean)
    z_meet = BOOT_Z0 + (r_in0 - (BOOT_COLLAR_R - BOOT_T)) / math.tan(lean)   # where the cone's inside reaches the collar bore
    inner = [(r_in0, BOOT_Z0), (BOOT_COLLAR_R - BOOT_T, z_meet), (BOOT_COLLAR_R - BOOT_T, BOOT_COLLAR_Z1)]
    poly = outer + inner[::-1]
    wall = revolve_ring(poly)
    flange = revolve_ring([(BOOT_FLANGE_R0, BOOT_Z0 - BOOT_FLANGE_T), (BOOT_FLANGE_R1, BOOT_Z0 - BOOT_FLANGE_T),
                           (BOOT_FLANGE_R1, BOOT_Z0), (BOOT_FLANGE_R0, BOOT_Z0)])
    b = wall.union(flange)
    for (x, y) in ring_screw_pts():
        b = b.cut(cyl(M3_CLEAR + 0.4, 6, (x, y, BOOT_Z0 - 3)))
    return b


def boot_ring():
    """Thin clamp ring on the face over the boot flange, eight M3 button-head screws."""
    r = revolve_ring([(RING_R0, FACE_Z), (RING_R1, FACE_Z), (RING_R1, FACE_Z + RING_T), (RING_R0, FACE_Z + RING_T)])
    try:
        r = r.faces(">Z").edges().chamfer(0.5)
    except Exception:
        pass
    for (x, y) in ring_screw_pts():
        r = r.cut(cyl(M3_CLEAR, RING_T + 2, (x, y, FACE_Z - 1)))
    return r


def stem_guide():
    """Tube on the yaw block guiding the stem's round end and carrying the boot
    collar; flange screwed to the block from behind, four gussets."""
    tube = cyl(TUBE_OD, TUBE_Z1 - BLOCK_Z1, (0, 0, BLOCK_Z1))
    flare = cyl(TUBE_FLARE_D, 1.5, (0, 0, TUBE_Z1 - 1.5)).faces(">Z").edges().chamfer(0.6)
    flange = box(34, 36, 4, (0, 0, BLOCK_Z1))
    g = tube.union(flare).union(flange)
    for a in (45, 135, 225, 315):
        rib = (cq.Workplane("XZ").polyline([(TUBE_OD / 2 - 1, BLOCK_Z1 + 4), (16, BLOCK_Z1 + 4), (TUBE_OD / 2 - 1, BLOCK_Z1 + 16)])
               .close().extrude(1.0, both=True).rotate((0, 0, 0), (0, 0, 1), a))
        g = g.union(rib)
    g = g.cut(cyl(TUBE_ID, TUBE_Z1 + 2 - BLOCK_Z1 + 1, (0, 0, BLOCK_Z1 - 1)))
    for (x, y) in CAP_SCREWS:
        g = g.cut(cyl(M3_INSERT, 4.2, (x, y, BLOCK_Z1 - 0.1)))
    return g


def knob():
    """Black prolate-spheroid knob, long axis along y' (in the face plane),
    on the stem; countersunk M3 screw on the face towards the user."""
    a, b = KNOB_AX
    sph = cq.Workplane("XY").sphere(1.0).val()
    spheroid = sph.transformGeometry(cq.Matrix([[a, 0, 0, 0], [0, b, 0, 0], [0, 0, a, 0]]))
    k = cq.Workplane("XY").newObject([spheroid]).translate((0, 0, KNOB_Z))
    k = k.cut(cyl(STEM_ROUND_D + 0.3, a + 1, (0, 0, KNOB_Z - a - 1)))
    k = k.cut(cyl(M3_CLEAR, a + 2, (0, 0, KNOB_Z - 1)))
    k = k.cut(cyl(12.0, 4.0, (0, 0, KNOB_Z + a - 3.0)))          # round recess with the M3 socket head in it
    return k


# ----------------------------------------------------------- pitch axis --
def stub_axle_right():
    x0, x1 = STUB_R
    a = cyl(AXLE_D, x1 - x0, (x0, 0, 0), "X")
    a = a.cut(box(x1 - x0 + 2, 4, AXLE_D, ((x0 + x1) / 2, AXLE_D / 2 - 1 + 2, -AXLE_D / 2)))
    a = a.cut(cyl(2.9, 20, (CRADLE_X + CRADLE_T / 2, -10, 0), "Y"))
    return a.cut(cyl(2.9, 20, (SECTOR_X0 + SECTOR_T / 2, -10, 0), "Y"))


def stub_axle_left():
    x0, x1 = STUB_L
    a = cyl(AXLE_D, x0 - x1, (x1, 0, 0), "X")
    a = a.cut(box(x0 - x1 + 2, 4, AXLE_D, ((x0 + x1) / 2, AXLE_D / 2 - 1 + 2, -AXLE_D / 2)))
    return a.cut(cyl(2.9, 20, (-CRADLE_X - CRADLE_T / 2, -10, 0), "Y"))


def sector():
    half = math.radians(SECTOR_SPAN / 2)
    pts = [(0, 0)] + [(SECTOR_R * math.sin(-half + 2 * half * i / 40), -SECTOR_R * math.cos(-half + 2 * half * i / 40)) for i in range(41)]
    q = yz_prism(pts, SECTOR_X0, SECTOR_X0 + SECTOR_T)
    q = q.union(cyl(22, SECTOR_T, (SECTOR_X0, 0, 0), "X"))
    q = q.cut(d_hole(SECTOR_T + 2, SECTOR_X0 - 1))
    notch = yz_prism([(-4.5, -SECTOR_R - 1), (4.5, -SECTOR_R - 1), (0, -SECTOR_R + 3.5)], SECTOR_X0 - 0.5, 82.5)
    q = q.cut(notch)
    # soft-stop bump: reaches the plunger after SOFT_STOP degrees of handle-up travel
    a = math.radians(math.degrees(math.asin(DETENT_DY / SECTOR_R)) - SOFT_STOP)
    q = q.union(cyl(5, 3, (SECTOR_X0 + SECTOR_T - 3, (SECTOR_R - 1) * math.sin(a), -(SECTOR_R - 1) * math.cos(a)), "X"))
    return q.cut(cyl(2.9, 14, (SECTOR_X0 + SECTOR_T / 2, -12, 0), "Y"))


def pawl_crank():
    """Bell crank on a Ø3 pin: tip arm straight up to the sector notch (the tip
    moves radially), control arm down-and-forward to the lever pin, a foot
    that presses the mode switch when the tip is withdrawn.  The lever's pin
    runs in a radial slot in the control arm: the slot's wall is where the pin
    meets it on the way up from JETS (PIN_CONTACT_DEG), and the slot is wide
    enough for the pin to float LOST_MOTION further at JETS.  A spring boss
    on the tip arm's back face takes the crank spring from the frame, which
    pushes the tip forward into the notch.  Modelled engaged (JETS)."""
    py, pz = CRANK_PIVOT
    x0, x1 = PAWL_X
    hub = cyl(10, x1 - x0, (x0, py, pz), "X")
    tip_arm = lbox(x0, x1, py, -3, pz - 3, pz + 3)
    tip = yz_prism([(-4, pz + 2.5), (4, pz + 2.5), (0, -SECTOR_R + 3.5)], x0, x1)
    foot = lbox(66.5, x1, -14, -6, pz - 3, pz + 3)
    # control arm along the pivot -> contact-pin line, long enough to take the slot
    cy, cz = pin_at(PIN_CONTACT_DEG)
    d = math.hypot(cy - py, cz - pz)
    ang = math.degrees(math.atan2(cz - pz, cy - py))
    ctrl = (box(x1 - x0, d + 6, 10, ((x0 + x1) / 2, 0, -5), (True, False, False))
            .rotate((0, 0, 0), (1, 0, 0), ang).translate((0, py, pz)))
    sy, sz = SPRING_SEAT
    seat = cyl(3.8, 2.0, ((x0 + x1) / 2, sy, pz - 3 - 2.0))                   # spring boss on the tip arm's back
    c = hub.union(tip_arm).union(tip).union(foot).union(ctrl).union(seat)
    c = c.cut(cyl(PIN_D + 0.3, 20, (x0 - 5, py, pz), "X"))
    # radial slot: its "push" wall is tangent to the pin at contact; the pin slides along the slot as the
    # crank turns and floats LOST_MOTION clear of the far wall at JETS
    jy, jz = pin_at(LEVER_SWING)                                               # the pin at JETS
    ty, tz = pin_at(-LEVER_SWING)                                              # the pin at THROTTLE
    r_lo = min(math.hypot(jy - py, jz - pz), math.hypot(ty - py, tz - pz), d) - PIN_D / 2 - 1.0
    r_hi = max(math.hypot(jy - py, jz - pz), math.hypot(ty - py, tz - pz), d) + PIN_D / 2 + 1.0
    # lateral: the push wall at +PIN_D/2 on the side the pin comes from (JETS side), the other wall LOST_MOTION + PIN_D further
    u = ((cy - py) / d, (cz - pz) / d)                                          # radial unit (y', z')
    n = (-u[1], u[0])                                                           # lateral unit
    side = 1.0 if ((jy - cy) * n[0] + (jz - cz) * n[1]) > 0 else -1.0          # which lateral side JETS lies on
    w = PIN_D + 0.3 + LOST_MOTION
    centre_lat = side * (w / 2 - PIN_D / 2 - 0.15)
    slot = box(x1 - x0 + 4, r_hi - r_lo, w, ((x0 + x1) / 2, (r_lo + r_hi) / 2, 0), (True, True, True))
    slot = slot.edges("|X").fillet(w / 2 - 0.01)
    slot = slot.translate((0, 0, centre_lat)).rotate((0, 0, 0), (1, 0, 0), ang).translate((0, py, pz))
    return c.cut(slot)


def detent_plunger():
    return cyl(DETENT_D, 28.5, (DETENT_X, DETENT_DY, -73)).faces(">Z").edges().fillet(2.0)


def pot_coupler():
    x0, x1 = COUPLER_X
    c = cyl(16, x1 - x0, (x0, 0, 0), "X")
    c = c.cut(d_hole(8, x1 - 8))                                       # stub end
    pot = cyl(POT_SHAFT_D, 8, (x0 - 1, 0, 0), "X")
    c = c.cut(pot.cut(box(10, 4, 8, (x0 + 3, 3 - 1.5 + 2, -4))))         # pot D-shaft end
    c = c.cut(cyl(2.9, 20, (x1 - 4, 0, -10), "Y"))
    return c.cut(cyl(2.9, 20, (x0 + 4, 0, -10), "Y"))


def brake_slider():
    """Wedge slider in the brake tunnel (world frame): the rod from the knob
    pushes it back (-Z); the ramp on its -X face then forces the pad onto the
    cradle's brake flange."""
    (x0, x1), (y0, y1), (z0, z1) = SLIDER_X, SLIDER_Y, SLIDER_Z
    s = lbox(x0, x1, y0 + 0.3, y1 - 0.3, z0, z1)
    wedge = (cq.Workplane("XZ").polyline([(x0, z1 - 13), (x0, z1), (x0 - 3, z1), (x0 - 3, z1 - 4)]).close()
             .extrude(-(y1 - y0 - 0.6)).translate((0, y0 + 0.3, 0)))
    return s.union(wedge)


def brake_pad():
    """Pad between the slider's ramp and the cradle's brake flange (world
    frame), keyed into the tunnel's plates so it moves only in X."""
    z0, z1 = PAD_WZ
    (bx0, bx1), (by0, by1) = BRAKE_X, BRAKE_Y
    x_flange = HANDLE_X + CRADLE_X + CRADLE_T                                # the flange's face, world X
    p = lbox(x_flange + 0.6, SLIDER_X[0] - 0.4, by0 + 4.3, by1 - 4.3, z0, z1)
    zc = (z0 + z1) / 2
    for (k0, k1) in ((by0 - 0.3, by0 + 4.4), (by1 - 4.4, by1 + 0.3)):
        p = p.union(lbox(x_flange + 1, SLIDER_X[0] - 1, k0, k1, zc - 2, zc + 2))
    return p


def brake_rod():
    """Push rod from the brake slider to just below the M4 nut boss (world frame); the knob's screw tip bears on it."""
    z0 = SLIDER_Z[1]
    return cyl(ROD_D, LOWER_Z - PLATE_T - 17 - z0, (KNOB_WX, KNOB_WY, z0)).faces(">Z").edges().chamfer(1)


# =============================================================== parts ===
LOCAL_PARTS = {
    "ttca_cradle": cradle,
    "ttca_yaw_block": yaw_block,
    "ttca_yaw_block_lid": yaw_block_lid,
    "ttca_stem_washer": stem_washer,
    "ttca_stem": stem,
    "ttca_stem_guide": stem_guide,
    "ttca_boot": boot,
    "ttca_boot_ring": boot_ring,
    "ttca_knob": knob,
    "ttca_stub_axle_right": stub_axle_right,
    "ttca_stub_axle_left": stub_axle_left,
    "ttca_sector": sector,
    "ttca_pawl_crank": pawl_crank,
    "ttca_detent_plunger": detent_plunger,
    "ttca_pot_coupler": pot_coupler,
}
WORLD_PARTS = {
    "ttca_housing": housing,
    "ttca_bottom_plate": bottom_plate,
    "ttca_nameplate": nameplate,
    "ttca_vent_plate": vent_plate,
    "ttca_friction_knob": friction_knob,
    "ttca_placard_friction": placard_friction,
    "ttca_brake_slider": brake_slider,
    "ttca_brake_pad": brake_pad,
    "ttca_brake_rod": brake_rod,
    "ttca_select_lever": select_lever,
    "ttca_lever_guide": lever_guide,
}
LOCAL_PARTS.update({
    "ttca_lever_band": lever_band,
    "ttca_lever_arm": lever_arm,
    "ttca_placard_mode": placard_mode,
})
PARTS = dict(LOCAL_PARTS, **WORLD_PARTS)


def build(name):
    s = PARTS[name]()
    return M(s) if name in LOCAL_PARTS else s


if __name__ == "__main__":
    import sys
    report()
    only = sys.argv[1:]
    built = {}
    for name in PARTS:
        if only and name not in only:
            continue
        built[name] = build(name)
        export(built[name], name)
    if not only:
        asm = cq.Assembly()
        for name, shape in built.items():
            asm.add(shape, name=name)
        asm.export(os.path.join(OUT_DIR, "ttca_assembly.step"))
    print("done")
