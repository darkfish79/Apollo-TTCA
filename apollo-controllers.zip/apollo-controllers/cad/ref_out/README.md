# Reference meshes (not printable parts)

These OBJ files are the cockpit-mesh groups that the replica exteriors were
measured against. They are extracted, unchanged apart from the coordinate
frame, from Project Apollo - NASSP, the Apollo add-on for the Orbiter space
flight simulator:

    https://github.com/orbiternassp/NASSP   (branch Orbiter2016)

| File | NASSP source | Group label |
| --- | --- | --- |
| `ttca_Body.obj`, `ttca_Handle.obj`, `ttca_SelectionLever.obj`, `ttca_FrictionControl.obj` | `Meshes/ProjectApollo/LM_VC.msh` | Body, Handle, SelectionLever, FrictionControl (the TTCA) |
| `thc_Group_5.obj`, `thc_THChandle.obj` | `Meshes/ProjectApollo/CM-VC.msh` | Group_5 (THC housing), THChandle |

Frames: the TTCA groups are translated so that the replica's housing back wall
is Z = 0, the desk Y = 0 and the body centre X = 0 (X = x + 847.3,
Y = y + 162.3, Z = 1636 - z in Orbiter metres scaled to millimetres); the THC
groups are rotated into the replica's box frame (X across the box, Y along it,
Z out of the handle face). `../msh_extract.py` regenerates them from the
original `.msh` files; `../render_docs.py` uses them for the side-by-side
comparison figures.

NASSP is copyright its authors and released under the GNU General Public
License version 2 (`NASSP-LICENSE.txt` is the licence text and `COPYING-NASSP.txt` the project's copying notice, both copied from the repository). These
derived files are redistributed under the same licence. Nothing else in this
archive is derived from NASSP: the CadQuery sources, STL/STEP parts, firmware
and documents are independent work that used these meshes only as a
dimensional reference.
