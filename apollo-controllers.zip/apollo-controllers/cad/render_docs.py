"""Render the build-plan figures into ../renders/doc_*.png.
usage: python3 render_docs.py [figure ...]      (from the cad directory, after thc.py and ttca.py)
Needs the NASSP reference meshes (ref_out/*.obj) next to this script for the comparison figures;
those figures are skipped when the folder is missing."""
import os, sys, math, subprocess, tempfile
import numpy as np, trimesh
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
S = os.path.join(HERE, "..", "stl")
R = os.path.join(HERE, "..", "renders")
REF = os.path.join(HERE, "ref_out")
TMP = tempfile.mkdtemp()
os.makedirs(R, exist_ok=True)

GRAY = "0.62,0.64,0.66"; DARK = "0.30,0.31,0.33"; GRIP = "0.52,0.53,0.55"; BLACK = "0.12,0.12,0.13"
BLUE = "0.20,0.22,0.30"; ALU = "0.80,0.81,0.83"; KNOB = "0.55,0.56,0.58"; STEEL = "0.75,0.75,0.72"
TTCA_GRAY = "0.60,0.62,0.64"; BOOT_BLUE = "0.60,0.68,0.80"; TTCA_KNOB = "0.66,0.67,0.68"
LEVER_GRAY = "0.58,0.59,0.61"; CHROME = "0.88,0.89,0.91"; PLACARD_BLACK = "0.08,0.08,0.09"


def shade(out, items, view, up="z", cut=None, px=900):
    cmd = [sys.executable, os.path.join(HERE, "shade.py"), out] + [f"{f}:{c}" for (f, c) in items] + ["--view", view, "--up", up, "--px", str(px)]
    if cut:
        cmd += ["--cut", cut]
    subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL)
    return out


def stl(name):
    return os.path.join(S, name + ".stl")


def grid(files, cols, out, size=None):
    ims = [Image.open(f) for f in files]
    w, h = ims[0].size
    rows = (len(ims) + cols - 1) // cols
    im = Image.new("RGB", (cols * w, rows * h), "white")
    for i, a in enumerate(ims):
        im.paste(a, ((i % cols) * w, (i // cols) * h))
    if size:
        im = im.resize(size, Image.LANCZOS)
    im.save(out)
    return out


def transformed(name, T, tag):
    m = trimesh.load(stl(name), force="mesh")
    m.apply_transform(T)
    p = os.path.join(TMP, f"{tag}_{name}.stl")
    m.export(p)
    return p


THC_EXT = [("thc_front_plate", GRAY), ("thc_front_body", GRAY), ("thc_rear_body", GRAY), ("thc_connector_boss", BLACK),
           ("thc_boot", BLACK), ("thc_grip", GRIP), ("thc_lock_slider", GRIP)]
THC_ALL = THC_EXT + [("thc_carriage", "0.50,0.80,0.50"), ("thc_boss_cap", "0.92,0.82,0.40"), ("thc_sleeve", "0.80,0.50,0.75"),
                     ("thc_sleeve_retainer", "0.80,0.50,0.75"), ("thc_shaft", "0.60,0.60,0.90"), ("thc_tail_disc", "0.55,0.55,0.58")]
TTCA_EXT = [("ttca_housing", TTCA_GRAY), ("ttca_bottom_plate", TTCA_GRAY), ("ttca_nameplate", ALU), ("ttca_boot_ring", TTCA_GRAY),
            ("ttca_boot", BOOT_BLUE), ("ttca_stem_guide", TTCA_GRAY), ("ttca_stem", STEEL), ("ttca_knob", TTCA_KNOB),
            ("ttca_friction_knob", KNOB), ("ttca_select_lever", LEVER_GRAY), ("ttca_lever_band", CHROME),
            ("ttca_lever_guide", LEVER_GRAY), ("ttca_placard_mode", PLACARD_BLACK), ("ttca_placard_friction", PLACARD_BLACK),
            ("ttca_vent_plate", "0.93,0.93,0.91")]
TTCA_MECH = [("ttca_cradle", "0.90,0.55,0.30"), ("ttca_yaw_block", "0.50,0.80,0.50"), ("ttca_yaw_block_lid", "0.40,0.70,0.40"),
             ("ttca_stem_guide", "0.45,0.55,0.85"),
             ("ttca_stem_washer", "0.90,0.30,0.30"), ("ttca_stub_axle_right", "0.95,0.80,0.20"), ("ttca_stub_axle_left", "0.95,0.80,0.20"),
             ("ttca_sector", "0.80,0.40,0.80"), ("ttca_pawl_crank", "0.30,0.80,0.80"), ("ttca_detent_plunger", "0.95,0.50,0.50"),
             ("ttca_pot_coupler", "0.60,0.60,0.95"), ("ttca_brake_slider", "0.95,0.65,0.20"), ("ttca_brake_pad", "0.80,0.20,0.20"),
             ("ttca_brake_rod", "0.70,0.70,0.30"), ("ttca_lever_arm", "0.85,0.85,0.88")]
TTCA_ALL = [("ttca_housing", "0.55,0.55,0.58"), ("ttca_bottom_plate", "0.45,0.45,0.48"), ("ttca_boot_ring", "0.35,0.40,0.70"),
            ("ttca_boot", BOOT_BLUE), ("ttca_stem", "0.85,0.85,0.60"), ("ttca_knob", TTCA_KNOB),
            ("ttca_friction_knob", KNOB), ("ttca_select_lever", "0.85,0.85,0.88"), ("ttca_lever_band", CHROME),
            ("ttca_lever_guide", KNOB), ("ttca_nameplate", ALU), ("ttca_vent_plate", "0.93,0.93,0.91")] + TTCA_MECH


def items(lst, mapper=stl):
    return [(mapper(n), c) for (n, c) in lst]


FIGS = {}


def fig(name):
    def deco(fn):
        FIGS[name] = fn
        return fn
    return deco


@fig("doc_thc_exterior")
def _():
    a = shade(os.path.join(TMP, "a.png"), items(THC_EXT), "1,-1.1,0.9", "z")
    b = shade(os.path.join(TMP, "b.png"), items(THC_EXT), "0,-0.001,1", "y")
    return grid([a, b], 2, os.path.join(R, "doc_thc_exterior.png"), (1600, 800))


@fig("doc_thc_back")
def _():
    return shade(os.path.join(R, "doc_thc_back.png"), items(THC_EXT), "0.9,-0.6,-1.2", "z", px=800)


@fig("doc_thc_section")
def _():
    return shade(os.path.join(R, "doc_thc_section.png"), items(THC_ALL), "1,0,0", "z", cut="x", px=900)


def thc_on_stand():
    """Box on the stand: bottom face (dovetail socket) on the slope, handle pointing
    up the slope towards the user, who sits at the raised end."""
    ang = math.radians(25.0)
    n = np.array([0, -math.sin(ang), math.cos(ang)])      # slope normal
    s = np.array([0, math.cos(ang), math.sin(ang)])       # up the slope
    R = np.column_stack([np.array([-1.0, 0, 0]), n, s])   # box x -> -X, y -> n, z -> s
    T = np.eye(4); T[:3, :3] = R; T[:3, 3] = 80.0 * n + 138.0 * s
    return [(transformed(nme, T, "stand"), c) for (nme, c) in THC_EXT] + [(stl("thc_tilt_stand"), GRIP)]


@fig("doc_thc_stand")
def _():
    return shade(os.path.join(R, "doc_thc_stand.png"), thc_on_stand(), "1,1.3,0.7", "z", px=800)


@fig("doc_ttca_exterior")
def _():
    a = shade(os.path.join(TMP, "ta.png"), items(TTCA_EXT), "1,0.8,1.3", "y")
    b = shade(os.path.join(TMP, "tb.png"), items(TTCA_EXT), "0,0.25,1", "y")
    return grid([a, b], 2, os.path.join(R, "doc_ttca_exterior.png"), (1600, 800))


@fig("doc_ttca_left")
def _():
    a = shade(os.path.join(TMP, "tl.png"), items(TTCA_EXT), "-1,0.6,1.2", "y")
    b = shade(os.path.join(TMP, "ts.png"), items(TTCA_EXT), "1,0,0", "y")
    return grid([a, b], 2, os.path.join(R, "doc_ttca_left.png"), (1600, 800))


@fig("doc_ttca_section")
def _():
    a = shade(os.path.join(TMP, "sx0.png"), items(TTCA_ALL), "1,0,0", "y", cut="x--18")
    b = shade(os.path.join(TMP, "sx88.png"), items(TTCA_ALL), "1,0,0", "y", cut="x-69.5")
    return grid([a, b], 2, os.path.join(R, "doc_ttca_section.png"), (1600, 800))


@fig("doc_ttca_mechanism")
def _():
    lst = [("ttca_stem", "0.85,0.85,0.60"), ("ttca_knob", "0.20,0.20,0.22")] + TTCA_MECH
    a = shade(os.path.join(TMP, "m1.png"), items(lst), "1,0.7,1.2", "y")
    b = shade(os.path.join(TMP, "m2.png"), items(lst), "1,0.3,-0.9", "y")
    return grid([a, b], 2, os.path.join(R, "doc_ttca_mechanism.png"), (1600, 800))


@fig("doc_ttca_brake")
def _():
    lst = [("ttca_housing", "0.55,0.55,0.58"), ("ttca_cradle", "0.90,0.55,0.30"), ("ttca_brake_slider", "0.95,0.65,0.20"),
           ("ttca_brake_pad", "0.80,0.20,0.20"), ("ttca_brake_rod", "0.70,0.70,0.30"),
           ("ttca_friction_knob", KNOB), ("ttca_sector", "0.80,0.40,0.80"), ("ttca_pawl_crank", "0.30,0.80,0.80"),
           ("ttca_detent_plunger", "0.95,0.50,0.50"), ("ttca_select_lever", "0.85,0.85,0.88"), ("ttca_lever_arm", "0.85,0.85,0.88"),
           ("ttca_stub_axle_right", "0.95,0.80,0.20")]
    return shade(os.path.join(R, "doc_ttca_brake.png"), items(lst), "1,0.5,0.6", "y", cut="x-40", px=900)


@fig("doc_ttca_vs_ref")
def _():
    if not os.path.isdir(REF):
        return None
    ref = [(os.path.join(REF, "ttca_Body.obj"), TTCA_GRAY), (os.path.join(REF, "ttca_Handle.obj"), TTCA_KNOB),
           (os.path.join(REF, "ttca_SelectionLever.obj"), ALU), (os.path.join(REF, "ttca_FrictionControl.obj"), KNOB)]
    a = shade(os.path.join(TMP, "r1.png"), ref, "1,0.8,1.3", "y")
    b = shade(os.path.join(TMP, "r2.png"), items(TTCA_EXT), "1,0.8,1.3", "y")
    c = shade(os.path.join(TMP, "r3.png"), ref, "0,0.25,1", "y")
    d = shade(os.path.join(TMP, "r4.png"), items(TTCA_EXT), "0,0.25,1", "y")
    return grid([a, b, c, d], 2, os.path.join(R, "doc_ttca_vs_ref.png"), (1400, 1400))


@fig("doc_thc_vs_ref")
def _():
    if not os.path.isdir(REF):
        return None
    ref = [(os.path.join(REF, "thc_Group_5.obj"), GRAY), (os.path.join(REF, "thc_THChandle.obj"), GRIP)]
    a = shade(os.path.join(TMP, "h1.png"), ref, "1,-1.1,0.9", "z")
    b = shade(os.path.join(TMP, "h2.png"), items(THC_EXT), "1,-1.1,0.9", "z")
    c = shade(os.path.join(TMP, "h3.png"), ref, "1,0,0", "z")
    d = shade(os.path.join(TMP, "h4.png"), items(THC_EXT), "1,0,0", "z")
    return grid([a, b, c, d], 2, os.path.join(R, "doc_thc_vs_ref.png"), (1400, 1400))


@fig("doc_both")
def _():
    # THC on its stand to the left of the TTCA, both on the desk plane y = 0 (TTCA frame)
    thc = thc_on_stand()
    # the stand frame has z up; rotate into the TTCA frame (y up, z towards the user): (x, y, z) -> (x, z, -y)
    Tf = np.array([[-1, 0, 0, 0], [0, 0, 1, 0], [0, 1, 0, 0], [0, 0, 0, 1]], float)   # stand y (towards the user) -> +Z
    Tf = trimesh.transformations.translation_matrix([-235, 0, 10]) @ Tf
    out = []
    for (f, c) in thc:
        m = trimesh.load(f, force="mesh").apply_transform(Tf)
        p = os.path.join(TMP, "both_" + os.path.basename(f)); m.export(p); out.append((p, c))
    out += items(TTCA_EXT)
    return shade(os.path.join(R, "doc_both.png"), out, "0.9,0.7,1.3", "y", px=1400)


if __name__ == "__main__":
    want = sys.argv[1:] or list(FIGS)
    for name in want:
        print(name, "->", FIGS[name]())
