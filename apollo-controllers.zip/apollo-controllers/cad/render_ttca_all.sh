#!/bin/sh
# usage: render_ttca_all.sh out.png [shade.py args...]   (all parts, distinct colours; add --cut x-NN for a section)
cd "$(dirname "$0")/.." || exit 1
S=stl
OUT=$1; shift
python3 cad/shade.py "$OUT" $S/ttca_housing.stl:0.55,0.55,0.58 $S/ttca_bottom_plate.stl:0.45,0.45,0.48 \
  $S/ttca_boot_ring.stl:0.35,0.40,0.70 $S/ttca_boot.stl:0.60,0.68,0.80 $S/ttca_stem_guide.stl:0.45,0.55,0.85 \
  $S/ttca_stem.stl:0.85,0.85,0.60 $S/ttca_knob.stl:0.66,0.67,0.68 \
  $S/ttca_cradle.stl:0.90,0.55,0.30 $S/ttca_yaw_block.stl:0.50,0.80,0.50 $S/ttca_yaw_block_lid.stl:0.40,0.70,0.40 \
  $S/ttca_stem_washer.stl:0.9,0.3,0.3 $S/ttca_stub_axle_right.stl:0.95,0.80,0.20 $S/ttca_stub_axle_left.stl:0.95,0.80,0.20 \
  $S/ttca_sector.stl:0.80,0.40,0.80 $S/ttca_pawl_crank.stl:0.30,0.80,0.80 $S/ttca_detent_plunger.stl:0.95,0.50,0.50 \
  $S/ttca_pot_coupler.stl:0.60,0.60,0.95 $S/ttca_brake_slider.stl:0.95,0.65,0.20 $S/ttca_brake_pad.stl:0.80,0.20,0.20 $S/ttca_brake_rod.stl:0.70,0.70,0.30 \
  $S/ttca_friction_knob.stl:0.40,0.40,0.42 $S/ttca_select_lever.stl:0.85,0.85,0.88 $S/ttca_lever_arm.stl:0.85,0.85,0.88 $S/ttca_lever_band.stl:0.88,0.89,0.91 \
  $S/ttca_lever_guide.stl:0.55,0.56,0.58 $S/ttca_placard_mode.stl:0.08,0.08,0.09 $S/ttca_placard_friction.stl:0.08,0.08,0.09 \
  $S/ttca_nameplate.stl:0.80,0.81,0.83 "$@"
