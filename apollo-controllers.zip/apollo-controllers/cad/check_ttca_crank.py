"""Selector crank check: swings the crank to its THROTTLE position (tip withdrawn)
and tests it against the sector over the pitch travel and against the fixed parts.
usage: python3 check_ttca_crank.py   (after ttca.py, from the cad directory)"""
import math, numpy as np, trimesh
from trimesh.ray.ray_triangle import RayMeshIntersector
import ttca as t

S = "../stl/"
def load(n):
    return trimesh.load(S + n + ".stl", force="mesh")

crank, sector, housing = load("ttca_pawl_crank"), load("ttca_sector"), load("ttca_housing")
others = {n: load(n) for n in ("ttca_stem_guide", "ttca_boot_ring", "ttca_cradle", "ttca_stub_axle_right", "ttca_detent_plunger", "ttca_brake_slider", "ttca_brake_pad", "ttca_brake_rod", "ttca_lever_arm")}
ax = np.array([t.HANDLE_X, t.AY, t.AZ])
py, pz = t.CRANK_PIVOT
pivot_w = np.array([t.HANDLE_X, *t.to_world(py, pz)])
theta = -t.crank_angle(-t.LEVER_SWING, t.LEVER_SWING)                   # control arm swing at THROTTLE (kinematics in ttca.py)
print(f"crank swing at THROTTLE: {theta:.1f} deg (lever swing +/-{t.LEVER_SWING:.1f}, pin contact at {t.PIN_CONTACT_DEG:.1f} from neutral)")

def rot(axis, deg, point):
    return trimesh.transformations.rotation_matrix(math.radians(deg), axis, point)

def pts(m, n=2000, near=None):
    """Sample points pulled 0.3 mm inside the surface: the vertices plus points spread over
    the faces (so an edge or a flat face passing through another part is caught); with
    `near` (a mesh), keep every point inside that mesh's bounding box grown by 6 mm
    instead of a random subset."""
    q, fi = trimesh.sample.sample_surface_even(m, 1500, seed=0)
    p = np.vstack([m.vertices - m.vertex_normals * 0.3, q - m.face_normals[fi] * 0.3])
    if near is not None:
        lo, hi = near.bounds[0] - 6, near.bounds[1] + 6
        p = p[np.all((p > lo) & (p < hi), axis=1)]
        return p
    if len(p) > n:
        p = p[np.random.RandomState(0).choice(len(p), n, replace=False)]
    return p

def inside(mesh, p):
    if len(p) == 0:
        return np.zeros(0, bool)
    return np.concatenate([RayMeshIntersector(mesh).contains_points(p[k:k + 40]) for k in range(0, len(p), 40)])

# which rotation sense withdraws the tip?  the tip apex moves along -z'
apex_local = np.array([0.0, 0.0, -t.SECTOR_R + 3.5])
for sgn in (1, -1):
    Tc = rot([1, 0, 0], sgn * theta, pivot_w)
    apex_w = np.array([0.0, *t.to_world(0.0, -t.SECTOR_R + 3.5)])
    moved = (Tc[:3, :3] @ apex_w) + Tc[:3, 3]
    yl, zl = t.to_local(moved[1], moved[2])
    print(f"  sense {sgn:+d}: tip apex at local y' {yl:.1f} z' {zl:.1f} (engaged z' {-t.SECTOR_R + 3.5:.1f})")
    if zl < -t.SECTOR_R + 3.5 - 3:
        T_throttle = Tc
        print(f"  -> THROTTLE sense {sgn:+d}: tip withdraws {(-t.SECTOR_R + 3.5) - zl:.1f} mm, rim clearance {abs(zl) - t.SECTOR_R:.1f} mm")

crank_p = pts(crank)
cp_thr = (T_throttle[:3, :3] @ crank_p.T).T + T_throttle[:3, 3]
problems = 0
for pitch in (-t.PITCH_STOP, -t.PITCH_STOP / 2, 0, t.PITCH_STOP / 2, t.PITCH_STOP):
    Tp = rot([1, 0, 0], pitch, ax)
    sec = sector.copy().apply_transform(Tp)
    for label, cp in (("engaged", crank_p), ("THROTTLE", cp_thr)):
        hits = int(inside(sec, cp).sum())
        sp = pts(sec); crank_mesh = crank.copy()
        if label == "THROTTLE":
            crank_mesh.apply_transform(T_throttle)
        hits += int(inside(crank_mesh, sp).sum())
        if label == "engaged" and pitch != 0:
            continue        # in JETS the notch flank pushes the engaged tip out against its spring: expected
        if hits:
            problems += 1
            print(f"pitch {pitch:+5.1f}: crank ({label}) <-> sector: {hits} points inside")
hub_w = np.array([0.0, t.LEVER_PIVOT[1], t.LEVER_PIVOT[0]])
for label, cp, Tc, lever_deg in (("engaged", crank_p, np.eye(4), t.LEVER_SWING), ("THROTTLE", cp_thr, T_throttle, -t.LEVER_SWING)):
    for n, m in dict(others, ttca_housing=housing).items():
        if n == "ttca_detent_plunger":
            continue
        if n == "ttca_lever_arm":                                        # the arm (and its pin) turns with the lever
            m = m.copy().apply_transform(rot([1, 0, 0], lever_deg, hub_w))
        hits = int(inside(m, cp).sum())
        crank_mesh = crank.copy().apply_transform(Tc)
        hits += int(inside(crank_mesh, pts(m, near=crank_mesh)).sum())
        if hits:
            problems += 1
            print(f"crank ({label}) <-> {n}: {hits} points inside")
# mode switch: where is the crank's foot relative to the switch lever zone?
foot = crank.vertices[(crank.vertices[:, 0] < 70 + t.HANDLE_X)]
for label, Tc in (("engaged", np.eye(4)), ("THROTTLE", T_throttle)):
    f = (Tc[:3, :3] @ foot.T).T + Tc[:3, 3]
    zl = [t.to_local(p[1], p[2])[1] for p in f]
    print(f"foot back face at z' {min(zl):.1f} ({label}); switch plunger face at z' {t.SW_ZL - 2.6 + 10.2:.1f}, lever rest about {t.SW_ZL - 2.6 + 10.2 + 4:.1f}")
print("problems:", problems)
