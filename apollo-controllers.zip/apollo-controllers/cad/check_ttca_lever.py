"""Selector lever check: turns the lever (bar), its chrome band and the crank
arm inside the wall about the hub to JETS (band down), neutral and THROTTLE
(band up) and tests them against the fixed parts outside (housing, guide
plate, boot, knobs, placards) and inside (sector, brake, detent plunger);
also reports the band's clearance over the front panel, the boot ring and
the guide plate.  The pin-and-slot drive itself is checked in ttca.py's
kinematics (crank_angle) and by check_ttca_crank.py.
usage: python3 check_ttca_lever.py   (after ttca.py, from the cad directory)"""
import math, numpy as np, trimesh
from trimesh.ray.ray_triangle import RayMeshIntersector
import ttca as t

S = "../stl/"
MOVING = ["ttca_select_lever", "ttca_lever_band", "ttca_lever_arm"]
FIXED = ["ttca_housing", "ttca_lever_guide", "ttca_boot_ring", "ttca_boot", "ttca_friction_knob", "ttca_placard_mode",
         "ttca_placard_friction", "ttca_stem_guide", "ttca_knob", "ttca_nameplate", "ttca_sector", "ttca_brake_slider",
         "ttca_brake_pad", "ttca_brake_rod", "ttca_detent_plunger"]
IGNORE = {("ttca_select_lever", "ttca_housing")}          # the detent bump is preloaded into the wall
# the band and bar never reach the inside parts; the arm never reaches the outside ones
SKIP = {("ttca_lever_arm", n) for n in FIXED if n not in ("ttca_housing", "ttca_sector", "ttca_brake_slider", "ttca_brake_pad", "ttca_brake_rod", "ttca_detent_plunger")}
SKIP |= {(m, n) for m in ("ttca_select_lever", "ttca_lever_band") for n in ("ttca_sector", "ttca_brake_slider", "ttca_brake_pad", "ttca_brake_rod", "ttca_detent_plunger")}

meshes = {n: trimesh.load(S + n + ".stl", force="mesh") for n in MOVING + FIXED}
inter = {n: RayMeshIntersector(m) for n, m in meshes.items()}


def pts(n, near=None, cap=4000):
    """Vertices plus 1500 points spread over the faces, all pulled 0.3 mm inside."""
    m = meshes[n]
    q, fi = trimesh.sample.sample_surface_even(m, 1500, seed=0)
    p = np.vstack([m.vertices - m.vertex_normals * 0.3, q - m.face_normals[fi] * 0.3])
    if near is not None:
        lo, hi = near.bounds[0] - 5, near.bounds[1] + 5
        p = p[np.all((p > lo) & (p < hi), axis=1)]
    if len(p) > cap:
        p = p[np.random.RandomState(0).choice(len(p), cap, replace=False)]
    return p


def inside(n, p):
    if len(p) == 0:
        return np.zeros(0, bool)
    return np.concatenate([inter[n].contains_points(p[k:k + 40]) for k in range(0, len(p), 40)])


pivot = np.array([0.0, t.LEVER_PIVOT[1], t.LEVER_PIVOT[0]])
problems = 0
# a positive rotation about +X (right-hand rule) swings the front end of the lever down: JETS
for ang, label in ((t.LEVER_SWING, "JETS"), (0.0, "neutral"), (-t.LEVER_SWING, "THROTTLE")):
    T = trimesh.transformations.rotation_matrix(math.radians(ang), [1, 0, 0], pivot)
    for mv in MOVING:
        moved = meshes[mv].copy().apply_transform(T)
        mp = (T[:3, :3] @ pts(mv).T).T + T[:3, 3]
        for fx in FIXED:
            if (mv, fx) in IGNORE or (mv, fx) in SKIP:
                continue
            hits = int(inside(fx, mp).sum())
            fp = pts(fx, near=moved)
            if len(fp):
                im = RayMeshIntersector(moved)
                hits += int(sum(im.contains_points(fp[k:k + 40]).sum() for k in range(0, len(fp), 40)))
            if hits:
                problems += 1
                print(f"{label:8s}: {mv} <-> {fx}: {hits} sample points inside")
    # where is the band's arm?  (its y' range at this position, for the record) and how close does the
    # band come to the face plate, the boot ring and the guide plate
    band = meshes["ttca_lever_band"].copy().apply_transform(T)
    yl = np.array([t.to_local(v[1], v[2])[0] for v in band.vertices])
    zl = np.array([t.to_local(v[1], v[2])[1] for v in band.vertices])
    print(f"{label:8s}: band y' {yl.min():6.1f} .. {yl.max():6.1f}, z' {zl.min():5.1f} .. {zl.max():5.1f} (face plane {t.FACE_Z})")
    bp = band.vertices[np.random.RandomState(1).choice(len(band.vertices), min(3000, len(band.vertices)), replace=False)]
    for fx in ("ttca_housing", "ttca_boot_ring", "ttca_lever_guide"):
        _, dist, _ = trimesh.proximity.closest_point(meshes[fx], bp)
        print(f"{label:8s}: band to {fx}: {dist.min():.1f} mm")
print("problems:", problems)
