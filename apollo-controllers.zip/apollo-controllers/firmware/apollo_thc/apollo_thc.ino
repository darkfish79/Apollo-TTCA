/*
 * Apollo CM Translation Hand Controller (THC) replica - USB HID firmware
 * Board: Arduino Pro Micro / Leonardo (ATmega32U4)
 * Library: "Joystick" by Matthew Heironimus (Arduino Library Manager: "Joystick")
 *
 * Eight microswitches, one side to GND, the other to the pins below.
 * The board presents itself as a game controller with 8 buttons.
 * Reentry: Settings > Input > CONFIGURE, press ASSIGN, press any THC switch,
 * then bind the six translation commands and (if exposed) the two twist
 * functions to the buttons.
 *
 * Build options:
 *   OUTPUT_JOYSTICK  (default)  - HID game controller buttons 1..8
 *   OUTPUT_KEYBOARD             - sends Reentry's default translation keys
 *                                 (U O I K J L) and two keys for CW / CCW,
 *                                 useful if a binding cannot be made in-game.
 */

#define OUTPUT_JOYSTICK
// #define OUTPUT_KEYBOARD

#ifdef OUTPUT_JOYSTICK
#include <Joystick.h>
#endif
#ifdef OUTPUT_KEYBOARD
#include <Keyboard.h>
#endif

// ---- pin map (Pro Micro silkscreen numbers) --------------------------------
// Translation switches sit in the pocket walls (Y/Z), on the tall floor fin
// (pull) and on the short floor fin (push). The two twist switches are on the
// carriage deck.
const uint8_t PIN_X_PLUS  = 2;   // push (handle toward the housing)      -> +X forward
const uint8_t PIN_X_MINUS = 3;   // pull                                   -> -X
const uint8_t PIN_Y_PLUS  = 4;   // right wall switch                      -> +Y
const uint8_t PIN_Y_MINUS = 5;   // left wall switch                       -> -Y
const uint8_t PIN_Z_PLUS  = 6;   // bottom wall switch (handle down)       -> +Z (toward the crew's feet)
const uint8_t PIN_Z_MINUS = 7;   // top wall switch (handle up)            -> -Z
const uint8_t PIN_CW      = 8;   // twist clockwise                        -> CMC->SCS transfer
const uint8_t PIN_CCW     = 9;   // twist counterclockwise                 -> launch abort

// Set to 1 to swap push/pull, if you mount the box with the handle vertical
// (CM armrest style) and want "toward the panel" to stay +X.
#define INVERT_X 0

const uint8_t PINS[8]   = {PIN_X_PLUS, PIN_X_MINUS, PIN_Y_PLUS, PIN_Y_MINUS, PIN_Z_PLUS, PIN_Z_MINUS, PIN_CW, PIN_CCW};
const char    KEYS[8]   = {'u', 'o', 'l', 'j', 'k', 'i', '=', '-'};   // keyboard mode
const uint8_t DEBOUNCE_MS = 8;

#ifdef OUTPUT_JOYSTICK
Joystick_ Joystick(JOYSTICK_DEFAULT_REPORT_ID, JOYSTICK_TYPE_JOYSTICK,
                   8, 0,                  // 8 buttons, no hat
                   false, false, false,   // no X, Y, Z axes
                   false, false, false,   // no Rx, Ry, Rz
                   false, false,          // no rudder, throttle
                   false, false, false);  // no accelerator, brake, steering
#endif

uint8_t  state[8];
uint8_t  lastRead[8];
uint32_t lastChange[8];

void setup() {
  for (uint8_t i = 0; i < 8; i++) {
    pinMode(PINS[i], INPUT_PULLUP);
    state[i] = lastRead[i] = HIGH;
    lastChange[i] = 0;
  }
#ifdef OUTPUT_JOYSTICK
  Joystick.begin();
#endif
#ifdef OUTPUT_KEYBOARD
  Keyboard.begin();
#endif
}

void emit(uint8_t idx, bool pressed) {
  uint8_t logical = idx;
#if INVERT_X
  if (idx == 0) logical = 1; else if (idx == 1) logical = 0;
#endif
#ifdef OUTPUT_JOYSTICK
  Joystick.setButton(logical, pressed ? 1 : 0);
#endif
#ifdef OUTPUT_KEYBOARD
  if (pressed) Keyboard.press(KEYS[logical]); else Keyboard.release(KEYS[logical]);
#endif
}

void loop() {
  uint32_t now = millis();
  for (uint8_t i = 0; i < 8; i++) {
    uint8_t r = digitalRead(PINS[i]);
    if (r != lastRead[i]) { lastRead[i] = r; lastChange[i] = now; }
    if (r != state[i] && (now - lastChange[i]) >= DEBOUNCE_MS) {
      state[i] = r;
      emit(i, r == LOW);   // switch closed = pressed
    }
  }
  delay(1);
}
