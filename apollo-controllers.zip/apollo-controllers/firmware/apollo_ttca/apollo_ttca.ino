/*
 * Apollo LM Thrust/Translation Controller Assembly (TTCA) replica - USB HID firmware
 * Board: Arduino Pro Micro / Leonardo (ATmega32U4)
 * Library: "Joystick" by Matthew Heironimus (Arduino Library Manager: "Joystick")
 *
 * Inputs
 *   A0      10k potentiometer on the pitch axle (throttle / +-X)
 *   D2..D5  four lever microswitches: +Y, -Y (yaw), +Z, -Z (slide)
 *   D6      mode switch, closed = THROTTLE (selector band up), open = JETS (band down)
 *
 * Outputs (OUTPUT_JOYSTICK, default): a game controller with
 *   Throttle axis   : handle position, 0..1023, reported only in THROTTLE mode;
 *                     in JETS mode the axis is parked at its minimum (10 %).
 *   Buttons 1..4    : +Y  -Y  +Z  -Z
 *   Buttons 5, 6    : +X  -X   (JETS mode only: handle above / below the mid detent)
 *   Button 7        : THROTTLE mode indicator (on while the selector is at THROTTLE)
 *   Button 8        : soft-stop passed (handle beyond SOFT_STOP), for a cockpit light
 *
 * Reentry treats the TTCA X-axis input as the throttle when THR CONT is MAN and
 * the in-cockpit THROTTLE/JETS lever is at THROTTLE. Bind the Throttle axis to
 * the LM translation up/down axis, and buttons 5/6 to translation up/down for
 * JETS mode. If the axis binding does not behave, use OUTPUT_KEYBOARD, which
 * presses I / K (translation up / down) while the handle is moved up / down.
 */

#define OUTPUT_JOYSTICK
// #define OUTPUT_KEYBOARD

#ifdef OUTPUT_JOYSTICK
#include <Joystick.h>
#endif
#ifdef OUTPUT_KEYBOARD
#include <Keyboard.h>
#endif

const uint8_t PIN_POT     = A0;
const uint8_t PIN_Y_PLUS  = 2;   // left/right yaw switches (right = +Y)
const uint8_t PIN_Y_MINUS = 3;
const uint8_t PIN_Z_PLUS  = 4;   // push in = +Z (forward)
const uint8_t PIN_Z_MINUS = 5;   // pull out = -Z
const uint8_t PIN_MODE    = 6;   // closed = THROTTLE (selector band up, switch pressed by the crank foot)

// ---- calibration: raw ADC values at the mechanical stops --------------------
// Move the handle to each stop with the serial monitor open and copy the numbers
// printed by the CALIBRATE build. Direct-drive 10k pot, 56 deg of its 300 deg
// sweep: about 190 counts between the stops.
int RAW_MIN  = 415;   // handle fully down   (10 % thrust)
int RAW_MAX  = 605;   // handle fully up     (hard stop, FTP 92.5 %)
int RAW_MID  = 510;   // JETS detent position
const int   JETS_DEADBAND  = 12;   // counts either side of RAW_MID before +-X fires
const float SOFT_STOP_FRAC = 0.70; // fraction of travel where the soft stop sits (real: 53/63)
// #define CALIBRATE                // uncomment, upload, open Serial Monitor at 115200

#ifdef OUTPUT_JOYSTICK
Joystick_ Joystick(JOYSTICK_DEFAULT_REPORT_ID, JOYSTICK_TYPE_JOYSTICK,
                   8, 0,
                   false, false, false,
                   false, false, false,
                   false, true,          // throttle axis
                   false, false, false);
#endif

const uint8_t PINS[5] = {PIN_Y_PLUS, PIN_Y_MINUS, PIN_Z_PLUS, PIN_Z_MINUS, PIN_MODE};
uint8_t state[5], lastRead[5];
uint32_t lastChange[5];
const uint8_t DEBOUNCE_MS = 8;
int filt = 512;
bool xPlus = false, xMinus = false, softLit = false;

void setup() {
  for (uint8_t i = 0; i < 5; i++) { pinMode(PINS[i], INPUT_PULLUP); state[i] = lastRead[i] = HIGH; }
#ifdef OUTPUT_JOYSTICK
  Joystick.begin();
  Joystick.setThrottleRange(0, 1023);
#endif
#ifdef OUTPUT_KEYBOARD
  Keyboard.begin();
#endif
#ifdef CALIBRATE
  Serial.begin(115200);
#endif
}

void setButton(uint8_t b, bool on) {
#ifdef OUTPUT_JOYSTICK
  Joystick.setButton(b, on ? 1 : 0);
#endif
#ifdef OUTPUT_KEYBOARD
  const char keys[8] = {'l', 'j', 'u', 'o', 'i', 'k', 0, 0};
  if (keys[b]) { if (on) Keyboard.press(keys[b]); else Keyboard.release(keys[b]); }
#endif
}

void loop() {
  uint32_t now = millis();
  for (uint8_t i = 0; i < 5; i++) {
    uint8_t r = digitalRead(PINS[i]);
    if (r != lastRead[i]) { lastRead[i] = r; lastChange[i] = now; }
    if (r != state[i] && (now - lastChange[i]) >= DEBOUNCE_MS) {
      state[i] = r;
      if (i < 4) setButton(i, r == LOW);
      if (i == 4) setButton(6, r == LOW);          // THROTTLE mode indicator
    }
  }
  bool throttleMode = (state[4] == LOW);

  int raw = analogRead(PIN_POT);
  filt += (raw - filt) / 4;                        // light low-pass filter
#ifdef CALIBRATE
  static uint32_t t; if (now - t > 200) { t = now; Serial.print("raw "); Serial.println(filt); }
#endif
  long pos = map(constrain(filt, min(RAW_MIN, RAW_MAX), max(RAW_MIN, RAW_MAX)), RAW_MIN, RAW_MAX, 0, 1023);
  pos = constrain(pos, 0L, 1023L);

#ifdef OUTPUT_JOYSTICK
  Joystick.setThrottle(throttleMode ? (int)pos : 0);
#endif
#ifdef OUTPUT_KEYBOARD
  // keyboard mode: press I while moving up, K while moving down (rate control)
  static long lastPos = pos;
  long d = pos - lastPos; lastPos = pos;
  if (throttleMode) {
    if (d > 2) { Keyboard.press('i'); } else if (d < -2) { Keyboard.press('k'); }
    else { Keyboard.release('i'); Keyboard.release('k'); }
  }
#endif
  // JETS mode: +X / -X from the detent position
  bool p = !throttleMode && filt > RAW_MID + JETS_DEADBAND;
  bool m = !throttleMode && filt < RAW_MID - JETS_DEADBAND;
  if (p != xPlus)  { xPlus = p;  setButton(4, p); }
  if (m != xMinus) { xMinus = m; setButton(5, m); }
  bool s = throttleMode && pos > SOFT_STOP_FRAC * 1023;
  if (s != softLit) { softLit = s; setButton(7, s); }
  delay(2);
}
